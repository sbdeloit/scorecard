import pandas as pd
import numpy as np
import statsmodels.api as sm

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    roc_auc_score,
    roc_curve
)

from statsmodels.stats.outliers_influence import (
    variance_inflation_factor
)


##############################################################
# Extracting only WOE Transformed Variables
##############################################################


def prepare_model_dataset(
        df,
        key_col,
        target="Default"
):

    woe_cols = [

        c

        for c in df.columns

        if c.endswith("_COARSE_WOE")

    ]

    cols = []

    if key_col in df.columns:

        cols.append(
            key_col
        )

    cols.extend(
        woe_cols
    )

    if target in df.columns:

        cols.append(
            target
        )

    model_df = (
        df[cols]
        .copy()
    )
    
    woe_cols = [
    
        c
    
        for c in model_df.columns
    
        if c.endswith("_WOE")
    
    ]
    
    if len(woe_cols) > 0:
    
        model_df[woe_cols] = (
            model_df[woe_cols]
            .astype(float)
        )
    
    return model_df


########################################################
### Corrleation Function
########################################################

def correlation_analysis(
        model_df,
        target="Default",
        key_col=None,
        threshold=0.7
):

    cols = [

        c

        for c in model_df.columns

        if c.endswith("_WOE")

    ]

    corr_matrix = (
        model_df[cols]
        .corr()
    )

    high_corr = []

    for i in range(len(cols)):

        for j in range(i + 1, len(cols)):

            corr = corr_matrix.iloc[i, j]

            if abs(corr) >= threshold:

                high_corr.append({

                    "VARIABLE_1":
                        cols[i],

                    "VARIABLE_2":
                        cols[j],

                    "CORRELATION":
                        round(corr, 4)

                })

    high_corr = pd.DataFrame(
        high_corr,
        columns=["VARIABLE_1", "VARIABLE_2", "CORRELATION"]
    ).sort_values(
        "CORRELATION",
        key=lambda x: abs(x),
        ascending=False
    )

    return (
        corr_matrix,
        high_corr
    )


########################################################
### VIF Function
########################################################

def calculate_vif(df):

    vif_df = pd.DataFrame({

        "VARIABLE": df.columns,

        "VIF": [

            variance_inflation_factor(
                df.values,
                i
            )

            for i in range(df.shape[1])

        ]

    })

    return vif_df

##################################################
# Calibrated Scoring function
##################################################
    
def calculate_score(pd_series,min_score=300,max_score=900,base_score=600,base_odds=50,pdo=20):

    factor=pdo/np.log(2)

    offset=base_score-factor*np.log(base_odds)

    odds=(1-pd_series)/pd_series

    score=offset+factor*np.log(odds)

    return score.clip(min_score,max_score).round(0)

# =====================================================
# COMPLETE SCORECARD MODEL PIPELINE
# =====================================================

def scorecard_model_pipeline(
    train_df,
    test_df,
    coarse_rules=None,
    iv_map=None,
    target="Default",
    key_col=None,

    weighted_logit=False,
    weight_col=None,

    train_source_df=None,
    test_source_df=None,
    export_mode="none",
    export_folder="Scored_Data",
    export_format="csv",

    vif_threshold=3,
    pvalue_threshold=0.05,
    n_bins=10,
    min_score=300,
    max_score=900,
    base_score=600,
    base_odds=50,
    pdo=20,
    save_output=False,
    output_file="Model_Report.xlsx"
):

    # =================================================
    # TRAIN TEST SPLIT
    # =================================================
    # train_df, test_df = train_test_split(

    #     df,

    #     test_size=test_size,

    #     stratify=df[target],

    #     random_state=random_state
    # )

    print("\n===================================")
    print("TRAIN SHAPE :", train_df.shape)
    print("TEST SHAPE  :", test_df.shape)
    print("===================================")

    if weighted_logit and weight_col is None:    
        raise ValueError("weight_col must be supplied when weighted_logit=True")
    
    if weighted_logit and weight_col not in train_df.columns:    
        raise ValueError(f"{weight_col} not found in train_df")

    if export_mode.lower() not in ["none","final","all"]:

        raise ValueError(
            "export_mode must be "
            "'none', 'final' or 'all'")
    
    if export_format.lower() not in ["csv","xlsx"]:
    
        raise ValueError(
            "export_format must be "
            "'csv' or 'xlsx'")

    # =================================================
    # PREPARE DATA
    # =================================================
    drop_cols = [target]

    if key_col in train_df.columns:
        drop_cols.append(key_col)

    if weighted_logit:
        drop_cols.append(weight_col)

    X_train = train_df.drop(columns=drop_cols).copy()

    y_train = train_df[target]

    weights_train=train_df[weight_col] if weighted_logit else None

    X_test=test_df.drop(columns=[c for c in drop_cols if c in test_df.columns]).copy()

    y_test = test_df[target]

    # =================================================
    # MISSING VALUE CHECK
    # =================================================
    
    if X_train.isna().sum().sum() > 0:
    
        raise ValueError(
            "Missing values found in training data"
        )
    
    if X_test.isna().sum().sum() > 0:
    
        raise ValueError(
            "Missing values found in test data"
        )

    # =================================================
    # REMOVE CONSTANT COLUMNS
    # =================================================
    X_train = X_train.loc[:, X_train.nunique() > 1]

    X_test = X_test[X_train.columns]

    # =================================================
    # VIF FILTERING
    # =================================================
    dropped_vif = []

    if X_train.shape[1] == 0:
        raise ValueError("No variables available for VIF calculation")

    while True:

        vif_df = pd.DataFrame({

            "VARIABLE": X_train.columns,

            "VIF": [
                variance_inflation_factor(
                    X_train.values,
                    i
                )
                for i in range(X_train.shape[1])
            ]
        })

        max_vif = vif_df["VIF"].max()

        if max_vif < vif_threshold:
            break

        remove_var = vif_df.sort_values(
            "VIF",
            ascending=False
        )["VARIABLE"].iloc[0]

        dropped_vif.append({
            "VARIABLE": remove_var,
            "VIF": round(max_vif, 4)
        })

        print(
            f"Dropped by VIF: "
            f"{remove_var} "
            f"| VIF={round(max_vif,4)}"
        )

        X_train = X_train.drop(columns=[remove_var])
    vif_after_filtering = vif_df.copy()

    X_test = X_test[X_train.columns]

    # =================================================
    # STEPWISE LOGISTIC
    # =================================================
    variables = list(X_train.columns)

    dropped_stepwise = []

    while len(variables) > 1:

        try:      
            if weighted_logit:           
                model=sm.GLM(
                    y_train,
                    sm.add_constant(X_train[variables], has_constant="add"),
                    family=sm.families.Binomial(),
                    freq_weights=weights_train
                ).fit()
            
            else:

                model=sm.Logit(
                    y_train,
                    sm.add_constant(X_train[variables], has_constant="add")
                ).fit(disp=0)
        
        except Exception as e:
        
            raise ValueError(
                f"Logistic Regression Failed: {e}"
            )

        pvalues = model.pvalues.drop("const")

        max_p = pvalues.max()

        if max_p < pvalue_threshold:
            break

        remove_var = pvalues.idxmax()

        dropped_stepwise.append({
            "VARIABLE": remove_var,
            "P_VALUE": round(max_p, 6)
        })

        print(
            f"Dropped by Stepwise: "
            f"{remove_var} "
            f"| p-value={round(max_p,6)}"
        )

        variables.remove(remove_var)

    print("\nFinal Variables:")
    
    print(variables)

    # ==========================================
    # FINAL VIF AFTER STEPWISE
    # ==========================================
    
    final_vif = calculate_vif(
    
        X_train[
            variables
        ]
    
    )

    # =================================================
    # FINAL MODEL
    # =================================================
    try:
    
        if weighted_logit:
            final_model=sm.GLM(
                y_train,
                sm.add_constant(X_train[variables], has_constant="add"),
                family=sm.families.Binomial(),
                freq_weights=weights_train
            ).fit()
        
        else:        
            final_model=sm.Logit(
                y_train,
                sm.add_constant(X_train[variables], has_constant="add")
            ).fit(disp=0)
    
    except Exception as e:
    
        raise ValueError(
            f"Final Model Failed: {e}"
        )

    # =================================================
    # PREDICT PD
    # =================================================
    train_pred = final_model.predict(

        sm.add_constant(
            X_train[variables],
            has_constant="add"
        )
    )

    test_pred = final_model.predict(

        sm.add_constant(
            X_test[variables],
            has_constant="add"
        )
    )

    # =================================================
    # STORE PD
    # =================================================
    base_cols=[]

    if key_col in train_df.columns:
        base_cols.append(key_col)
    
    if target in train_df.columns:
        base_cols.append(target)
    
    train_output=train_df[base_cols].copy()
    test_base_cols = [column for column in base_cols if column in test_df.columns]
    test_output=test_df[test_base_cols].copy()

    train_output["PD"] = train_pred.values

    test_output["PD"] = test_pred.values

    # =================================================
    # CREATE TRAIN DECILES
    # =================================================
    if n_bins < 2:
        raise ValueError("n_bins must be at least 2")
    bin_edges=np.unique(pd.qcut(train_output["PD"],q=n_bins,retbins=True,duplicates="drop")[1])
    if len(bin_edges) < 2:
        raise ValueError("Predicted probabilities do not contain enough variation for banding")
    bin_edges[0] = -np.inf
    bin_edges[-1] = np.inf
    train_output["PD_BAND"]=pd.cut(train_output["PD"],bins=bin_edges,include_lowest=True)
    test_output["PD_BAND"]=pd.cut(test_output["PD"],bins=bin_edges,include_lowest=True)
    train_output["SCORE"]=calculate_score(train_output["PD"],min_score,max_score,base_score,base_odds,pdo)    
    test_output["SCORE"]=calculate_score(test_output["PD"],min_score,max_score,base_score,base_odds,pdo)    
    score_band_table=train_output.groupby("PD_BAND",observed=False)["SCORE"].agg(["min","max"]).reset_index()    
    score_band_table["SCORE_BAND"]=score_band_table["min"].astype(int).astype(str)+"-"+score_band_table["max"].astype(int).astype(str)    
    mapping=dict(zip(score_band_table["PD_BAND"],score_band_table["SCORE_BAND"]))    
    train_output["SCORE_BAND"]=train_output["PD_BAND"].map(mapping)    
    test_output["SCORE_BAND"]=test_output["PD_BAND"].map(mapping)

    # =================================================
    # METRICS FUNCTION
    # =================================================
    def get_metrics(y_true, y_pred):

        auc = roc_auc_score(
            y_true,
            y_pred
        )

        gini = 2 * auc - 1

        fpr, tpr, _ = roc_curve(
            y_true,
            y_pred
        )

        ks = np.max(
            np.abs(tpr - fpr)
        )

        return auc, gini, ks

    # =================================================
    # OVERALL METRICS
    # =================================================
    train_auc, train_gini, train_ks = get_metrics(
        y_train,
        train_pred
    )

    test_auc, test_gini, test_ks = get_metrics(
        y_test,
        test_pred
    )

    # =================================================
    # BAND REPORT FUNCTION
    # =================================================
    def create_band_report(data):

        total_rows = len(data)

        total_event = data[target].sum()

        total_non_event = (
            total_rows - total_event
        )

        grp = data.groupby(
            "PD_BAND",
            observed=False
        ).agg(

            TOTAL=(target, "count"),

            EVENT=(target, "sum")
        )

        grp["NON_EVENT"] = (
            grp["TOTAL"] - grp["EVENT"]
        )

        grp["POPULATION_%"] = (
            grp["TOTAL"] / total_rows
        )

        grp["EVENT_RATE"] = (
            grp["EVENT"] / grp["TOTAL"]
        )

        grp["EVENT_%"] = (
            grp["EVENT"] / total_event
        )

        grp["NON_EVENT_%"] = (
            grp["NON_EVENT"] / total_non_event
        )

        grp["CUM_EVENT_%"] = (
            grp["EVENT_%"].cumsum()
        )

        grp["CUM_NON_EVENT_%"] = (
            grp["NON_EVENT_%"].cumsum()
        )

        grp["KS"] = np.abs(

            grp["CUM_EVENT_%"]

            -

            grp["CUM_NON_EVENT_%"]

        ) * 100

        score_map=data.groupby("PD_BAND",observed=False)["SCORE_BAND"].first()

        grp["SCORE_BAND"]=score_map
        
        grp=grp.reset_index()
        
        cols=["PD_BAND","SCORE_BAND"]+[c for c in grp.columns if c not in ["PD_BAND","SCORE_BAND"]]
        
        return grp[cols]

    # =================================================
    # CREATE REPORTS
    # =================================================
    train_band_report = create_band_report(
        train_output
    )

    test_band_report = create_band_report(
        test_output
    )

    # =================================================
    # ADD AUC / GINI
    # =================================================
    train_band_report["AUC"] = round(
        train_auc,
        4
    )

    train_band_report["GINI"] = round(
        train_gini,
        4
    )

    test_band_report["AUC"] = round(
        test_auc,
        4
    )

    test_band_report["GINI"] = round(
        test_gini,
        4
    )

    # =================================================
    # PSI CALCULATION
    # =================================================
    test_band_report["EXPECTED_POP_%"] = (
        train_band_report["POPULATION_%"].values
    )

    test_band_report["PSI"] = (

        (

            test_band_report["EXPECTED_POP_%"]

            -

            test_band_report["POPULATION_%"]

        )

        *

        np.log(

            (test_band_report["EXPECTED_POP_%"] + 1e-10)

            /

            (test_band_report["POPULATION_%"] + 1e-10)

        )
    )

    total_psi = test_band_report["PSI"].sum()

    # =================================================
    # PRINT METRICS
    # =================================================
    print("\n========== TRAIN METRICS ==========")

    print({
        "AUC": round(train_auc, 4),
        "GINI": round(train_gini, 4),
        "KS": round(train_ks, 4)
    })

    print("\n========== TEST METRICS ==========")

    print({
        "AUC": round(test_auc, 4),
        "GINI": round(test_gini, 4),
        "KS": round(test_ks, 4)
    })

    print("\n========== PSI ==========")

    print(
        f"TOTAL PSI : {round(total_psi,4)}"
    )

    # =================================================
    # COEFFICIENTS
    # =================================================
    coef_df = pd.DataFrame({
    
        "VARIABLE":
            final_model.params.index,
    
        "COEF":
            final_model.params.values,
    
        "P_VALUE":
            final_model.pvalues.values
    
    })
    
    coef_df["SIGN"] = np.where(coef_df["COEF"] >= 0, "POSITIVE", "NEGATIVE")

    coef_print = coef_df.merge(final_vif, on="VARIABLE", how="left")
    coef_print["VIF"] = coef_print["VIF"].round(3)
    
    print("\n========== FINAL MODEL ==========")
    print(coef_print.round({"COEF":6, "P_VALUE":6, "VIF":3}))

    coef_map=dict(zip(coef_df["VARIABLE"],coef_df["COEF"]))

    if coarse_rules is not None:

        scorecard_table,variable_summary=build_scorecard_table(
            coarse_rules=coarse_rules,
            coef_df=coef_df,
            iv_map=iv_map,
            pdo=pdo
        )
    
    else:
    
        scorecard_table=pd.DataFrame()
        variable_summary=pd.DataFrame()

########################################################
# EXPORT SCORED DATASETS
########################################################

    train_export=None
    test_export=None
    
    if export_mode.lower()!="none":
    
        if export_format.lower() not in ["csv","xlsx"]:
    
            raise ValueError(
                "export_format must be "
                "'csv' or 'xlsx'"
            )
    
        if (
            train_source_df is None
            or
            test_source_df is None
        ):
    
            raise ValueError(
                "train_source_df and test_source_df "
                "must be supplied when export_mode "
                "is not 'none'"
            )
    
        import os
    
        os.makedirs(export_folder,exist_ok=True)
    
        ####################################################
        # FINAL VARIABLES ONLY
        ####################################################
    
        if export_mode.lower()=="final":
        
            export_cols=[]
        
            if key_col in train_source_df.columns:
                export_cols.append(key_col)
        
            if target in train_source_df.columns:
                export_cols.append(target)
    
            for woe_var in variables:
    
                base_var=woe_var.replace(
                    "_COARSE_WOE",
                    ""
                )
    
                bin_var=base_var+"_COARSE_BIN"
    
                if base_var in train_source_df.columns:
                    export_cols.append(base_var)
    
                if bin_var in train_source_df.columns:
                    export_cols.append(bin_var)
    
                if woe_var in train_source_df.columns:
                    export_cols.append(woe_var)
    
            export_cols=list(dict.fromkeys(export_cols))

            train_export=train_source_df[export_cols].copy()            
            test_export=test_source_df[export_cols].copy()
    
        ####################################################
        # ALL VARIABLES
        ####################################################
    
        elif export_mode.lower()=="all":
    
            train_export=train_source_df.copy()
    
            test_export=test_source_df.copy()
    
        ####################################################
        # INVALID OPTION
        ####################################################
    
        else:
    
            raise ValueError(
                "export_mode must be "
                "'none', 'final' or 'all'"
            )
    
        ####################################################
        # APPEND MODEL OUTPUTS
        ####################################################
    
        train_export=pd.concat(
            [
                train_export,
    
                train_output[
                    [
                        "PD",
                        "PD_BAND",
                        "SCORE",
                        "SCORE_BAND"
                    ]
                ]
            ],
            axis=1
        )
    
        test_export=pd.concat(
            [
                test_export,
    
                test_output[
                    [
                        "PD",
                        "PD_BAND",
                        "SCORE",
                        "SCORE_BAND"
                    ]
                ]
            ],
            axis=1
        )

    
        if export_format.lower()=="csv":
            train_export.to_csv(os.path.join(export_folder,"Train_Scored_Dataset.csv"),index=False)
            test_export.to_csv(os.path.join(export_folder,"Test_Scored_Dataset.csv"),index=False)
        
        elif export_format.lower()=="xlsx":
            train_export.to_excel(os.path.join(export_folder,"Train_Scored_Dataset.xlsx"),index=False)
            test_export.to_excel(os.path.join(export_folder,"Test_Scored_Dataset.xlsx"),index=False)
        
        else:
            raise ValueError("export_format must be 'csv' or 'xlsx'")

# =================================================
# RESULTS
# =================================================

    results = {      
        "model": final_model,    
        "coefficients": coef_df,    
        "train_band_report": train_band_report,    
        "test_band_report": test_band_report,    
        "train_data": train_output,    
        "test_data": test_output,
        "train_data_full":train_export,
        "test_data_full":test_export,    
        "train_probabilities": train_pred,    
        "test_probabilities": test_pred,
        "scorecard_table":scorecard_table,
        "variable_summary":variable_summary,    
        "vif_removed": pd.DataFrame(dropped_vif),    
        "stepwise_removed": pd.DataFrame(dropped_stepwise),    
        "final_variables": variables,
        "vif_after_filtering":vif_after_filtering,
        "final_vif": final_vif,    
        "train_metrics": {    
            "AUC":round(train_auc,4),    
            "GINI":round(train_gini,4),    
            "KS":round(train_ks,4)},
    
        "test_metrics": {    
            "AUC":round(test_auc,4),    
            "GINI":round(test_gini,4),    
            "KS":round(test_ks,4)},
    
        "total_psi":round(total_psi,4),    
        "bin_edges":bin_edges    
    }
    
    # =================================================
    # SAVE OUTPUT
    # =================================================
    
    if save_output:
    
        save_model_report(
    
            results=results,
    
            output_file=output_file
    
        )
    
        save_model(
    
            final_model,
    
            "FinalModel.pkl"
    
        )
    
        save_model_metadata(
            variables=variables,
            bin_edges=bin_edges,
            development_distribution=train_band_report["POPULATION_%"].tolist(),
            score_band_mapping=mapping,
            score_band_table=score_band_table,
            min_score=min_score,
            max_score=max_score,
            base_score=base_score,
            base_odds=base_odds,
            pdo=pdo,
            coefficients=coef_map,
            file_path="ModelMetadata.pkl"
        )
    return results
        

### Save Report

def save_model_report(
        results,
        output_file="Model_Report.xlsx"
):

    import pandas as pd

    with pd.ExcelWriter(
        output_file,
        engine="openpyxl"
    ) as writer:

        # ======================================
        # MODEL SUMMARY
        # ======================================

        summary_df = pd.DataFrame({

            "METRIC": [

                "TRAIN_AUC",
                "TRAIN_GINI",
                "TRAIN_KS",

                "TEST_AUC",
                "TEST_GINI",
                "TEST_KS",

                "TOTAL_PSI",

                "NO_OF_FINAL_VARIABLES"

            ],

            "VALUE": [

                results["train_metrics"]["AUC"],
                results["train_metrics"]["GINI"],
                results["train_metrics"]["KS"],

                results["test_metrics"]["AUC"],
                results["test_metrics"]["GINI"],
                results["test_metrics"]["KS"],

                results["total_psi"],

                len(results["final_variables"])

            ]

        })

        summary_df.to_excel(
            writer,
            sheet_name="MODEL_SUMMARY",
            index=False,
            startrow=0
        )

        # ======================================
        # FINAL VARIABLES
        # ======================================

        pd.DataFrame({

            "VARIABLE":
                results["final_variables"]

        }).to_excel(

            writer,

            sheet_name="MODEL_SUMMARY",

            index=False,

            startrow=len(summary_df) + 3

        )

        # ======================================
        # COEFFICIENTS + VIF
        # ======================================

        coef_df = results[
            "coefficients"
        ].merge(

            results["final_vif"],

            on="VARIABLE",

            how="left"

        )

        coef_df.to_excel(

            writer,

            sheet_name="MODEL_SUMMARY",

            index=False,

            startrow=len(summary_df)
                     + len(results["final_variables"])
                     + 8

        )

        # ======================================
        # VIF REMOVED
        # ======================================

        results[
            "vif_removed"
        ].to_excel(

            writer,

            sheet_name="MODEL_SUMMARY",

            index=False,

            startrow=len(summary_df)
                     + len(results["final_variables"])
                     + len(coef_df)
                     + 15

        )

        # ======================================
        # STEPWISE REMOVED
        # ======================================

        results[
            "stepwise_removed"
        ].to_excel(

            writer,

            sheet_name="MODEL_SUMMARY",

            index=False,

            startrow=len(summary_df)
                     + len(results["final_variables"])
                     + len(coef_df)
                     + len(results["vif_removed"])
                     + 22

        )

        # ======================================
        # BANDING REPORT
        # ======================================

        results[
            "train_band_report"
        ].to_excel(

            writer,

            sheet_name="BANDING_REPORT",

            index=False,

            startrow=0

        )

        test_start_row = (
            len(
                results["train_band_report"]
            )
            + 4
        )

        results[
            "test_band_report"
        ].to_excel(

            writer,

            sheet_name="BANDING_REPORT",

            index=False,

            startrow=test_start_row

        )

        psi_row = (
            test_start_row
            +
            len(
                results["test_band_report"]
            )
            +
            3
        )

        pd.DataFrame({

            "METRIC": [
                "TOTAL_PSI"
            ],

            "VALUE": [
                results["total_psi"]
            ]

        }).to_excel(

            writer,

            sheet_name="BANDING_REPORT",

            index=False,

            startrow=psi_row

        )

        # ======================================
        # TRAIN SCORED
        # ======================================

        results[
            "train_data"
        ].to_excel(

            writer,

            sheet_name="TRAIN_SCORED",

            index=False

        )

        # ======================================
        # TEST SCORED
        # ======================================

        results[
            "test_data"
        ].to_excel(
        
            writer,
        
            sheet_name="TEST_SCORED",
        
            index=False
        
        )

        results["variable_summary"].to_excel(writer,sheet_name="VARIABLE_SUMMARY",index=False)
        results["scorecard_table"].to_excel(writer,sheet_name="SCORECARD",index=False)

        

import pickle


def save_model(
        model,
        file_path
):

    with open(file_path, "wb") as f:

        pickle.dump(
            model,
            f
        )


def load_model(
        file_path
):

    with open(file_path, "rb") as f:

        model = pickle.load(f)

    return model


def save_model_metadata(
    variables,
    bin_edges,
    development_distribution,
    score_band_mapping,
    score_band_table,
    min_score,
    max_score,
    base_score,
    base_odds,
    pdo,
    coefficients,
    file_path
):

    metadata={

        "variables":variables,

        "bin_edges":bin_edges,

        "development_distribution":development_distribution,

        "score_band_mapping":score_band_mapping,

        "score_band_table":score_band_table,

        "min_score":min_score,

        "max_score":max_score,

        "base_score":base_score,

        "base_odds":base_odds,

        "pdo":pdo,

        "coefficients":coefficients

    }

    with open(file_path,"wb") as f:

        pickle.dump(metadata,f)


def load_model_metadata(
        file_path
):

    with open(file_path, "rb") as f:

        metadata = pickle.load(f)

    return metadata

#############################################################
# Scorecard & Variable Sheets
#############################################################

def build_scorecard_table(coarse_rules,coef_df,iv_map,pdo=20):

    factor=pdo/np.log(2)
    iv_map = iv_map or {}

    coef_map=dict(zip(coef_df["VARIABLE"],coef_df["COEF"]))
    
    scorecard=[]
    summary=[]

    for var,info in coarse_rules.items():

        model_var=var+"_COARSE_WOE"

        if model_var not in coef_map:
            continue

        coef=coef_map[model_var]
        
        rules=info["RULES"].copy()
        
        if "WOE" not in rules.columns:
            continue
        
        iv=iv_map.get(var,0)
        
        rules["VARIABLE"]=var
        rules["COEF"]=coef
        rules["IV"]=iv
        
        rules["BIN_POINTS"]=(
            -coef
            *
            rules["WOE"]
            *
            factor
        ).round(0)
        
        score_spread=(
            rules["BIN_POINTS"].max()
            -
            rules["BIN_POINTS"].min()
        )
        
        importance=abs(coef)*iv
        
        summary.append({
            "VARIABLE":var,
            "COEF":coef,
            "IV":iv,
            "IMPORTANCE_RAW":importance,
            "SCORE_SPREAD":score_spread
        })
        
        scorecard.append(rules)

    if scorecard:
        scorecard=pd.concat(scorecard,ignore_index=True)
    else:
        scorecard=pd.DataFrame()

    variable_summary=pd.DataFrame(summary)

    if variable_summary.empty:
        return scorecard, variable_summary

    total_importance = variable_summary["IMPORTANCE_RAW"].sum()
    if total_importance > 0:
        variable_summary["IMPORTANCE_%"] = (
            variable_summary["IMPORTANCE_RAW"] / total_importance * 100
        )
        variable_summary["RANK"] = (
            variable_summary["IMPORTANCE_%"]
            .rank(ascending=False, method="dense")
            .astype("Int64")
        )
    else:
        variable_summary["IMPORTANCE_%"] = 0.0
        variable_summary["RANK"] = pd.Series(pd.NA, index=variable_summary.index, dtype="Int64")

    variable_summary=variable_summary.sort_values(
        "RANK"
    )

    return scorecard,variable_summary
