import pandas as pd
import numpy as np
import statsmodels.api as sm
from . import Fine_Classing as fc
from . import Coarse_Classing as cc
from . import Binning_Rules as rules
from . import CSI as csi
from . import Modelling as mdl
from sklearn.metrics import (roc_auc_score,roc_curve)
from .Modelling import (load_model,load_model_metadata)
# from Loading_Fine_and_Coarse_Rules_and_Coarse_Binning import (apply_coarse_binning)

def deploy_model(df,
                 coarse_rules_path,
                 model_path,
                 metadata_path,
                 target_available=False,
                 target="Default",
                 key_col="PROSPECTID",
                 save_output=True,
                 output_file="Validation_Report.xlsx"):

    # =====================================
    # LOAD ARTIFACTS
    # =====================================

    coarse_rules = rules.load_coarse_rules(coarse_rules_path)
    model = mdl.load_model(model_path)
    metadata = mdl.load_model_metadata(metadata_path)

    # =====================================
    # APPLY COARSE RULES
    # =====================================

    scored_df = cc.apply_coarse_binning(df=df,coarse_rules=coarse_rules,return_woe=True)

    # =====================================
    # BUILD MODEL DATASET
    # =====================================

    variables = metadata["variables"]

    missing_variables = [variable for variable in variables if variable not in scored_df.columns]
    if missing_variables:
        raise ValueError(f"Model variables missing after binning: {missing_variables}")

    if scored_df[variables].isna().any().any():
        null_variables = scored_df[variables].columns[scored_df[variables].isna().any()].tolist()
        raise ValueError(f"Missing WOE values after binning: {null_variables}")

    X = (scored_df[variables].astype(float))

    X = sm.add_constant(X,has_constant="add")

    # =====================================
    # SCORE PD
    # =====================================

    scored_df["PD"] = model.predict(X)

    scored_df["SCORE"]=mdl.calculate_score(
        scored_df["PD"],
        min_score=metadata["min_score"],
        max_score=metadata["max_score"],
        base_score=metadata["base_score"],
        base_odds=metadata["base_odds"],
        pdo=metadata["pdo"]
    )

    # =====================================
    # APPLY DEVELOPMENT BANDS
    # =====================================

    bin_edges = np.asarray(metadata["bin_edges"], dtype=float).copy()
    if len(bin_edges) < 2:
        raise ValueError("Model metadata contains invalid PD band edges")
    bin_edges[0] = -np.inf
    bin_edges[-1] = np.inf

    scored_df["PD_BAND"] = pd.cut(scored_df["PD"],bins=bin_edges,include_lowest=True)
    scored_df["SCORE_BAND"]=(scored_df["PD_BAND"].map(metadata["score_band_mapping"]))

    # =====================================
    # BAND DISTRIBUTION
    # =====================================

    band_report = (scored_df.groupby("PD_BAND",observed=False).size().reset_index(name="TOTAL"))
    band_report["SCORE_BAND"] = (band_report["PD_BAND"].map(metadata["score_band_mapping"]))
    band_report["POPULATION_%"] = (band_report["TOTAL"]/band_report["TOTAL"].sum())

    # =====================================
    # PSI
    # =====================================

    band_report["EXPECTED_POP_%"] = (

        metadata[
            "development_distribution"
        ]

    )

    band_report["PSI"] = (

        (

            band_report[
                "EXPECTED_POP_%"
            ]

            -

            band_report[
                "POPULATION_%"
            ]

        )

        *

        np.log(

            (

                band_report[
                    "EXPECTED_POP_%"
                ]

                + 1e-10

            )

            /

            (

                band_report[
                    "POPULATION_%"
                ]

                + 1e-10

            )

        )

    )

    total_psi = (

        band_report["PSI"]

        .sum()

    )

    # =====================================
    # IF TARGET AVAILABLE
    # =====================================

    metrics = {}

    if target_available:

        auc = roc_auc_score(

            scored_df[target],

            scored_df["PD"]

        )

        gini = (

            2 * auc

            - 1

        )

        fpr,\
        tpr,\
        _ = roc_curve(

            scored_df[target],

            scored_df["PD"]

        )

        ks = np.max(
            np.abs(
                tpr - fpr
            )
        )

        metrics = {

            "AUC":
                round(auc,4),

            "GINI":
                round(gini,4),

            "KS":
                round(ks,4),

            "PSI":
                round(total_psi,4)

        }

        # ==============================
        # EVENT STATS
        # ==============================

        event_report = (
            scored_df
            .groupby(
                "PD_BAND",
                observed=False
            )
            .agg(
                TOTAL=(target,"count"),
                EVENT=(target,"sum")
            )
            .reset_index()
        )
        
        event_report["SCORE_BAND"] = (
            event_report["PD_BAND"]
            .map(metadata["score_band_mapping"])
        )

        event_report["NON_EVENT"] = (

            event_report["TOTAL"]

            -

            event_report["EVENT"]

        )

        event_report["EVENT_RATE"] = (

            event_report["EVENT"]

            /

            event_report["TOTAL"]

        )

        band_report = band_report.merge(
            event_report,
            on=["PD_BAND","SCORE_BAND"],
            how="left"
        )

    else:
        metrics = {"PSI": round(total_psi,4)}
    
    ########################################################
    # KEEP ONLY MODEL VARIABLES
    ########################################################
    
    final_cols=[key_col] if key_col in scored_df.columns else []
    
    if target in scored_df.columns:
        final_cols.append(target)
    
    for woe_var in variables:
    
        base_var = woe_var.replace(
            "_COARSE_WOE",
            ""
        )
    
        bin_var = base_var + "_COARSE_BIN"
    
        if base_var in scored_df.columns:
            final_cols.append(base_var)
    
        if bin_var in scored_df.columns:
            final_cols.append(bin_var)
    
        if woe_var in scored_df.columns:
            final_cols.append(woe_var)
    
    final_cols.extend([
        "PD",
        "PD_BAND",
        "SCORE",
        "SCORE_BAND"
    ])
    
    scored_df = scored_df[
        list(dict.fromkeys(final_cols))
    ].copy()
    
    # =====================================
    # RESULTS
    # =====================================
    
    results = {
        "data": scored_df,
        "band_report": band_report,
        "metrics": metrics,
        "total_psi": round(total_psi,4)
    }
    
    if save_output:
        save_deployment_report(
            results,
            output_file
        )
    
    return results
    
    
##########################################################
### Saving Report in an excel
##########################################################
    
def save_deployment_report(
        results,
        output_file):

    with pd.ExcelWriter(
        output_file,
        engine="openpyxl"
    ) as writer:

        pd.DataFrame(
            results["metrics"].items(),
            columns=["METRIC","VALUE"]
        ).to_excel(
            writer,
            sheet_name="SUMMARY",
            index=False
        )

        results["band_report"].to_excel(
            writer,
            sheet_name="BAND_REPORT",
            index=False
        )

        results["data"].to_excel(
            writer,
            sheet_name="SCORED_DATA",
            index=False
        )
