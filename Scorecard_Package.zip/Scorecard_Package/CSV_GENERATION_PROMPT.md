# Prompt: Generate a synthetic self-employed personal-loan scorecard CSV

Generate and deliver a single model-development CSV file only. Do not provide Python, SQL, notebooks, or implementation code in the response. You may use internal tools to create the file, but the user-facing deliverable must be the completed CSV plus a very short validation summary.

## Business context

The dataset is synthetic/dummy development data for a self-employed personal-loan application scorecard. Exact reproduction of proprietary bureau calculations is not required. Create plausible, internally consistent applicant-level data that can later be used to test binning, WOE/IV, feature selection, logistic-regression scorecard development, validation, PSI/CSI, and reporting pipelines.

## Required dimensions

- Rows: exactly 20,000 applicants, excluding the header row.
- Columns: exactly 1,381.
- The first four columns must be: `custid`, `mrn`, `application_date`, `bad_flag`.
- The remaining 1,377 columns must be the unique bureau variables in the exact order listed in the embedded dictionary below.
- `custid`: unique positive integer.
- `mrn`: unique positive integer application/reference number.
- `application_date`: ISO format `YYYY-MM-DD`, distributed monthly from 2023-01-01 through 2025-12-31.
- `bad_flag`: integer 0 or 1; 1 means bad and 0 means good.

## Target distribution

- Overall bad rate: 12%, with a tolerance of +/-0.25 percentage points.
- Expected bad observations: approximately 2,400.
- Do not make the target a simple deterministic rule.
- Use a noisy latent-risk relationship so higher delinquency, utilization, enquiry intensity, past-due amounts, write-off indicators, and thinner/younger credit history generally increase risk.
- Older clean credit histories, lower utilization, fewer recent enquiries, and lower delinquency generally reduce risk.
- Avoid perfect separation and target leakage. No single feature should reproduce `bad_flag` exactly.
- Keep monthly bad rates reasonably stable but allow mild realistic drift; no month should have a wildly implausible bad rate solely because of random sampling.

## Synthetic-data rules

1. Generate one row per applicant/application, not one row per tradeline or enquiry.
2. Retain every required bureau variable even when its exact source definition is unavailable.
3. Generate logically related variables together rather than drawing every column independently.
4. Enforce identities and monotonic relationships where applicable, for example:
   - open trades <= total trades;
   - recent trade counts <= lifetime trade counts;
   - 90+ DPD counts <= 60+ DPD counts <= 30+ DPD counts where definitions share the same population/window;
   - product-level balances/counts should broadly reconcile with aggregate balances/counts;
   - past-due amounts should usually be zero for clean borrowers;
   - utilization ratios should be consistent with balance and credit-line variables;
   - ?months since? variables should be non-negative when an event exists;
   - longer-window counts should generally be >= shorter-window counts;
   - M01-M24 series should show plausible persistence and gradual movement rather than independent noise.
5. Use plausible self-employed personal-loan population characteristics:
   - a mixture of thin-file, medium-file, and mature-file borrowers;
   - secured and unsecured borrowing;
   - personal loans, business loans, bankcards, auto/two-wheeler loans, gold loans, retail and mortgage exposure;
   - realistic zero inflation for rare derogatory events.
6. Use integer values for counts, flags, scores, DPD measures, and months-since fields unless the description clearly indicates a percentage, ratio, amount, average, or index.
7. Monetary fields must be non-negative unless the variable convention explicitly requires a special value.
8. Percentages may use either 0-100 or ratios may use 0-1, but apply the convention consistently based on the description and variable family.
9. Add realistic missingness without destroying usability:
   - overall missingness should generally be modest;
   - demographic/contact variables may have higher missingness;
   - use empty CSV fields for unavailable values;
   - do not use text values such as `NULL` in numeric columns.
10. Do not add any column that is not in the required schema.
11. Do not omit or rename any listed variable.
12. Preserve the exact capitalization of every variable name.
13. Ensure the CSV is UTF-8 encoded and has a single header row.
14. Quote fields only as required by standard CSV formatting.
15. Use a fixed random seed so regeneration is reproducible.

## Validation required before delivery

Confirm all of the following:

- Shape is exactly 20,000 rows x 1,381 columns, excluding the header from the row count.
- All 1,377 unique bureau variables are present exactly once.
- No unexpected columns or duplicated headers exist.
- `custid` and `mrn` are unique and non-missing.
- `bad_flag` contains only 0 and 1.
- Overall bad rate is within 11.75%-12.25%.
- No numeric field contains infinity.
- Count fields do not contain negative ordinary values.
- Major cross-field consistency rules pass.
- The file can be read back successfully as a CSV.

The source dictionary originally contained 1,379 rows. `G242B` and `RE30S` were duplicated, so each is included once, producing 1,377 unique bureau variables.

## Reference raw bureau schemas

These raw headers are included only to explain the conceptual source structure. Do not add them separately to the final applicant-level CSV unless a name is already present in the required output dictionary.

### Tradeline-level headers

`custid`, `mrn`, `input_date`, `run_date`, `report_dt`, `owner_indic`, `cur_balance`, `close_dt`, `short_name`, `Member class`, `acct_num`, `acct_type`, `LIVE_CLOSED`, `PRODUCT_FLAG`, `opened_dt`, `high_credit`, `amt_past_due`, `pmt_start_dt`, `pmt_end_dt`, `suit_filed`, `wo_settled`, `credit_limit`, `Credit_vintage`, `Credit Utilization`, `int_rate`, `wo_amt_total`, `wo_amt_principal`, `repay_tenure`, `tenure Flag`, `emi_amt_int`, `paymt_freq`, `last_pmt_dt`, `collataral_type`, `p_hist_01`, `p_hist_02`, `p_hist_03`, `p_hist_04`, `p_hist_05`, `p_hist_06`, `p_hist_07`, `p_hist_08`, `p_hist_09`, `p_hist_10`, `p_hist_11`, `p_hist_12`, `p_hist_13`, `p_hist_14`, `p_hist_15`, `p_hist_16`, `p_hist_17`, `p_hist_18`, `p_hist_19`, `p_hist_20`, `p_hist_21`, `p_hist_22`, `p_hist_23`, `p_hist_24`, `p_hist_25`, `p_hist_26`, `p_hist_27`, `p_hist_28`, `p_hist_29`, `p_hist_30`, `p_hist_31`, `p_hist_32`, `p_hist_33`, `p_hist_34`, `p_hist_35`, `p_hist_36`, `Max hist`, `Month Since30+`, `Month Since60+`, `Month Since90+`, `First Month Since30+`, `First Month Since60+`, `First Month Since90+`, `v3_score`, `onus_sp`, `onus_sp_3mob_at_30`, `onus_sp_6mob_at_30`, `onus_sp_9mob_at_30`, `onus_sp_12mob_at_30`, `onus_sp_15mob_at_30`, `onus_sp_18mob_at_30`, `onus_sp_24mob_at_30`, `onus_sp_3mob_at_60`, `onus_sp_6mob_at_60`, `onus_sp_9mob_at_60`, `onus_sp_12mob_at_60`, `onus_sp_15mob_at_60`, `onus_sp_18mob_at_60`, `onus_sp_24mob_at_60`, `onus_sp_3mob_at_90`, `onus_sp_6mob_at_90`, `onus_sp_9mob_at_90`, `onus_sp_12mob_at_90`, `onus_sp_15mob_at_90`, `onus_sp_18mob_at_90`, `onus_sp_24mob_at_90`, `onus_sp_3mob_at_120`, `onus_sp_6mob_at_120`, `onus_sp_9mob_at_120`, `onus_sp_12mob_at_120`, `onus_sp_15mob_at_120`, `onus_sp_18mob_at_120`, `onus_sp_24mob_at_120`, `onus_op`, `onus_op_3mob_at_30`, `onus_op_6mob_at_30`, `onus_op_9mob_at_30`, `onus_op_12mob_at_30`, `onus_op_15mob_at_30`, `onus_op_18mob_at_30`, `onus_op_24mob_at_30`, `onus_op_3mob_at_60`, `onus_op_6mob_at_60`, `onus_op_9mob_at_60`, `onus_op_12mob_at_60`, `onus_op_15mob_at_60`, `onus_op_18mob_at_60`, `onus_op_24mob_at_60`, `onus_op_3mob_at_90`, `onus_op_6mob_at_90`, `onus_op_9mob_at_90`, `onus_op_12mob_at_90`, `onus_op_15mob_at_90`, `onus_op_18mob_at_90`, `onus_op_24mob_at_90`, `onus_op_3mob_at_120`, `onus_op_6mob_at_120`, `onus_op_9mob_at_120`, `onus_op_12mob_at_120`, `onus_op_15mob_at_120`, `onus_op_18mob_at_120`, `onus_op_24mob_at_120`, `offus_sp`, `offus_sp_3mob_at_30`, `offus_sp_6mob_at_30`, `offus_sp_9mob_at_30`, `offus_sp_12mob_at_30`, `offus_sp_15mob_at_30`, `offus_sp_18mob_at_30`, `offus_sp_24mob_at_30`, `offus_sp_3mob_at_60`, `offus_sp_6mob_at_60`, `offus_sp_9mob_at_60`, `offus_sp_12mob_at_60`, `offus_sp_15mob_at_60`, `offus_sp_18mob_at_60`, `offus_sp_24mob_at_60`, `offus_sp_3mob_at_90`, `offus_sp_6mob_at_90`, `offus_sp_9mob_at_90`, `offus_sp_12mob_at_90`, `offus_sp_15mob_at_90`, `offus_sp_18mob_at_90`, `offus_sp_24mob_at_90`, `offus_sp_3mob_at_120`, `offus_sp_6mob_at_120`, `offus_sp_9mob_at_120`, `offus_sp_12mob_at_120`, `offus_sp_15mob_at_120`, `offus_sp_18mob_at_120`, `offus_sp_24mob_at_120`, `offus_op`, `offus_op_3mob_at_30`, `offus_op_6mob_at_30`, `offus_op_9mob_at_30`, `offus_op_12mob_at_30`, `offus_op_15mob_at_30`, `offus_op_18mob_at_30`, `offus_op_24mob_at_30`, `offus_op_3mob_at_60`, `offus_op_6mob_at_60`, `offus_op_9mob_at_60`, `offus_op_12mob_at_60`, `offus_op_15mob_at_60`, `offus_op_18mob_at_60`, `offus_op_24mob_at_60`, `offus_op_3mob_at_90`, `offus_op_6mob_at_90`, `offus_op_9mob_at_90`, `offus_op_12mob_at_90`, `offus_op_15mob_at_90`, `offus_op_18mob_at_90`, `offus_op_24mob_at_90`, `offus_op_3mob_at_120`, `offus_op_6mob_at_120`, `offus_op_9mob_at_120`, `offus_op_12mob_at_120`, `offus_op_15mob_at_120`, `offus_op_18mob_at_120`, `offus_op_24mob_at_120`

### Enquiry-level headers

`custid`, `mrn`, `input_date`, `run_date`, `short_name`, `ecn`, `enq_date`, `enq_purpose`, `enq_amt`

## Required bureau-variable dictionary

| Position | Variable | Description |
|---:|---|---|
| 1 | `AGG1002` | Aggregate unsecured loan balance at month M = 02 |
| 2 | `AGG1003` | Aggregate unsecured loan balance at month M = 03 |
| 3 | `AGG1004` | Aggregate unsecured loan balance at month M = 04 |
| 4 | `AGG1005` | Aggregate unsecured loan balance at month M = 05 |
| 5 | `AGG1006` | Aggregate unsecured loan balance at month M = 06 |
| 6 | `AGG1007` | Aggregate unsecured loan balance at month M = 07 |
| 7 | `AGG1008` | Aggregate unsecured loan balance at month M = 08 |
| 8 | `AGG1009` | Aggregate unsecured loan balance at month M = 09 |
| 9 | `AGG101` | Aggregate financial non-mortgage balance at month M = 01 |
| 10 | `AGG1010` | Aggregate unsecured loan balance at month M = 10 |
| 11 | `AGG1011` | Aggregate unsecured loan balance at month M = 11 |
| 12 | `AGG1012` | Aggregate unsecured loan balance at month M = 12 |
| 13 | `AGG1013` | Aggregate unsecured loan balance at month M = 13 |
| 14 | `AGG1014` | Aggregate unsecured loan balance at month M = 14 |
| 15 | `AGG1015` | Aggregate unsecured loan balance at month M = 15 |
| 16 | `AGG1016` | Aggregate unsecured loan balance at month M = 16 |
| 17 | `AGG1017` | Aggregate unsecured loan balance at month M = 17 |
| 18 | `AGG1018` | Aggregate unsecured loan balance at month M = 18 |
| 19 | `AGG1019` | Aggregate unsecured loan balance at month M = 19 |
| 20 | `AGG102` | Aggregate financial non-mortgage balance at month M = 02 |
| 21 | `AGG1020` | Aggregate unsecured loan balance at month M = 20 |
| 22 | `AGG1021` | Aggregate unsecured loan balance at month M = 21 |
| 23 | `AGG1023` | Aggregate unsecured loan balance at month M = 23 |
| 24 | `AGG1024` | Aggregate unsecured loan balance at month M = 24 |
| 25 | `AGG103` | Aggregate financial non-mortgage balance at month M = 03 |
| 26 | `AGG104` | Aggregate financial non-mortgage balance at month M = 04 |
| 27 | `AGG105` | Aggregate financial non-mortgage balance at month M = 05 |
| 28 | `AGG106` | Aggregate financial non-mortgage balance at month M = 06 |
| 29 | `AGG107` | Aggregate financial non-mortgage balance at month M = 07 |
| 30 | `AGG108` | Aggregate financial non-mortgage balance at month M = 08 |
| 31 | `AGG109` | Aggregate financial non-mortgage balance at month M = 09 |
| 32 | `AGG110` | Aggregate financial non-mortgage balance at month M = 10 |
| 33 | `AGG1101` | Aggregate unsecured loan credit line at month M = 01 |
| 34 | `AGG1102` | Aggregate unsecured loan credit line at month M = 02 |
| 35 | `AGG1103` | Aggregate unsecured loan credit line at month M = 03 |
| 36 | `AGG1104` | Aggregate unsecured loan credit line at month M = 04 |
| 37 | `AGG1105` | Aggregate unsecured loan credit line at month M = 05 |
| 38 | `AGG1106` | Aggregate unsecured loan credit line at month M = 06 |
| 39 | `AGG1107` | Aggregate unsecured loan credit line at month M = 07 |
| 40 | `AGG1108` | Aggregate unsecured loan credit line at month M = 08 |
| 41 | `AGG1109` | Aggregate unsecured loan credit line at month M = 09 |
| 42 | `AGG111` | Aggregate financial non-mortgage balance at month M = 11 |
| 43 | `AGG1110` | Aggregate unsecured loan credit line at month M = 10 |
| 44 | `AGG1111` | Aggregate unsecured loan credit line at month M = 11 |
| 45 | `AGG1112` | Aggregate unsecured loan credit line at month M = 12 |
| 46 | `AGG1113` | Aggregate unsecured loan credit line at month M = 13 |
| 47 | `AGG1114` | Aggregate unsecured loan credit line at month M = 14 |
| 48 | `AGG1115` | Aggregate unsecured loan credit line at month M = 15 |
| 49 | `AGG1116` | Aggregate unsecured loan credit line at month M = 16 |
| 50 | `AGG1117` | Aggregate unsecured loan credit line at month M = 17 |
| 51 | `AGG1118` | Aggregate unsecured loan credit line at month M = 18 |
| 52 | `AGG1119` | Aggregate unsecured loan credit line at month M = 19 |
| 53 | `AGG112` | Aggregate financial non-mortgage balance at month M = 12 |
| 54 | `AGG1120` | Aggregate unsecured loan credit line at month M = 20 |
| 55 | `AGG1121` | Aggregate unsecured loan credit line at month M = 21 |
| 56 | `AGG1122` | Aggregate unsecured loan credit line at month M = 22 |
| 57 | `AGG1123` | Aggregate unsecured loan credit line at month M = 23 |
| 58 | `AGG1124` | Aggregate unsecured loan credit line at month M = 24 |
| 59 | `AGG113` | Aggregate financial non-mortgage balance at month M = 13 |
| 60 | `AGG114` | Aggregate financial non-mortgage balance at month M = 14 |
| 61 | `AGG115` | Aggregate financial non-mortgage balance at month M = 15 |
| 62 | `AGG116` | Aggregate financial non-mortgage balance at month M = 16 |
| 63 | `AGG117` | Aggregate financial non-mortgage balance at month M = 17 |
| 64 | `AGG118` | Aggregate financial non-mortgage balance at month M = 18 |
| 65 | `AGG119` | Aggregate financial non-mortgage balance at month M = 19 |
| 66 | `AGG120` | Aggregate financial non-mortgage balance at month M = 20 |
| 67 | `AGG1201` | Aggregate unsecured loan amount past due at month M = 01 |
| 68 | `AGG1202` | Aggregate unsecured loan amount past due at month M = 02 |
| 69 | `AGG1203` | Aggregate unsecured loan amount past due at month M = 03 |
| 70 | `AGG1204` | Aggregate unsecured loan amount past due at month M = 04 |
| 71 | `AGG1205` | Aggregate unsecured loan amount past due at month M = 05 |
| 72 | `AGG1206` | Aggregate unsecured loan amount past due at month M = 06 |
| 73 | `AGG1207` | Aggregate unsecured loan amount past due at month M = 07 |
| 74 | `AGG1208` | Aggregate unsecured loan amount past due at month M = 08 |
| 75 | `AGG1209` | Aggregate unsecured loan amount past due at month M = 09 |
| 76 | `AGG121` | Aggregate financial non-mortgage balance at month M = 21 |
| 77 | `AGG1210` | Aggregate unsecured loan amount past due at month M = 10 |
| 78 | `AGG1211` | Aggregate unsecured loan amount past due at month M = 11 |
| 79 | `AGG1212` | Aggregate unsecured loan amount past due at month M = 12 |
| 80 | `AGG1213` | Aggregate unsecured loan amount past due at month M = 13 |
| 81 | `AGG1214` | Aggregate unsecured loan amount past due at month M = 14 |
| 82 | `AGG1215` | Aggregate unsecured loan amount past due at month M = 15 |
| 83 | `AGG1216` | Aggregate unsecured loan amount past due at month M = 16 |
| 84 | `AGG1217` | Aggregate unsecured loan amount past due at month M = 17 |
| 85 | `AGG1218` | Aggregate unsecured loan amount past due at month M = 18 |
| 86 | `AGG1219` | Aggregate unsecured loan amount past due at month M = 19 |
| 87 | `AGG122` | Aggregate financial non-mortgage balance at month M = 22 |
| 88 | `AGG1220` | Aggregate unsecured loan amount past due at month M = 20 |
| 89 | `AGG1221` | Aggregate unsecured loan amount past due at month M = 21 |
| 90 | `AGG1222` | Aggregate unsecured loan amount past due at month M = 22 |
| 91 | `AGG1223` | Aggregate unsecured loan amount past due at month M = 23 |
| 92 | `AGG1224` | Aggregate unsecured loan amount past due at month M = 24 |
| 93 | `AGG123` | Aggregate financial non-mortgage balance at month M = 23 |
| 94 | `AGG124` | Aggregate financial non-mortgage balance at month M = 24 |
| 95 | `AGG1301` | Aggregate unsecured loan actual payment amount at month M = 01 |
| 96 | `AGG1302` | Aggregate unsecured loan actual payment amount at month M = 02 |
| 97 | `AGG1303` | Aggregate unsecured loan actual payment amount at month M = 03 |
| 98 | `AGG1304` | Aggregate unsecured loan actual payment amount at month M = 04 |
| 99 | `AGG1305` | Aggregate unsecured loan actual payment amount at month M = 05 |
| 100 | `AGG1306` | Aggregate unsecured loan actual payment amount at month M = 06 |
| 101 | `AGG1307` | Aggregate unsecured loan actual payment amount at month M = 07 |
| 102 | `AGG1308` | Aggregate unsecured loan actual payment amount at month M = 08 |
| 103 | `AGG1309` | Aggregate unsecured loan actual payment amount at month M = 09 |
| 104 | `AGG1310` | Aggregate unsecured loan actual payment amount at month M = 10 |
| 105 | `AGG1311` | Aggregate unsecured loan actual payment amount at month M = 11 |
| 106 | `AGG1312` | Aggregate unsecured loan actual payment amount at month M = 12 |
| 107 | `AGG1313` | Aggregate unsecured loan actual payment amount at month M = 13 |
| 108 | `AGG1314` | Aggregate unsecured loan actual payment amount at month M = 14 |
| 109 | `AGG1315` | Aggregate unsecured loan actual payment amount at month M = 15 |
| 110 | `AGG1316` | Aggregate unsecured loan actual payment amount at month M = 16 |
| 111 | `AGG1317` | Aggregate unsecured loan actual payment amount at month M = 17 |
| 112 | `AGG1318` | Aggregate unsecured loan actual payment amount at month M = 18 |
| 113 | `AGG1319` | Aggregate unsecured loan actual payment amount at month M = 19 |
| 114 | `AGG1320` | Aggregate unsecured loan actual payment amount at month M = 20 |
| 115 | `AGG1321` | Aggregate unsecured loan actual payment amount at month M = 21 |
| 116 | `AGG1322` | Aggregate unsecured loan actual payment amount at month M = 22 |
| 117 | `AGG1323` | Aggregate unsecured loan actual payment amount at month M = 23 |
| 118 | `AGG1324` | Aggregate unsecured loan actual payment amount at month M = 24 |
| 119 | `AGG201` | Aggregate financial non-mortgage credit line at month M = 01 |
| 120 | `AGG202` | Aggregate financial non-mortgage credit line at month M = 02 |
| 121 | `AGG203` | Aggregate financial non-mortgage credit line at month M = 03 |
| 122 | `AGG204` | Aggregate financial non-mortgage credit line at month M = 04 |
| 123 | `AGG205` | Aggregate financial non-mortgage credit line at month M = 05 |
| 124 | `AGG206` | Aggregate financial non-mortgage credit line at month M = 06 |
| 125 | `AGG207` | Aggregate financial non-mortgage credit line at month M = 07 |
| 126 | `AGG208` | Aggregate financial non-mortgage credit line at month M = 08 |
| 127 | `AGG209` | Aggregate financial non-mortgage credit line at month M = 09 |
| 128 | `AGG210` | Aggregate financial non-mortgage credit line at month M = 10 |
| 129 | `AGG211` | Aggregate financial non-mortgage credit line at month M = 11 |
| 130 | `AGG212` | Aggregate financial non-mortgage credit line at month M = 12 |
| 131 | `AGG213` | Aggregate financial non-mortgage credit line at month M = 13 |
| 132 | `AGG214` | Aggregate financial non-mortgage credit line at month M = 14 |
| 133 | `AGG215` | Aggregate financial non-mortgage credit line at month M = 15 |
| 134 | `AGG216` | Aggregate financial non-mortgage credit line at month M = 16 |
| 135 | `AGG217` | Aggregate financial non-mortgage credit line at month M = 17 |
| 136 | `AGG218` | Aggregate financial non-mortgage credit line at month M = 18 |
| 137 | `AGG219` | Aggregate financial non-mortgage credit line at month M = 19 |
| 138 | `AGG220` | Aggregate financial non-mortgage credit line at month M = 20 |
| 139 | `AGG221` | Aggregate financial non-mortgage credit line at month M = 21 |
| 140 | `AGG222` | Aggregate financial non-mortgage credit line at month M = 22 |
| 141 | `AGG223` | Aggregate financial non-mortgage credit line at month M = 23 |
| 142 | `AGG224` | Aggregate financial non-mortgage credit line at month M = 24 |
| 143 | `AGG301` | Aggregate financial non-mortgage amount past due at month M = 01 |
| 144 | `AGG302` | Aggregate financial non-mortgage amount past due at month M = 02 |
| 145 | `AGG303` | Aggregate financial non-mortgage amount past due at month M = 03 |
| 146 | `AGG304` | Aggregate financial non-mortgage amount past due at month M = 04 |
| 147 | `AGG305` | Aggregate financial non-mortgage amount past due at month M = 05 |
| 148 | `AGG306` | Aggregate financial non-mortgage amount past due at month M = 06 |
| 149 | `AGG307` | Aggregate financial non-mortgage amount past due at month M = 07 |
| 150 | `AGG308` | Aggregate financial non-mortgage amount past due at month M = 08 |
| 151 | `AGG309` | Aggregate financial non-mortgage amount past due at month M = 09 |
| 152 | `AGG310` | Aggregate financial non-mortgage amount past due at month M = 10 |
| 153 | `AGG311` | Aggregate financial non-mortgage amount past due at month M = 11 |
| 154 | `AGG312` | Aggregate financial non-mortgage amount past due at month M = 12 |
| 155 | `AGG313` | Aggregate financial non-mortgage amount past due at month M = 13 |
| 156 | `AGG314` | Aggregate financial non-mortgage amount past due at month M = 14 |
| 157 | `AGG315` | Aggregate financial non-mortgage amount past due at month M = 15 |
| 158 | `AGG316` | Aggregate financial non-mortgage amount past due at month M = 16 |
| 159 | `AGG317` | Aggregate financial non-mortgage amount past due at month M = 17 |
| 160 | `AGG318` | Aggregate financial non-mortgage amount past due at month M = 18 |
| 161 | `AGG319` | Aggregate financial non-mortgage amount past due at month M = 19 |
| 162 | `AGG320` | Aggregate financial non-mortgage amount past due at month M = 20 |
| 163 | `AGG321` | Aggregate financial non-mortgage amount past due at month M = 21 |
| 164 | `AGG322` | Aggregate financial non-mortgage amount past due at month M = 22 |
| 165 | `AGG323` | Aggregate financial non-mortgage amount past due at month M = 23 |
| 166 | `AGG324` | Aggregate financial non-mortgage amount past due at month M = 24 |
| 167 | `AGG401` | Aggregate financial non-mortgage actual payment amount at month M = 01 |
| 168 | `AGG402` | Aggregate financial non-mortgage actual payment amount at month M = 02 |
| 169 | `AGG403` | Aggregate financial non-mortgage actual payment amount at month M = 03 |
| 170 | `AGG404` | Aggregate financial non-mortgage actual payment amount at month M = 04 |
| 171 | `AGG405` | Aggregate financial non-mortgage actual payment amount at month M = 05 |
| 172 | `AGG406` | Aggregate financial non-mortgage actual payment amount at month M = 06 |
| 173 | `AGG407` | Aggregate financial non-mortgage actual payment amount at month M = 07 |
| 174 | `AGG408` | Aggregate financial non-mortgage actual payment amount at month M = 08 |
| 175 | `AGG409` | Aggregate financial non-mortgage actual payment amount at month M = 09 |
| 176 | `AGG410` | Aggregate financial non-mortgage actual payment amount at month M = 10 |
| 177 | `AGG411` | Aggregate financial non-mortgage actual payment amount at month M = 11 |
| 178 | `AGG412` | Aggregate financial non-mortgage actual payment amount at month M = 12 |
| 179 | `AGG413` | Aggregate financial non-mortgage actual payment amount at month M = 13 |
| 180 | `AGG414` | Aggregate financial non-mortgage actual payment amount at month M = 14 |
| 181 | `AGG415` | Aggregate financial non-mortgage actual payment amount at month M = 15 |
| 182 | `AGG416` | Aggregate financial non-mortgage actual payment amount at month M = 16 |
| 183 | `AGG417` | Aggregate financial non-mortgage actual payment amount at month M = 17 |
| 184 | `AGG418` | Aggregate financial non-mortgage actual payment amount at month M = 18 |
| 185 | `AGG419` | Aggregate financial non-mortgage actual payment amount at month M = 19 |
| 186 | `AGG420` | Aggregate financial non-mortgage actual payment amount at month M = 20 |
| 187 | `AGG421` | Aggregate financial non-mortgage actual payment amount at month M = 21 |
| 188 | `AGG422` | Aggregate financial non-mortgage actual payment amount at month M = 22 |
| 189 | `AGG423` | Aggregate financial non-mortgage actual payment amount at month M = 23 |
| 190 | `AGG424` | Aggregate financial non-mortgage actual payment amount at month M = 24 |
| 191 | `AGG501` | Aggregate bankcard balance at month M = 01 |
| 192 | `AGG502` | Aggregate bankcard balance at month M = 02 |
| 193 | `AGG503` | Aggregate bankcard balance at month M = 03 |
| 194 | `AGG504` | Aggregate bankcard balance at month M = 04 |
| 195 | `AGG505` | Aggregate bankcard balance at month M = 05 |
| 196 | `AGG506` | Aggregate bankcard balance at month M = 06 |
| 197 | `AGG507` | Aggregate bankcard balance at month M = 07 |
| 198 | `AGG508` | Aggregate bankcard balance at month M = 08 |
| 199 | `AGG509` | Aggregate bankcard balance at month M = 09 |
| 200 | `AGG510` | Aggregate bankcard balance at month M = 10 |
| 201 | `AGG511` | Aggregate bankcard balance at month M = 11 |
| 202 | `AGG512` | Aggregate bankcard balance at month M = 12 |
| 203 | `AGG513` | Aggregate bankcard balance at month M = 13 |
| 204 | `AGG514` | Aggregate bankcard balance at month M = 14 |
| 205 | `AGG515` | Aggregate bankcard balance at month M = 15 |
| 206 | `AGG516` | Aggregate bankcard balance at month M = 16 |
| 207 | `AGG517` | Aggregate bankcard balance at month M = 17 |
| 208 | `AGG518` | Aggregate bankcard balance at month M = 18 |
| 209 | `AGG519` | Aggregate bankcard balance at month M = 19 |
| 210 | `AGG520` | Aggregate bankcard balance at month M = 20 |
| 211 | `AGG521` | Aggregate bankcard balance at month M = 21 |
| 212 | `AGG522` | Aggregate bankcard balance at month M = 22 |
| 213 | `AGG523` | Aggregate bankcard balance at month M = 23 |
| 214 | `AGG524` | Aggregate bankcard balance at month M = 24 |
| 215 | `AGG601` | Aggregate bankcard credit line at month M = 01 |
| 216 | `AGG602` | Aggregate bankcard credit line at month M = 02 |
| 217 | `AGG603` | Aggregate bankcard credit line at month M = 03 |
| 218 | `AGG604` | Aggregate bankcard credit line at month M = 04 |
| 219 | `AGG605` | Aggregate bankcard credit line at month M = 05 |
| 220 | `AGG606` | Aggregate bankcard credit line at month M = 06 |
| 221 | `AGG607` | Aggregate bankcard credit line at month M = 07 |
| 222 | `AGG608` | Aggregate bankcard credit line at month M = 08 |
| 223 | `AGG609` | Aggregate bankcard credit line at month M = 09 |
| 224 | `AGG610` | Aggregate bankcard credit line at month M = 10 |
| 225 | `AGG611` | Aggregate bankcard credit line at month M = 11 |
| 226 | `AGG612` | Aggregate bankcard credit line at month M = 12 |
| 227 | `AGG613` | Aggregate bankcard credit line at month M = 13 |
| 228 | `AGG614` | Aggregate bankcard credit line at month M = 14 |
| 229 | `AGG615` | Aggregate bankcard credit line at month M = 15 |
| 230 | `AGG616` | Aggregate bankcard credit line at month M = 16 |
| 231 | `AGG617` | Aggregate bankcard credit line at month M = 17 |
| 232 | `AGG618` | Aggregate bankcard credit line at month M = 18 |
| 233 | `AGG619` | Aggregate bankcard credit line at month M = 19 |
| 234 | `AGG620` | Aggregate bankcard credit line at month M = 20 |
| 235 | `AGG621` | Aggregate bankcard credit line at month M = 21 |
| 236 | `AGG622` | Aggregate bankcard credit line at month M = 22 |
| 237 | `AGG623` | Aggregate bankcard credit line at month M = 23 |
| 238 | `AGG624` | Aggregate bankcard credit line at month M = 24 |
| 239 | `AGG701` | Aggregate bankcard amount past due at month M = 01 |
| 240 | `AGG702` | Aggregate bankcard amount past due at month M = 02 |
| 241 | `AGG703` | Aggregate bankcard amount past due at month M = 03 |
| 242 | `AGG704` | Aggregate bankcard amount past due at month M = 04 |
| 243 | `AGG705` | Aggregate bankcard amount past due at month M = 05 |
| 244 | `AGG706` | Aggregate bankcard amount past due at month M = 06 |
| 245 | `AGG707` | Aggregate bankcard amount past due at month M = 07 |
| 246 | `AGG708` | Aggregate bankcard amount past due at month M = 08 |
| 247 | `AGG709` | Aggregate bankcard amount past due at month M = 09 |
| 248 | `AGG710` | Aggregate bankcard amount past due at month M = 10 |
| 249 | `AGG711` | Aggregate bankcard amount past due at month M = 11 |
| 250 | `AGG712` | Aggregate bankcard amount past due at month M = 12 |
| 251 | `AGG713` | Aggregate bankcard amount past due at month M = 13 |
| 252 | `AGG714` | Aggregate bankcard amount past due at month M = 14 |
| 253 | `AGG715` | Aggregate bankcard amount past due at month M = 15 |
| 254 | `AGG716` | Aggregate bankcard amount past due at month M = 16 |
| 255 | `AGG717` | Aggregate bankcard amount past due at month M = 17 |
| 256 | `AGG718` | Aggregate bankcard amount past due at month M = 18 |
| 257 | `AGG719` | Aggregate bankcard amount past due at month M = 19 |
| 258 | `AGG720` | Aggregate bankcard amount past due at month M = 20 |
| 259 | `AGG721` | Aggregate bankcard amount past due at month M = 21 |
| 260 | `AGG722` | Aggregate bankcard amount past due at month M = 22 |
| 261 | `AGG723` | Aggregate bankcard amount past due at month M = 23 |
| 262 | `AGG724` | Aggregate bankcard amount past due at month M = 24 |
| 263 | `AGG801` | Aggregate bankcard actual payment amount at month M = 01 |
| 264 | `AGG802` | Aggregate bankcard actual payment amount at month M = 02 |
| 265 | `AGG803` | Aggregate bankcard actual payment amount at month M = 03 |
| 266 | `AGG804` | Aggregate bankcard actual payment amount at month M = 04 |
| 267 | `AGG805` | Aggregate bankcard actual payment amount at month M = 05 |
| 268 | `AGG806` | Aggregate bankcard actual payment amount at month M = 06 |
| 269 | `AGG807` | Aggregate bankcard actual payment amount at month M = 07 |
| 270 | `AGG808` | Aggregate bankcard actual payment amount at month M = 08 |
| 271 | `AGG809` | Aggregate bankcard actual payment amount at month M = 09 |
| 272 | `AGG810` | Aggregate bankcard actual payment amount at month M = 10 |
| 273 | `AGG811` | Aggregate bankcard actual payment amount at month M = 11 |
| 274 | `AGG812` | Aggregate bankcard actual payment amount at month M = 12 |
| 275 | `AGG813` | Aggregate bankcard actual payment amount at month M = 13 |
| 276 | `AGG814` | Aggregate bankcard actual payment amount at month M = 14 |
| 277 | `AGG815` | Aggregate bankcard actual payment amount at month M = 15 |
| 278 | `AGG816` | Aggregate bankcard actual payment amount at month M = 16 |
| 279 | `AGG817` | Aggregate bankcard actual payment amount at month M = 17 |
| 280 | `AGG818` | Aggregate bankcard actual payment amount at month M = 18 |
| 281 | `AGG819` | Aggregate bankcard actual payment amount at month M = 19 |
| 282 | `AGG820` | Aggregate bankcard actual payment amount at month M = 20 |
| 283 | `AGG821` | Aggregate bankcard actual payment amount at month M = 21 |
| 284 | `AGG822` | Aggregate bankcard actual payment amount at month M = 22 |
| 285 | `AGG823` | Aggregate bankcard actual payment amount at month M = 23 |
| 286 | `AGG824` | Aggregate bankcard actual payment amount at month M = 24 |
| 287 | `AGG901` | Number of non-mortgage aggregate balance increases over the last quarter |
| 288 | `AGG902` | Number of non-mortgage aggregate balance decreases over the last quarter |
| 289 | `AGG903` | Number of non-mortgage aggregate credit line increases over the last quarter |
| 290 | `AGG904` | Number of non-mortgage aggregate credit line decreases over the last quarter |
| 291 | `AGG905` | Aggregate bankcard utilization average over the last 3 mo |
| 292 | `AGG906` | Aggregate bankcard utilization average over the last 12 mo |
| 293 | `AGG907` | Max aggregate bankcard balance over the last 3 months |
| 294 | `AGG908` | Max aggregate bankcard balance over the last 12 months |
| 295 | `AGG909` | Months since max aggregate bankcard balance over the last 12 months |
| 296 | `AGG910` | Max aggregate bankcard utilization over the last 3 months |
| 297 | `AGG9101` | Aggregate balance at month M = 01 |
| 298 | `AGG9102` | Aggregate balance at month M = 02 |
| 299 | `AGG9103` | Aggregate balance at month M = 03 |
| 300 | `AGG9104` | Aggregate balance at month M = 04 |
| 301 | `AGG9105` | Aggregate balance at month M = 05 |
| 302 | `AGG9106` | Aggregate balance at month M = 06 |
| 303 | `AGG9107` | Aggregate balance at month M = 07 |
| 304 | `AGG9108` | Aggregate balance at month M = 08 |
| 305 | `AGG9109` | Aggregate balance at month M = 09 |
| 306 | `AGG911` | Max aggregate bankcard utilization over the last 12 months |
| 307 | `AGG9110` | Aggregate balance at month M = 10 |
| 308 | `AGG9111` | Aggregate balance at month M = 11 |
| 309 | `AGG9112` | Aggregate balance at month M = 12 |
| 310 | `AGG9113` | Aggregate balance at month M = 13 |
| 311 | `AGG9114` | Aggregate balance at month M = 14 |
| 312 | `AGG9115` | Aggregate balance at month M = 15 |
| 313 | `AGG9116` | Aggregate balance at month M = 16 |
| 314 | `AGG9117` | Aggregate balance at month M = 17 |
| 315 | `AGG9118` | Aggregate balance at month M = 18 |
| 316 | `AGG9119` | Aggregate balance at month M = 19 |
| 317 | `AGG9120` | Aggregate balance at month M = 20 |
| 318 | `AGG9121` | Aggregate balance at month M = 21 |
| 319 | `AGG9122` | Aggregate balance at month M = 22 |
| 320 | `AGG9123` | Aggregate balance at month M = 23 |
| 321 | `AGG9124` | Aggregate balance at month M = 24 |
| 322 | `AGG9201` | Aggregate  credit line at month M = 01 |
| 323 | `AGG9202` | Aggregate  credit line at month M = 02 |
| 324 | `AGG9203` | Aggregate  credit line at month M = 03 |
| 325 | `AGG9204` | Aggregate  credit line at month M = 04 |
| 326 | `AGG9205` | Aggregate  credit line at month M = 05 |
| 327 | `AGG9206` | Aggregate  credit line at month M = 06 |
| 328 | `AGG9207` | Aggregate  credit line at month M = 07 |
| 329 | `AGG9208` | Aggregate  credit line at month M = 08 |
| 330 | `AGG9209` | Aggregate  credit line at month M = 09 |
| 331 | `AGG9210` | Aggregate  credit line at month M = 10 |
| 332 | `AGG9211` | Aggregate  credit line at month M = 11 |
| 333 | `AGG9212` | Aggregate  credit line at month M = 12 |
| 334 | `AGG9213` | Aggregate  credit line at month M = 13 |
| 335 | `AGG9214` | Aggregate  credit line at month M = 14 |
| 336 | `AGG9215` | Aggregate  credit line at month M = 15 |
| 337 | `AGG9216` | Aggregate  credit line at month M = 16 |
| 338 | `AGG9217` | Aggregate  credit line at month M = 17 |
| 339 | `AGG9218` | Aggregate  credit line at month M = 18 |
| 340 | `AGG9219` | Aggregate  credit line at month M = 19 |
| 341 | `AGG9220` | Aggregate  credit line at month M = 20 |
| 342 | `AGG9221` | Aggregate  credit line at month M = 21 |
| 343 | `AGG9222` | Aggregate  credit line at month M = 22 |
| 344 | `AGG9223` | Aggregate  credit line at month M = 23 |
| 345 | `AGG9224` | Aggregate  credit line at month M = 24 |
| 346 | `AGG9301` | Aggregate  amount past due at month M = 01 |
| 347 | `AGG9302` | Aggregate  amount past due at month M = 02 |
| 348 | `AGG9303` | Aggregate  amount past due at month M = 03 |
| 349 | `AGG9304` | Aggregate  amount past due at month M = 04 |
| 350 | `AGG9305` | Aggregate  amount past due at month M = 05 |
| 351 | `AGG9306` | Aggregate  amount past due at month M = 06 |
| 352 | `AGG9307` | Aggregate  amount past due at month M = 07 |
| 353 | `AGG9308` | Aggregate  amount past due at month M = 08 |
| 354 | `AGG9309` | Aggregate  amount past due at month M = 09 |
| 355 | `AGG9310` | Aggregate  amount past due at month M = 10 |
| 356 | `AGG9311` | Aggregate  amount past due at month M = 11 |
| 357 | `AGG9312` | Aggregate  amount past due at month M = 12 |
| 358 | `AGG9313` | Aggregate  amount past due at month M = 13 |
| 359 | `AGG9314` | Aggregate  amount past due at month M = 14 |
| 360 | `AGG9315` | Aggregate  amount past due at month M = 15 |
| 361 | `AGG9316` | Aggregate  amount past due at month M = 16 |
| 362 | `AGG9317` | Aggregate  amount past due at month M = 17 |
| 363 | `AGG9318` | Aggregate  amount past due at month M = 18 |
| 364 | `AGG9319` | Aggregate  amount past due at month M = 19 |
| 365 | `AGG9320` | Aggregate  amount past due at month M = 20 |
| 366 | `AGG9321` | Aggregate  amount past due at month M = 21 |
| 367 | `AGG9322` | Aggregate  amount past due at month M = 22 |
| 368 | `AGG9323` | Aggregate  amount past due at month M = 23 |
| 369 | `AGG9324` | Aggregate  amount past due at month M = 24 |
| 370 | `AGG9401` | Aggregate  actual payment amount at month M = 01 |
| 371 | `AGG9402` | Aggregate  actual payment amount at month M = 02 |
| 372 | `AGG9403` | Aggregate  actual payment amount at month M = 03 |
| 373 | `AGG9404` | Aggregate  actual payment amount at month M = 04 |
| 374 | `AGG9405` | Aggregate  actual payment amount at month M = 05 |
| 375 | `AGG9406` | Aggregate  actual payment amount at month M = 06 |
| 376 | `AGG9407` | Aggregate  actual payment amount at month M = 07 |
| 377 | `AGG9408` | Aggregate  actual payment amount at month M = 08 |
| 378 | `AGG9409` | Aggregate  actual payment amount at month M = 09 |
| 379 | `AGG9410` | Aggregate  actual payment amount at month M = 10 |
| 380 | `AGG9411` | Aggregate  actual payment amount at month M = 11 |
| 381 | `AGG9412` | Aggregate  actual payment amount at month M = 12 |
| 382 | `AGG9413` | Aggregate  actual payment amount at month M = 13 |
| 383 | `AGG9414` | Aggregate  actual payment amount at month M = 14 |
| 384 | `AGG9415` | Aggregate  actual payment amount at month M = 15 |
| 385 | `AGG9416` | Aggregate  actual payment amount at month M = 16 |
| 386 | `AGG9417` | Aggregate  actual payment amount at month M = 17 |
| 387 | `AGG9418` | Aggregate  actual payment amount at month M = 18 |
| 388 | `AGG9419` | Aggregate  actual payment amount at month M = 19 |
| 389 | `AGG9420` | Aggregate  actual payment amount at month M = 20 |
| 390 | `AGG9421` | Aggregate  actual payment amount at month M = 21 |
| 391 | `AGG9422` | Aggregate  actual payment amount at month M = 22 |
| 392 | `AGG9423` | Aggregate  actual payment amount at month M = 23 |
| 393 | `AGG9424` | Aggregate  actual payment amount at month M = 24 |
| 394 | `ALL231` | Aggregate excess payment for all accounts over the past month |
| 395 | `ALL232` | Aggregate excess payment for all accounts over the past 3 months |
| 396 | `ALL233` | Aggregate excess payment for all accounts over the past 6 months |
| 397 | `ALL234` | Aggregate excess payment for all accounts over the past 12 months |
| 398 | `ALL235` | Aggregate excess payment for all accounts over the past 24 months |
| 399 | `ALL252` | Average aggregate excess payment for all accounts over the past 3 months |
| 400 | `ALL253` | Average aggregate excess payment for all accounts over the past 6 months |
| 401 | `ALL254` | Average aggregate excess payment for all accounts over the past 12 months |
| 402 | `ALL255` | Average aggregate excess payment for all accounts over the past 24 months |
| 403 | `AT01S` | Number of trades |
| 404 | `AT02S` | Number of open trades |
| 405 | `AT06S` | Number of trades opened in past 6 months |
| 406 | `AT09S` | Number of trades opened in past 24 months |
| 407 | `AT101B` | Total balance of all trades verified in past 12 months (excluding mortgage and home equity) |
| 408 | `AT101S` | Total balance of all trades verified in past 12 months |
| 409 | `AT104S` | Percentage of all trades opened in past 24 months to all trades |
| 410 | `AT12S` | Number of open trades verified in past 12 months |
| 411 | `AT20S` | Months since oldest trade opened |
| 412 | `AT21S` | Months since most recent trade opened |
| 413 | `AT28A` | Total credit line of open trades verified in past 12 months |
| 414 | `AT28B` | Total credit line of open trades verified in past 12 months (excluding mortgage and home equity) |
| 415 | `AT29S` | Number of open trades with balance > $0 verified in past 12 months |
| 416 | `AT30S` | Percentage of open trades > 50% of credit line verified in past 12 months |
| 417 | `AT31S` | Percentage of open trades > 75% of credit line verified in past 12 months |
| 418 | `AT32S` | Maximum balance owed on open trades verified in past 12 months |
| 419 | `AT33A` | Total balance of open trades verified in past 12 months |
| 420 | `AT33B` | Total balance of open trades verified in past 12 months (excluding mortgage and home equity) |
| 421 | `AT34A` | Utilization for open trades verified in past 12 months |
| 422 | `AT34B` | Utilization for open trades verified in past 12 months (excluding mortgage and home equity) |
| 423 | `AT35A` | Average balance of open trades verified in past 12 months |
| 424 | `AT35B` | Average balance of open trades verified in past 12 months (excluding mortgage and home equity) |
| 425 | `AT36S` | Months since most recent delinquency |
| 426 | `AT57S` | Total past due amount of open trades verified in past 12 months |
| 427 | `ATAP01` | Total scheduled monthly payment for all trades verified in past 12 months |
| 428 | `AU01S` | Number of auto trades |
| 429 | `AU02S` | Number of open auto trades |
| 430 | `AU06S` | Number of auto trades opened in past 6 months |
| 431 | `AU09S` | Number of auto trades opened in past 24 months |
| 432 | `AU101S` | Total balance of all auto trades verified in past 12 months (BKAGBAL) |
| 433 | `AU12S` | Number of open auto trades verified in past 12 months |
| 434 | `AU200S` | Number of auto trades that are 30 days or more past due ever |
| 435 | `AU201S` | Number of auto trades that are 30 days or more past due in the past 12 months |
| 436 | `AU202S` | Number of auto trades that are 60 days or more past due ever |
| 437 | `AU203S` | Number of auto trades that are 60 days or more past due in the past 12 months |
| 438 | `AU204S` | Number of auto trades that are 90 days or more past due ever |
| 439 | `AU205S` | Number of auto trades that are 90 days or more past due in the past 12 months |
| 440 | `AU207S` | Number of Auto trades charged off |
| 441 | `AU20S` | Months since oldest auto trade opened |
| 442 | `AU21S` | Months since most recent auto trade opened |
| 443 | `AU28S` | Total credit line of open auto trades verified in past 12 months |
| 444 | `AU29S` | Number of open auto trades with balance > $0 verified in past 12 months |
| 445 | `AU30S` | Percentage of open auto trades > 50% of credit line verified in past 12 months |
| 446 | `AU31S` | Percentage of open auto trades > 75% of credit line verified in past 12 months |
| 447 | `AU32S` | Maximum balance owed on open auto trades verified in past 12 months |
| 448 | `AU33S` | Total balance of open auto trades verified in past 12 months |
| 449 | `AU34S` | Utilization for open auto trades verified in past 12 months |
| 450 | `AU35S` | Average balance of open auto trades verified in past 12 months |
| 451 | `AU36S` | Months since most recent auto delinquency |
| 452 | `AU51A` | Terms in months of most recent auto trade |
| 453 | `AU57S` | Total past due amount of open auto trades verified in past 12 months |
| 454 | `AUT201` | Total payment ratio for auto loans over the past month |
| 455 | `AUT202` | Total payment ratio for auto loans over the past 3 months |
| 456 | `AUT203` | Total payment ratio for auto loans over the past 6 months |
| 457 | `AUT204` | Total payment ratio for auto loans over the past 12 months |
| 458 | `AUT205` | Total payment ratio for auto loans over the past 24 months |
| 459 | `AUT222` | Average payment ratio for auto loans over the past 3 months |
| 460 | `AUT223` | Average payment ratio for auto loans over the past 6 months |
| 461 | `AUT224` | Average payment ratio for auto loans over the past 12 months |
| 462 | `AUT225` | Average payment ratio for auto loans over the past 24 months |
| 463 | `AUT231` | Aaggregate excess payment for auto loans over the past month |
| 464 | `AUT232` | Aggregate excess payment for auto loans over the past 3 months |
| 465 | `AUT233` | Aggregate excess payment for auto loans over the past 6 months |
| 466 | `AUT234` | Aggregate excess payment for auto loans over the past 12 months |
| 467 | `AUT235` | Aggregate excess payment for auto loans over the past 24 months |
| 468 | `AUT252` | Average aggregate excess payment for auto loans over the past 3 months |
| 469 | `AUT253` | Average aggregate excess payment for auto loans over the past 6 months |
| 470 | `AUT254` | Average aggregate excess payment for auto loans over the past 12 months |
| 471 | `AUT255` | Average aggregate excess payment for auto loans over the past 24 months |
| 472 | `BA01S` | Number of business agriculture trades |
| 473 | `BA02S` | Number of open business agriculture trades |
| 474 | `BA06S` | Number of business agriculture trades opened in past 6 months |
| 475 | `BA09S` | Number of business agriculture trades opened in past 24 months |
| 476 | `BA101S` | Total balance of all business agriculture trades verified in past 12 months (BKAGBAL) |
| 477 | `BA12S` | Number of open business agriculture trades verified in past 12 months |
| 478 | `BA20S` | Months since oldest business agriculture trade opened |
| 479 | `BA21S` | Months since most recent business agriculture trade opened |
| 480 | `BA28S` | Total credit line of open business agriculture trades verified in past 12 months |
| 481 | `BA29S` | Number of open business agriculture trades with balance > $0 verified in past 12 months |
| 482 | `BA30S` | Percentage of open business agriculture trades > 50% of credit line verified in past 12 months |
| 483 | `BA31S` | Percentage of open business agriculture trades > 75% of credit line verified in past 12 months |
| 484 | `BA32S` | Maximum balance owed on open business agriculture trades verified in past 12 months |
| 485 | `BA33S` | Total balance of open business agriculture trades verified in past 12 months |
| 486 | `BA34S` | Utilization for open business agriculture trades verified in past 12 months |
| 487 | `BA35S` | Average balance of open business agriculture trades verified in past 12 months |
| 488 | `BA36S` | Months since most recent business agriculture delinquency |
| 489 | `BA57S` | Total past due amount of open business agriculture trades verified in past 12 months |
| 490 | `BALMAG01` | Non-mortgage balance magnitude |
| 491 | `BALMAG02` | Revolving balance magnitude |
| 492 | `BALMAG03` | Cards balance magnitude |
| 493 | `BC_TRD` | Number of bankcard trades |
| 494 | `BC01S` | Number of credit card trades |
| 495 | `BC02S` | Number of open credit card trades |
| 496 | `BC06S` | Number of credit card trades opened in past 6 months |
| 497 | `BC09S` | Number of credit card trades opened in past 24 months |
| 498 | `BC101S` | Total balance of all credit card trades verified in past 12 months (BKAGBAL) |
| 499 | `BC102S` | Average credit line of open credit card trades verified in past 12 months (BKAVGCL) |
| 500 | `BC103S` | Average balance of all credit card trades with balance > $0 verified in past 12 months |
| 501 | `BC104S` | Average of the open credit card trade utilizations verified in past 12 months (TF1903) |
| 502 | `BC106S` | Number of credit card trades 30 or more days past due in past 24 months (TF0406) |
| 503 | `BC107S` | Number of 30 and 60 days past due ratings on credit card trades (TF0412) |
| 504 | `BC108S` | Number of 90 or more days past due ratings on credit card trades |
| 505 | `BC109S` | Number of credit card trades with past due amount > $50 verified in last 12 months (TF0804) |
| 506 | `BC110S` | Total past due amount of credit card trades verified in past 12 months (TF0915) |
| 507 | `BC12S` | Number of open credit card trades verified in past 12 months |
| 508 | `BC20S` | Months since oldest credit card trade opened |
| 509 | `BC21S` | Months since most recent credit card trade opened |
| 510 | `BC28S` | Total credit line of open credit card trades verified in past 12 months |
| 511 | `BC29S` | Number of open credit card trades with balance > $0 verified in past 12 months |
| 512 | `BC30S` | Percentage of open credit card trades > 50% of credit line verified in past 12 months |
| 513 | `BC31S` | Percentage of open credit card trades > 75% of credit line verified in past 12 months |
| 514 | `BC32S` | Maximum balance owed on open credit card trades verified in past 12 months |
| 515 | `BC33S` | Total balance of open credit card trades verified in past 12 months |
| 516 | `BC34S` | Utilization for open credit card trades verified in past 12 months |
| 517 | `BC35S` | Average balance of open credit card trades verified in past 12 months |
| 518 | `BC36S` | Months since most recent credit card delinquency |
| 519 | `BC57S` | Total past due amount of open credit card trades verified in past 12 months |
| 520 | `BC97A` | Total open to buy of open credit cards verified in past 3 months |
| 521 | `BC97B` | Total open to buy of closed credit cards verified in past 3 months |
| 522 | `BC98A` | Total open to buy of open credit cards verified in past 12 months |
| 523 | `BCPMTNUM` | Categorize Consumer by Bank Card Payment Behavior - Number |
| 524 | `BCPMTSTR` | Categorize Consumer by Bank Card Payment Behavior - String |
| 525 | `BG01S` | Number of business general trades |
| 526 | `BG02S` | Number of open business general trades |
| 527 | `BG06S` | Number of business general trades opened in past 6 months |
| 528 | `BG09S` | Number of business general trades opened in past 24 months |
| 529 | `BG101S` | Total balance of all business general trades verified in past 12 months (BKAGBAL) |
| 530 | `BG12S` | Number of open business general trades verified in past 12 months |
| 531 | `BG20S` | Months since oldest business general trade opened |
| 532 | `BG21S` | Months since most recent business general trade opened |
| 533 | `BG28S` | Total credit line of open business general trades verified in past 12 months |
| 534 | `BG29S` | Number of open business general trades with balance > $0 verified in past 12 months |
| 535 | `BG30S` | Percentage of open business general trades > 50% of credit line verified in past 12 months |
| 536 | `BG31S` | Percentage of open business general trades > 75% of credit line verified in past 12 months |
| 537 | `BG32S` | Maximum balance owed on open business general trades verified in past 12 months |
| 538 | `BG33S` | Total balance of open business general trades verified in past 12 months |
| 539 | `BG34S` | Utilization for open business general trades verified in past 12 months |
| 540 | `BG35S` | Average balance of open business general trades verified in past 12 months |
| 541 | `BG36S` | Months since most recent business general delinquency |
| 542 | `BG57S` | Total past due amount of open business general trades verified in past 12 months |
| 543 | `BI01S` | Number of bank installment trades |
| 544 | `BI02S` | Number of open bank installment trades |
| 545 | `BI06S` | Number of bank installment trades opened in past 6 months |
| 546 | `BI09S` | Number of bank installment trades opened in past 24 months |
| 547 | `BI101S` | Total balance of all bank installment trades verified in past 12 months (BKAGBAL) |
| 548 | `BI12S` | Number of open bank installment trades verified in past 12 months |
| 549 | `BI20S` | Months since oldest bank installment trade opened |
| 550 | `BI21S` | Months since most recent bank installment trade opened |
| 551 | `BI28S` | Total credit line of open bank installment trades verified in past 12 months |
| 552 | `BI29S` | Number of open bank installment trades with balance > $0 verified in past 12 months |
| 553 | `BI30S` | Percentage of open bank installment trades > 50% of credit line verified in past 12 months |
| 554 | `BI31S` | Percentage of open bank installment trades > 75% of credit line verified in past 12 months |
| 555 | `BI32S` | Maximum balance owed on open bank installment trades verified in past 12 months |
| 556 | `BI33S` | Total balance of open bank installment trades verified in past 12 months |
| 557 | `BI34S` | Utilization for open bank installment trades verified in past 12 months |
| 558 | `BI35S` | Average balance of open bank installment trades verified in past 12 months |
| 559 | `BI36S` | Months since most recent bank installment delinquency |
| 560 | `BI57S` | Total past due amount of open bank installment trades verified in past 12 months |
| 561 | `BIL201` | Total payment ratio for business installment loans over the past month |
| 562 | `BIL202` | Total payment ratio for business installment loans over the past 3 months |
| 563 | `BIL203` | Total payment ratio for business installment loans over the past 6 months |
| 564 | `BIL204` | Total payment ratio for business installment loans over the past 12 months |
| 565 | `BIL205` | Total payment ratio for business installment loans over the past 24 months |
| 566 | `BIL222` | Average payment ratio for business installment loans over the past 3 months |
| 567 | `BIL223` | Average payment ratio for business installment loans over the past 6 months |
| 568 | `BIL224` | Average payment ratio for business installment loans over the past 12 months |
| 569 | `BIL225` | Average payment ratio for business installment loans over the past 24 months |
| 570 | `BIL231` | Aggregate excess payment for business installment loans over the past month |
| 571 | `BIL232` | Aggregate excess payment for business installment loans over the past 3 months |
| 572 | `BIL233` | Aggregate excess payment for business installment loans over the past 6 months |
| 573 | `BIL234` | Aggregate excess payment for business installment loans over the past 12 months |
| 574 | `BIL235` | Aggregate excess payment for business installment loans over the past 24 months |
| 575 | `BIL252` | Average aggregate excess payment for business installment loans over the past 3 months |
| 576 | `BIL253` | Average aggregate excess payment for business installment loans over the past 6 months |
| 577 | `BIL254` | Average aggregate excess payment for business installment loans over the past 12 months |
| 578 | `BIL255` | Average aggregate excess payment for business installment loans over the past 24 months |
| 579 | `BKC102` | Number of months in the past 12 months where percentage of bankcards utilized less than 50% was more than 25% |
| 580 | `BKC11` | Number of instances where a bankcard was utilized more than 25% in the past 12 months |
| 581 | `BKC112` | Number of months in the past 12 months where percentage of bankcards utilized less than 75% was more than 25% |
| 582 | `BKC12` | Number of instances where a bankcard was utilized more than 50% in the past 12 months |
| 583 | `BKC122` | Number of months in the past 12 months where percentage of bankcards utilized less than 100% was more than 25% |
| 584 | `BKC13` | Number of instances where a bankcard was utilized more than 75% in the past 12 months |
| 585 | `BKC132` | Number of months in the past 12 months where percentage of bankcards utilized more than 25% was more than 90% |
| 586 | `BKC14` | Number of instances where a bankcard was utilized more than 90% in the past 12 months |
| 587 | `BKC142` | Number of months in the past 12 months where percentage of bankcards utilized more than 50% was more than 90% |
| 588 | `BKC152` | Number of months in the past 12 months where percentage of bankcards utilized more than 75% was more than 90% |
| 589 | `BKC162` | Number of months in the past 12 months where percentage of bankcards utilized more than 100% was more than 90% |
| 590 | `BKC201` | Total payment ratio for bankcard accounts over the past month |
| 591 | `BKC202` | Total payment ratio for bankcard accounts over the past 3 months |
| 592 | `BKC203` | Total payment ratio for bankcard accounts over the past 6 months |
| 593 | `BKC204` | Total payment ratio for bankcard accounts over the past 12 months |
| 594 | `BKC205` | Total payment ratio for bankcard accounts over the past 24 months |
| 595 | `BKC222` | Average payment ratio for bankcard accounts over the past 3 months |
| 596 | `BKC223` | Average payment ratio for bankcard accounts over the past 6 months |
| 597 | `BKC224` | Average payment ratio for bankcard accounts over the past 12 months |
| 598 | `BKC225` | Average payment ratio for bankcard accounts over the past 24 months |
| 599 | `BKC231` | Aggregate excess payment for bankcard accounts over the past month |
| 600 | `BKC232` | Aggregate excess payment for bankcard accounts over the past 3 months |
| 601 | `BKC233` | Aggregate excess payment for bankcard accounts over the past 6 months |
| 602 | `BKC234` | Aggregate excess payment for bankcard accounts over the past 12 months |
| 603 | `BKC235` | Aggregate excess payment for bankcard accounts over the past 24 months |
| 604 | `BKC252` | Average aggregate excess payment for bankcard accounts over the past 3 months |
| 605 | `BKC253` | Average aggregate excess payment for bankcard accounts over the past 6 months |
| 606 | `BKC254` | Average aggregate excess payment for bankcard accounts over the past 12 months |
| 607 | `BKC255` | Average aggregate excess payment for bankcard accounts over the past 24 months |
| 608 | `BKC51` | Number of bankcards utilized more than 25% in the past 12 months |
| 609 | `BKC52` | Number of bankcards utilized more than 50% in the past 12 months |
| 610 | `BKC53` | Number of bankcards utilized more than 75% in the past 12 months |
| 611 | `BKC54` | Number of bankcards utilized more than 90% in the past 12 months |
| 612 | `BKC81` | Months since a bankcard account last exceeded 25% utilization |
| 613 | `BKC82` | Months since a bankcard account last exceeded 50% utilization |
| 614 | `BKC83` | Months since a bankcard account last exceeded 75% utilization |
| 615 | `BKC84` | Months since a bankcard account last exceeded 90% utilization |
| 616 | `BKC92` | Number of months in the past 12 months where percentage of bankcards utilized less than 25% was more than 25% |
| 617 | `BP01S` | Number of business priority trades |
| 618 | `BP02S` | Number of open business priority trades |
| 619 | `BP06S` | Number of business priority trades opened in past 6 months |
| 620 | `BP09S` | Number of business priority trades opened in past 24 months |
| 621 | `BP101S` | Total balance of all business priority trades verified in past 12 months (BKAGBAL) |
| 622 | `BP12S` | Number of open business priority trades verified in past 12 months |
| 623 | `BP20S` | Months since oldest business priority trade opened |
| 624 | `BP21S` | Months since most recent business priority trade opened |
| 625 | `BP28S` | Total credit line of open business priority trades verified in past 12 months |
| 626 | `BP29S` | Number of open business priority trades with balance > $0 verified in past 12 months |
| 627 | `BP30S` | Percentage of open business priority trades > 50% of credit line verified in past 12 months |
| 628 | `BP31S` | Percentage of open business priority trades > 75% of credit line verified in past 12 months |
| 629 | `BP32S` | Maximum balance owed on open business priority trades verified in past 12 months |
| 630 | `BP33S` | Total balance of open business priority trades verified in past 12 months |
| 631 | `BP34S` | Utilization for open business priority trades verified in past 12 months |
| 632 | `BP35S` | Average balance of open business priority trades verified in past 12 months |
| 633 | `BP36S` | Months since most recent business priority delinquency |
| 634 | `BP57S` | Total past due amount of open business priority trades verified in past 12 months |
| 635 | `BR01S` | Number of bank revolving trades |
| 636 | `BR02S` | Number of open bank revolving trades |
| 637 | `BR06S` | Number of bank revolving trades opened in past 6 months |
| 638 | `BR09S` | Number of bank revolving trades opened in past 24 months |
| 639 | `BR101S` | Total balance of all bank revolving trades verified in past 12 months (BKAGBAL) |
| 640 | `BR109S` | Number of bank revolving trades with past due amount > $50 verified in last 12 months (TA0805) |
| 641 | `BR12S` | Number of open bank revolving trades verified in past 12 months |
| 642 | `BR20S` | Months since oldest bank revolving trade opened |
| 643 | `BR21S` | Months since most recent bank revolving trade opened |
| 644 | `BR28S` | Total credit line of open bank revolving trades verified in past 12 months |
| 645 | `BR29S` | Number of open bank revolving trades with balance > $0 verified in past 12 months |
| 646 | `BR30S` | Percentage of open bank revolving trades > 50% of credit line verified in past 12 months |
| 647 | `BR31S` | Percentage of open bank revolving trades > 75% of credit line verified in past 12 months |
| 648 | `BR32S` | Maximum balance owed on open bank revolving trades verified in past 12 months |
| 649 | `BR33S` | Total balance of open bank revolving trades verified in past 12 months |
| 650 | `BR34S` | Utilization for open bank revolving trades verified in past 12 months |
| 651 | `BR35S` | Average balance of open bank revolving trades verified in past 12 months |
| 652 | `BR36S` | Months since most recent bank revolving delinquency |
| 653 | `BR57S` | Total past due amount of open bank revolving trades verified in past 12 months |
| 654 | `CGD01S` | Number of closed in good standing trades |
| 655 | `CGD02S` | Number of closed in good standing trades in past 12 months |
| 656 | `CGD03S` | Number of closed in good standing trades in past 24 months |
| 657 | `CGD04S` | Months since most recent closed in good standing trade reported |
| 658 | `CGD05S` | Total balance of closed in good standing trades |
| 659 | `CGD06S` | Total balance of closed in good standing trades in past 12 months |
| 660 | `CGD07S` | Total balance of closed in good standing trades in past 24 months |
| 661 | `CMV201` | Total payment ratio for commercial vehicle loans over the past month |
| 662 | `CMV202` | Total payment ratio for commercial vehicle loans over the past 3 months |
| 663 | `CMV203` | Total payment ratio for commercial vehicle loans over the past 6 months |
| 664 | `CMV204` | Total payment ratio for commercial vehicle loans over the past 12 months |
| 665 | `CMV205` | Total payment ratio for commercial vehicle loans over the past 24 months |
| 666 | `CMV222` | Average payment ratio for commercial vehicle loans over the past 3 months |
| 667 | `CMV223` | Average payment ratio for commercial vehicle loans over the past 6 months |
| 668 | `CMV224` | Average payment ratio for commercial vehicle loans over the past 12 months |
| 669 | `CMV225` | Average payment ratio for commercial vehicle loans over the past 24 months |
| 670 | `CMV231` | Aggregate excess payment for commercial vehicle loans over the past month |
| 671 | `CMV232` | Aggregate excess payment for commercial vehicle loans over the past 3 months |
| 672 | `CMV233` | Aggregate excess payment for commercial vehicle loans over the past 6 months |
| 673 | `CMV234` | Aggregate excess payment for commercial vehicle loans over the past 12 months |
| 674 | `CMV235` | Aggregate excess payment for commercial vehicle loans over the past 24 months |
| 675 | `CMV252` | Average aggregate excess payment for commercial vehicle loans over the past 3 months |
| 676 | `CMV253` | Average aggregate excess payment for commercial vehicle loans over the past 6 months |
| 677 | `CMV254` | Average aggregate excess payment for commercial vehicle loans over the past 12 months |
| 678 | `CMV255` | Average aggregate excess payment for commercial vehicle loans over the past 24 months |
| 679 | `CO01S` | Number of charged-off trades |
| 680 | `CO01S120` | Number of charged-off trades (120DPD+) |
| 681 | `CO01S150` | Number of charged-off trades (150DPD+) |
| 682 | `CO01S180` | Number of charged-off trades (180DPD+) |
| 683 | `CO01S360` | Number of charged-off trades (360DPD+) |
| 684 | `CO01S720` | Number of charged-off trades (720DPD+) |
| 685 | `CO02S` | Number of charge-off trades in past 12 months |
| 686 | `CO02S120` | Number of charge-off trades in past 12 months (120DPD+) |
| 687 | `CO02S150` | Number of charge-off trades in past 12 months (150DPD+) |
| 688 | `CO02S180` | Number of charge-off trades in past 12 months (180DPD+) |
| 689 | `CO02S360` | Number of charge-off trades in past 12 months (360DPD+) |
| 690 | `CO02S720` | Number of charge-off trades in past 12 months (720DPD+) |
| 691 | `CO03S` | Number of charge-off trades in past 24 months |
| 692 | `CO03S120` | Number of charge-off trades in past 24 months (120DPD+) |
| 693 | `CO03S150` | Number of charge-off trades in past 24 months (150DPD+) |
| 694 | `CO03S180` | Number of charge-off trades in past 24 months (180DPD+) |
| 695 | `CO03S360` | Number of charge-off trades in past 24 months (360DPD+) |
| 696 | `CO03S720` | Number of charge-off trades in past 24 months (720DPD+) |
| 697 | `CO04S` | Months since most recent charged-off trade reported |
| 698 | `CO04S120` | Months since most recent charged-off trade reported (120DPD+) |
| 699 | `CO04S150` | Months since most recent charged-off trade reported (150DPD+) |
| 700 | `CO04S180` | Months since most recent charged-off trade reported (180DPD+) |
| 701 | `CO04S360` | Months since most recent charged-off trade reported (360DPD+) |
| 702 | `CO04S720` | Months since most recent charged-off trade reported (720DPD+) |
| 703 | `CO05S` | Total balance of trades that charged-off |
| 704 | `CO05S120` | Total balance of trades that charged-off (120DPD+) |
| 705 | `CO05S150` | Total balance of trades that charged-off (150DPD+) |
| 706 | `CO05S180` | Total balance of trades that charged-off (180DPD+) |
| 707 | `CO05S360` | Total balance of trades that charged-off (360DPD+) |
| 708 | `CO05S720` | Total balance of trades that charged-off (720DPD+) |
| 709 | `CO06S` | Total balance of trades that charged-off in the past 12 months |
| 710 | `CO06S120` | Total balance of trades that charged-off in the past 12 months (120DPD+) |
| 711 | `CO06S150` | Total balance of trades that charged-off in the past 12 months (150DPD+) |
| 712 | `CO06S180` | Total balance of trades that charged-off in the past 12 months (180DPD+) |
| 713 | `CO06S360` | Total balance of trades that charged-off in the past 12 months (360DPD+) |
| 714 | `CO06S720` | Total balance of trades that charged-off in the past 12 months (720DPD+) |
| 715 | `CO07S` | Total balance of trades that charged-off in the past 24 months |
| 716 | `CO07S120` | Total balance of trades that charged-off in the past 24 months (120DPD+) |
| 717 | `CO07S150` | Total balance of trades that charged-off in the past 24 months (150DPD+) |
| 718 | `CO07S180` | Total balance of trades that charged-off in the past 24 months (180DPD+) |
| 719 | `CO07S360` | Total balance of trades that charged-off in the past 24 months (360DPD+) |
| 720 | `CO07S720` | Total balance of trades that charged-off in the past 24 months (720DPD+) |
| 721 | `CV01` | Months since most recent charge-off occurrence |
| 722 | `CV10` | Number of accounts 30 or more days past due ever |
| 723 | `CV11` | Number of accounts 60 or more days past due ever |
| 724 | `CV12` | Number of accounts 90 or more days past due ever |
| 725 | `CV13` | Percentage of accounts ever delinquent |
| 726 | `CV17` | Number of accounts prior 30 days past due, now current, verified in past 12 months |
| 727 | `CV18` | Number of accounts prior 60 days past due, now current, verified in past 12 months |
| 728 | `CV19` | Total balance of accounts verified in past 3 months |
| 729 | `CV20` | Total monthly obligation of accounts verified in past 3 months |
| 730 | `CV21` | Total payment amount of accounts verified in past 3 months |
| 731 | `CV22` | Total balance of bankcard accounts verified in past 3 months |
| 732 | `CV23` | Total monthly obligation of bankcard accounts verified in past 3 months |
| 733 | `CV24` | Total payment amount of bankcard accounts verified in past 3 months |
| 734 | `CV25` | Percent of accounts switching from inactive to active status in the past 12 months |
| 735 | `CV26` | Percent of accounts switching from active to inactive status in the past 12 months |
| 736 | `CV27` | Percent of bankcard accounts switching from inactive to active status in the past 12 months |
| 737 | `CV28` | Percent of bankcard accounts switching from active to inactive status in the past 12 months |
| 738 | `DM001S` | Age |
| 739 | `DM002S` | Gender |
| 740 | `DM004S` | Owner/Tenant |
| 741 | `DM006S` | Income |
| 742 | `DM008S` | Occupation |
| 743 | `DM101S` | Postal Code |
| 744 | `DM201S` | Numer of phones first reported in 3 months |
| 745 | `DM202S` | Numer of phones first reported in 6 months |
| 746 | `DM203S` | Numer of phones first reported in 12 months |
| 747 | `DM204S` | Numer of phones first reported in 24 months |
| 748 | `DM205S` | Number of Phones Reported |
| 749 | `DM206S` | Months since last update of phone |
| 750 | `DM211S` | Numer of addresses first reported in 3 months |
| 751 | `DM212S` | Numer of addresses first reported in 6 months |
| 752 | `DM213S` | Numer of addresses first reported in 12 months |
| 753 | `DM214S` | Numer of addresses first reported in 24 months |
| 754 | `DM215S` | Number of addresses Reported |
| 755 | `DM216S` | Months since last update of address |
| 756 | `DM221S` | Numer of emails first reported in 3 months |
| 757 | `DM222S` | Numer of emails first reported in 6 months |
| 758 | `DM223S` | Numer of emails first reported in 12 months |
| 759 | `DM224S` | Numer of emails first reported in 24 months |
| 760 | `DM225S` | Number of emails Reported |
| 761 | `DM226S` | Months since last update of email |
| 762 | `DM231S` | Numer of employments first reported in 3 months |
| 763 | `DM232S` | Numer of employments first reported in 6 months |
| 764 | `DM233S` | Numer of employments first reported in 12 months |
| 765 | `DM234S` | Numer of employments first reported in 24 months |
| 766 | `DM235S` | Number of employments Reported |
| 767 | `DM236S` | Months since last update of employment |
| 768 | `FI01S` | Number of finance installment trades |
| 769 | `FI02S` | Number of open finance installment trades |
| 770 | `FI06S` | Number of finance installment trades opened in past 6 months |
| 771 | `FI09S` | Number of finance installment trades opened in past 24 months |
| 772 | `FI101S` | Total balance of all finance installment trades verified in past 12 months (BKAGBAL) |
| 773 | `FI12S` | Number of open finance installment trades verified in past 12 months |
| 774 | `FI20S` | Months since oldest finance installment trade opened |
| 775 | `FI21S` | Months since most recent finance installment trade opened |
| 776 | `FI28S` | Total credit line of open finance installment trades verified in past 12 months |
| 777 | `FI29S` | Number of open finance installment trades with balance > $0 verified in past 12 months |
| 778 | `FI30S` | Percentage of open finance installment trades > 50% of credit line verified in past 12 months |
| 779 | `FI31S` | Percentage of open finance installment trades > 75% of credit line verified in past 12 months |
| 780 | `FI32S` | Total past due amount of open finance installment trades verified in past 12 months |
| 781 | `FI33S` | Total balance of open finance installment trades verified in past 12 months |
| 782 | `FI34S` | Utilization for open finance installment trades verified in past 12 months |
| 783 | `FI35S` | Average balance of open finance installment trades verified in past 12 months |
| 784 | `FI36S` | Months since most recent finance installment delinquency |
| 785 | `FI57S` | Total past due amount of open finance installment trades verified in past 12 months |
| 786 | `FINANCIAL_TRD` | Number of "Financial" trades (excluded utility, non-loans) |
| 787 | `FR01S` | Number of finance revolving trades |
| 788 | `FR02S` | Number of open finance revolving trades |
| 789 | `FR06S` | Number of finance revolving trades opened in past 6 months |
| 790 | `FR09S` | Number of finance revolving trades opened in past 24 months |
| 791 | `FR101S` | Total balance of all finance revolving trades verified in past 12 months (BKAGBAL) |
| 792 | `FR12S` | Number of open finance revolving trades verified in past 12 months |
| 793 | `FR20S` | Months since oldest finance revolving trade opened |
| 794 | `FR21S` | Months since most recent finance revolving trade opened |
| 795 | `FR28S` | Total credit line of open finance revolving trades verified in past 12 months |
| 796 | `FR29S` | Number of open finance revolving trades with balance > $0 verified in past 12 months |
| 797 | `FR30S` | Percentage of open finance revolving trades > 50% of credit line verified in past 12 months |
| 798 | `FR31S` | Percentage of open finance revolving trades > 75% of credit line verified in past 12 months |
| 799 | `FR32S` | Maximum balance owed on open finance revolving trades verified in past 12 months |
| 800 | `FR33S` | Total balance of open finance revolving trades verified in past 12 months |
| 801 | `FR34S` | Utilization for open finance revolving trades verified in past 12 months |
| 802 | `FR35S` | Average balance of open finance revolving trades verified in past 12 months |
| 803 | `FR36S` | Months since most recent finance revolving delinquency |
| 804 | `FR57S` | Total past due amount of open finance revolving trades verified in past 12 months |
| 805 | `G001B` | Number of 30 or more days past due ratings in past 12 months |
| 806 | `G001S` | Number of 30 days past due ratings in past 12 months |
| 807 | `G002B` | Number of 60 or more days past due ratings in past 12 months |
| 808 | `G002S` | Number of 60 days past due ratings in past 12 months |
| 809 | `G003S` | Number of 90 or more days past due ratings in past 12 months |
| 810 | `G011S` | Number of trades with delinquencies in past 3 months |
| 811 | `G020S` | Number of trades with maximum delinquency of 30 days past due in past 24 months |
| 812 | `G041S` | Number of trades 30 or more days past due ever |
| 813 | `G042S` | Number of trades 60 or more days past due ever |
| 814 | `G043S` | Number of trades 90 or more days past due ever |
| 815 | `G051S` | Percentage of trades ever delinquent |
| 816 | `G057S` | Number of trades 30 or more days past due in past 3 months |
| 817 | `G058S` | Number of trades 30 or more days past due in past 6 months |
| 818 | `G059S` | Number of trades 30 or more days past due in past 12 months |
| 819 | `G061S` | Number of trades 30 or more days past due in past 24 months |
| 820 | `G063S` | Number of trades 60 or more days past due in past 6 months |
| 821 | `G064S` | Number of trades 60 or more days past due in past 12 months |
| 822 | `G066S` | Number of trades 60 or more days past due in past 24 months |
| 823 | `G068S` | Number of trades 90 or more days past due in past 6 months |
| 824 | `G069S` | Number of trades 90 or more days past due in past 12 months |
| 825 | `G071S` | Number of trades 90 or more days past due in past 24 months |
| 826 | `G102S` | Months since most recent inquiry |
| 827 | `G103S` | Months since most recent credit inquiry |
| 828 | `G105S` | Months since most recent mortgage inquiry |
| 829 | `G106S` | Months on File (from record creation on bureau, is different from age of oldest trade) |
| 830 | `G199S` | Total monthly obligation for contractually liable accounts verified in past 12 months |
| 831 | `G200S` | Percentage of contractually liable debt |
| 832 | `G201A` | Total open to buy of open trades verified in past 3 months (excluding installments and mortgages) (T02501) |
| 833 | `G201B` | Total open to buy of closed trades verified in past 3 months (excluding installments and mortgages) (T02501) |
| 834 | `G202A` | Total open to buy of open trades verified in past 12 months (excluding installments and mortgages) (T02503) |
| 835 | `G202B` | Total open to buy of closed trades verified in past 12 months (excluding installments and mortgages) (T02503) |
| 836 | `G205S` | Total monthly obligation for individual account verified in past 12 months (ATTR13) |
| 837 | `G206S` | Total monthly obligation for joint account verified in past 12 months (ATTR14) |
| 838 | `G207S` | Total monthly obligation for all accounts (ATTR16) |
| 839 | `G208S` | Percentage of individual debt (ATTR17) |
| 840 | `G209S` | Months since most recent charged-off trade opened (TB094) |
| 841 | `G209S120` | Months since most recent charged-off trade opened (TB094) (120+ DPD) |
| 842 | `G209S150` | Months since most recent charged-off trade opened (TB094) (150+ DPD) |
| 843 | `G209S180` | Months since most recent charged-off trade opened (TB094) (180+ DPD) |
| 844 | `G209S360` | Months since most recent charged-off trade opened (TB094) (360+ DPD) |
| 845 | `G209S720` | Months since most recent charged-off trade opened (TB094) (720+ DPD) |
| 846 | `G210S` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) |
| 847 | `G210S120` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) (120+ DPD) |
| 848 | `G210S150` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) (150+ DPD) |
| 849 | `G210S180` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) (180+ DPD) |
| 850 | `G210S360` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) (360+ DPD) |
| 851 | `G210S720` | Total past due amount of charged-off trades verified in past 12 months (TQ0903) (720+ DPD) |
| 852 | `G211S` | Highest balance of charged-off trades (TQ1702) |
| 853 | `G211S120` | Highest balance of charged-off trades (TQ1702) (120+ DPD) |
| 854 | `G211S150` | Highest balance of charged-off trades (TQ1702) (150+ DPD) |
| 855 | `G211S180` | Highest balance of charged-off trades (TQ1702) (180+ DPD) |
| 856 | `G211S360` | Highest balance of charged-off trades (TQ1702) (360+ DPD) |
| 857 | `G211S720` | Highest balance of charged-off trades (TQ1702) (720+ DPD) |
| 858 | `G212S` | Number of charged-off trades opened in past 24 months (TQ3105) |
| 859 | `G212S120` | Number of charged-off trades opened in past 24 months (TQ3105) (120+ DPD) |
| 860 | `G212S150` | Number of charged-off trades opened in past 24 months (TQ3105) (150+ DPD) |
| 861 | `G212S180` | Number of charged-off trades opened in past 24 months (TQ3105) (180+ DPD) |
| 862 | `G212S360` | Number of charged-off trades opened in past 24 months (TQ3105) (360+ DPD) |
| 863 | `G212S720` | Number of charged-off trades opened in past 24 months (TQ3105) (720+ DPD) |
| 864 | `G216S` | Number of trades with a delinquency of 90 or more days past due since opening a new trade (within past 24 months) (CT18) |
| 865 | `G217S` | Total past due amount of all trades verified in past 12 months |
| 866 | `G218A` | Number of trades verified in the past 12 months that are currently 30 days past due |
| 867 | `G218B` | Number of trades verified in the past 12 months that are currently 30 days or more past due |
| 868 | `G218C` | Number of credit card trades verified in the past 12 months that are currently 30 days past due |
| 869 | `G218D` | Number of credit card trades verified in the past 12 months that are currently 30 days or more past due |
| 870 | `G219A` | Number of trades verified in the past 12 months that are currently 60 days past due |
| 871 | `G219B` | Number of trades verified in the past 12 months that are currently 60 days or more past due |
| 872 | `G219C` | Number of credit card trades verified in the past 12 months that are currently 60 days past due |
| 873 | `G219D` | Number of credit card trades verified in the past 12 months that are currently 60 days or more past due |
| 874 | `G220A` | Number of trades verified in the past 12 months that are currently 90 days past due |
| 875 | `G220B` | Number of trades verified in the past 12 months that are currently 90 days or more past due |
| 876 | `G220C` | Number of credit card trades verified in the past 12 months that are currently 90 days past due |
| 877 | `G220D` | Number of credit card trades verified in the past 12 months that are currently 90 days or more past due |
| 878 | `G221A` | Number of trades verified in the past 12 months that are currently 120 days past due |
| 879 | `G221B` | Number of trades verified in the past 12 months that are currently 120 days or more past due |
| 880 | `G221C` | Number of credit card trades verified in the past 12 months that are currently 120 days past due |
| 881 | `G221D` | Number of credit card trades verified in the past 12 months that are currently 120 days or more past due |
| 882 | `G222S` | Number of trades prior 30 days past due, now current, verified in past 12 months (T0701B) |
| 883 | `G223S` | Number of trades prior 60 days past due, now current, verified in past 12 months (T0701C) |
| 884 | `G224A` | Number of 90 days past due or worse items ever (excluding medical collection items) (TB077) |
| 885 | `G224B` | Number of 90 days past due or worse items in the past 12 months (excluding medical collection items) (TB077) |
| 886 | `G224C` | Number of 90 days past due or worse items in the past 24 months (excluding medical collection items) (TB077) |
| 887 | `G225S` | Total past due amount of currently 90 or more days past due trades (TG0903) |
| 888 | `G226S` | Number of 60 or more days past due trades (current MOP only) with balance > $0 opened in past 12 months (TK1108) |
| 889 | `G227S` | Number of 90 or more days past due trades (current MOP only) with balance > $0 opened in past 12 months (TK1124) |
| 890 | `G228S` | Number of 90 or more days past due trades (current MOP only) with balance > $0 opened in past 24 months (TK1125) |
| 891 | `G230S` | Number of 60 or more days past due trades (current MOP only) with balance > $0 opened in past 24 months (TK1108) |
| 892 | `G232S` | Number of inquiries (includes duplicates) (NUMINQ) |
| 893 | `G234S` | Number of days with inquiry occurring in past 30 days |
| 894 | `G235S` | Number of trades opened since most recent delinquency (delinquency search limited to 24 months) |
| 895 | `G240S` | Number of mortgage inquiries |
| 896 | `G241S` | Number of mortgage inquiries in past 6 months |
| 897 | `G242B` | Number of bank inquiries (includes duplicates) in the last 3 months |
| 898 | `G242F` | Number of finance inquiries (includes duplicates) in the last 3 months |
| 899 | `G242S` | Number of inquiries (includes duplicates) in the last 3 months |
| 900 | `G243B` | Number of bank inquiries (includes duplicates) in the last 6 months |
| 901 | `G243F` | Number of finance inquiries (includes duplicates) in the last 6 months |
| 902 | `G243S` | Number of inquiries (includes duplicates) in the last 6 months |
| 903 | `G244B` | Number of bank inquiries (includes duplicates) in the last 12 months |
| 904 | `G244F` | Number of finance inquiries (includes duplicates) in the last 12 months |
| 905 | `G244S` | Number of inquiries (includes duplicates) in the last 12 months |
| 906 | `G250A` | Number of 30DPD or worse derogatory items ever, excluding medical |
| 907 | `G250B` | Number of 30DPD or worse derogatory items in past 12 months, excluding medical |
| 908 | `G250C` | Number of 30DPD or worse derogatory items in past 24 months, excluding medical |
| 909 | `G251A` | Number of 60DPD or worse derogatory items ever, excluding medical |
| 910 | `G251B` | Number of 60DPD or worse derogatory items in past 12 months, excluding medical |
| 911 | `G251C` | Number of 60DPD or worse derogatory items in past 24 months, excluding medical |
| 912 | `G300S` | Worst rating on credit card trades in past 12 months |
| 913 | `G301S` | Worst rating on credit card trades |
| 914 | `G302S` | Worst rating on revolving trades in past 12 months |
| 915 | `G303S` | Worst rating on revolving trades |
| 916 | `G304S` | Worst rating on installment trades in past 12 months |
| 917 | `G305S` | Worst rating on installment trades |
| 918 | `G306S` | Worst rating on auto trades in past 12 months |
| 919 | `G307S` | Worst rating on auto trades |
| 920 | `G308S` | Worst rating on mortgage trades in past 12 months |
| 921 | `G309S` | Worst rating on mortgage trades |
| 922 | `G310S` | Worst rating on all trades in past 12 months |
| 923 | `G311S` | Worst rating on all trades |
| 924 | `G314S` | Worst rating on home equity loan trades in past 12 months |
| 925 | `G315S` | Worst rating on home equity loan trades |
| 926 | `G330S` | Worst rating on retail trades in past 12 months |
| 927 | `G331S` | Worst rating on retail trades trades |
| 928 | `G416S` | Months since most recent finance inquiry |
| 929 | `G417S` | Months since most recent bank inquiry |
| 930 | `G418S` | Months since most recent auto inquiry |
| 931 | `G500S` | Days since most recent credit inquiry |
| 932 | `G501S` | Number of Credit inquiries in past 2 weeks |
| 933 | `G502S` | Number of Credit inquiries in past 30 days |
| 934 | `G503S` | Number of Credit inquiries in past 90 days |
| 935 | `G504S` | Number of Bank Loan  inquiries |
| 936 | `G505S` | Days since most recent Bank Personal Loan inquiry |
| 937 | `G506S` | Number of Bank  Personal Loan inquiries in past 2 weeks |
| 938 | `G507S` | Number of Bank Personal  Loan inquiries in past 30 days |
| 939 | `G508S` | Number of Bank Personal  Loan inquiries in past 90 days |
| 940 | `G509S` | Number of  Bank Personal Loan inquiries in past 6 months |
| 941 | `G510S` | Number of Bank Personal  Loan inquiries in past 12 months |
| 942 | `G511S` | Number of NON- Bank Personal  inquiries |
| 943 | `G512S` | Days since most recent NON- Bank Personal   Loan inquiry |
| 944 | `G513S` | Number of NON- Bank Personal   Loan inquiries in past 2 weeks |
| 945 | `G514S` | Number of NON- Bank Personal  Loan inquiries in past 30 days |
| 946 | `G515S` | Number of NON- Bank Personal   Loan inquiries in past 90 days |
| 947 | `G516S` | Number of NON- Bank Personal   Loan inquiries in past 6 months |
| 948 | `G517S` | Number of NON- Bank Personal Loan inquiries in past 12 months |
| 949 | `G518S` | Number of retail installment loan inquiries |
| 950 | `G519S` | Days since most recent retail installment loan inquiry |
| 951 | `G520S` | Number of retail installment loan inquiries in past 2 weeks |
| 952 | `G521S` | Number of retail installment loan inquiries in 30 days |
| 953 | `G522S` | Number of retail installment loan inquiries in past 90 days |
| 954 | `G523S` | Number of retail installment loan inquiries in past six months |
| 955 | `G524S` | Number of retail installment loan inquiries in past twelve months |
| 956 | `G532S` | Number of Credit Card Loan  inquiries |
| 957 | `G533S` | Days since most recentCredit Card  Loan inquiry |
| 958 | `G534S` | Number of Credit Card  Loan inquiries in past 2 weeks |
| 959 | `G535S` | Number of Credit Card  Loan inquiries in past 30 days |
| 960 | `G536S` | Number of Credit Card  Loan inquiries in past 90 days |
| 961 | `G537S` | Number of Credit Card  Loan inquiries in past 6 months |
| 962 | `G538S` | Number of Credit Card  Loan inquiries in past 12 months |
| 963 | `GL01S` | Number of gold loan trades |
| 964 | `GL02S` | Number of open gold loan trades |
| 965 | `GL06S` | Number of gold loan trades opened in past 6 months |
| 966 | `GL09S` | Number of gold loan trades opened in past 24 months |
| 967 | `GL101S` | Total balance of all gold loan trades verified in past 12 months (BKAGBAL) |
| 968 | `GL12S` | Number of open gold loan trades verified in past 12 months |
| 969 | `GL20S` | Months since oldest gold loan trade opened |
| 970 | `GL21S` | Months since most recent gold loan trade opened |
| 971 | `GL28S` | Total credit line of open gold loan trades verified in past 12 months |
| 972 | `GL29S` | Number of open gold loan trades with balance > $0 verified in past 12 months |
| 973 | `GL30S` | Percentage of open gold loan trades > 50% of credit line verified in past 12 months |
| 974 | `GL31S` | Percentage of open gold loan trades > 75% of credit line verified in past 12 months |
| 975 | `GL32S` | Maximum balance owed on open gold loan trades verified in past 12 months |
| 976 | `GL33S` | Total balance of open gold loan trades verified in past 12 months |
| 977 | `GL34S` | Utilization for open gold loan trades verified in past 12 months |
| 978 | `GL35S` | Average balance of open gold loan trades verified in past 12 months |
| 979 | `GL36S` | Months since most recent gold loan delinquency |
| 980 | `GL57S` | Total past due amount of open gold loan trades verified in past 12 months |
| 981 | `HI01S` | Number of home equity loan trades |
| 982 | `HI02S` | Number of open home equity loan trades |
| 983 | `HI06S` | Number of home equity loan trades opened in past 6 months |
| 984 | `HI09S` | Number of home equity loan trades opened in past 24 months |
| 985 | `HI101S` | Total balance of all home equity trades verified in past 12 months (BKAGBAL) |
| 986 | `HI12S` | Number of open home equity loan trades verified in past 12 months |
| 987 | `HI20S` | Months since oldest home equity loan trade opened |
| 988 | `HI21S` | Months since most recent home equity loan trade opened |
| 989 | `HI28S` | Total credit line of open home equity loan trades verified in past 12 months |
| 990 | `HI29S` | Number of open home equity loan trades with balance > $0 verified in past 12 months |
| 991 | `HI30S` | Percentage of open home equity loan trades > 50% of credit line verified in past 12 months |
| 992 | `HI31S` | Percentage of open home equity loan trades > 75% of credit line verified in past 12 months |
| 993 | `HI32S` | Maximum balance owed on open home equity loan trades verified in past 12 months |
| 994 | `HI33S` | Total balance of open home equity loan trades verified in past 12 months |
| 995 | `HI34S` | Utilization for open home equity loan trades verified in past 12 months |
| 996 | `HI35S` | Average balance of open home equity loan trades verified in past 12 months |
| 997 | `HI36S` | Months since most recent home equity loan delinquency |
| 998 | `HI57S` | Total past due amount of open home equity loan trades verified in past 12 months |
| 999 | `HIAP01` | Total scheduled monthly payment for open home equity trades verified in past 12 months |
| 1000 | `IN01S` | Number of installment trades |
| 1001 | `IN02S` | Number of open installment trades |
| 1002 | `IN06S` | Number of installment trades opened in past 6 months |
| 1003 | `IN09S` | Number of installment trades opened in past 24 months |
| 1004 | `IN101S` | Total balance of all installment trades verified in past 12 months (BKAGBAL) |
| 1005 | `IN12S` | Number of open installment trades verified in past 12 months |
| 1006 | `IN20S` | Months since oldest installment trade opened |
| 1007 | `IN21S` | Months since most recent installment trade opened |
| 1008 | `IN28S` | Total credit line of open installment trades verified in past 12 months |
| 1009 | `IN29S` | Number of open installment trades with balance > $0 verified in past 12 months |
| 1010 | `IN30S` | Percentage of open installment trades > 50% of credit line verified in past 12 months |
| 1011 | `IN31S` | Percentage of open installment trades > 75% of credit line verified in past 12 months |
| 1012 | `IN32S` | Maximum balance owed on open installment trades verified in past 12 months |
| 1013 | `IN33S` | Total balance of open installment trades verified in past 12 months |
| 1014 | `IN34S` | Utilization for open installment trades verified in past 12 months |
| 1015 | `IN35S` | Average balance of open installment trades verified in past 12 months |
| 1016 | `IN36S` | Months since most recent installment delinquency |
| 1017 | `IN57S` | Total past due amount of open installment trades verified in past 12 months |
| 1018 | `INAP01` | Total scheduled monthly payment for installment trades verified in past 12 months |
| 1019 | `INDEX01` | Annual year-over-year index |
| 1020 | `INDEX02` | Most recent quarter year-over-year index |
| 1021 | `INST_TRD` | Number of installment trades |
| 1022 | `JT01S` | Number of joint trades |
| 1023 | `JT02S` | Number of open joint trades |
| 1024 | `JT20S` | Months since oldest joint trade opened |
| 1025 | `JT21S` | Months since most recent joint trade opened |
| 1026 | `JT28S` | Total credit line of open joint trade verified in the past 12 months |
| 1027 | `JT33S` | Total balance of joint trades in the last 12 months |
| 1028 | `JT34S` | Utilization of open joint trades |
| 1029 | `JT40S` | Number of joint revolving trades |
| 1030 | `JT41S` | Number of joint installment or joint mortgage trades |
| 1031 | `JT42S` | Ratio of open joint trades to open trades |
| 1032 | `JT44S` | Total past due amount of joint trades |
| 1033 | `JT51S` | Months since most recent 30+ days past due on a joint trade |
| 1034 | `JT70S` | Ratio of dollars past due joint trades to total dollars past due trades |
| 1035 | `JT75S` | Number of joint trades 30 days past due or wors in the last 12 months |
| 1036 | `JT80S` | Number of nonMortgage and non-Auto joint trades with greater than 75% of utilization |
| 1037 | `MT01S` | Number of mortgage trades |
| 1038 | `MT02S` | Number of open mortgage trades |
| 1039 | `MT06S` | Number of mortgage trades opened in past 6 months |
| 1040 | `MT09S` | Number of mortgage trades opened in past 24 months |
| 1041 | `MT101S` | Total balance of all mortgage trades verified in past 12 months (BKAGBAL) |
| 1042 | `MT12S` | Number of open mortgage trades verified in past 12 months |
| 1043 | `MT20S` | Months since oldest mortgage trade opened |
| 1044 | `MT21S` | Months since most recent mortgage trade opened |
| 1045 | `MT28S` | Total credit line of open mortgage trades verified in past 12 months |
| 1046 | `MT29S` | Number of open mortgage trades with balance > $0 verified in past 12 months |
| 1047 | `MT30S` | Percentage of open mortgage trades > 50% of credit line verified in past 12 months |
| 1048 | `MT31S` | Percentage of open mortgage trades > 75% of credit line verified in past 12 months |
| 1049 | `MT32S` | Maximum balance owed on open mortgage trades verified in past 12 months |
| 1050 | `MT33S` | Total balance of open mortgage trades verified in past 12 months |
| 1051 | `MT34B` | Utilization for the most recently opened open mortgage trade verified in past 12 months |
| 1052 | `MT34C` | Utilization for open mortgage trades older than 12 months and verified in past 12 months |
| 1053 | `MT34S` | Utilization for open mortgage trades verified in past 12 months |
| 1054 | `MT35S` | Average balance of open mortgage trades verified in past 12 months |
| 1055 | `MT36S` | Months since most recent mortgage delinquency |
| 1056 | `MT47S` | Number of mortgage trade delinquencies in the past 12 months |
| 1057 | `MT57S` | Total past due amount of open mortgage trades verified in past 12 months |
| 1058 | `MTAP01` | Total scheduled monthly payment for mortgage trades verified in past 12 months |
| 1059 | `NON_MT_TRD` | Number of non-mortgage trades |
| 1060 | `NONMTFINTRD` | Number of non-mortgage financial  trades |
| 1061 | `PAYMNT01` | Number of installment events prepaying in last 3 mo |
| 1062 | `PAYMNT02` | Number of installment events prepaying in last 12 mo |
| 1063 | `PAYMNT03` | Total amount prepaid on installment last month |
| 1064 | `PAYMNT04` | Total amount prepaid on installment in last 3 mo |
| 1065 | `PAYMNT05` | Total amount prepaid on installment in last 12 mo |
| 1066 | `PAYMNT06` | Installment sum of actual to min pay ratio over last 6 mo |
| 1067 | `PAYMNT07` | Non-mortgage ratio actual to min pay over last month |
| 1068 | `PAYMNT08` | Revolving ratio actual to min pay over last month |
| 1069 | `PAYMNT09` | Bankcard ratio actual to min pay over last month |
| 1070 | `PAYMNT10` | Number of payments in last 3 months |
| 1071 | `PAYMNT11` | Number of payments in last 12 months |
| 1072 | `PAYMNT50` | Number of required payments in last month for financial trades |
| 1073 | `PAYMNT51` | Number of Required payments in last 3 months for financial trades |
| 1074 | `PAYMNT52` | Number of Required payments in last 6 months for financial trades |
| 1075 | `PAYMNT53` | Number of Required payments in last 12 months for financial trades |
| 1076 | `PAYMNT55` | Number of Missed payments in last month for financial trades |
| 1077 | `PAYMNT56` | Number of Missed payments in last 3 months for financial trades |
| 1078 | `PAYMNT57` | Number of Missed payments in last 6 months for financial trades |
| 1079 | `PAYMNT58` | Number of Missed payments in last 12 months for financial trades |
| 1080 | `PAYMNT60` | Missed payments ratio last month (lag required) for financial trades |
| 1081 | `PAYMNT61` | Missed payments ratio last 3 months (lag required) for financial trades |
| 1082 | `PAYMNT62` | Missed payments ratio last 6 months (lag required) for financial trades |
| 1083 | `PAYMNT63` | Missed payments ratio last 12 months (lag required) for financial trades |
| 1084 | `PAYMNT65` | Number of Required payments in last  month |
| 1085 | `PAYMNT66` | Number of Required payments in last 3 months |
| 1086 | `PAYMNT67` | Number of Required payments in last 6 months |
| 1087 | `PAYMNT68` | Number of Required payments in last 12 months |
| 1088 | `PAYMNT70` | Number of Missed payments in last month |
| 1089 | `PAYMNT71` | Number of Missed payments in last 3 months |
| 1090 | `PAYMNT72` | Number of Missed payments in last 6 months |
| 1091 | `PAYMNT73` | Number of Missed payments in last 12 months |
| 1092 | `PAYMNT75` | Missed payments ratio last month (lag required) |
| 1093 | `PAYMNT76` | Missed payments ratio last 3 months (lag required) |
| 1094 | `PAYMNT77` | Missed payments ratio last 6 months (lag required) |
| 1095 | `PAYMNT78` | Missed payments ratio last 12 months (lag required) |
| 1096 | `PER201` | Total payment ratio for personal loans over the past month |
| 1097 | `PER202` | Total payment ratio for personal loans over the past 3 months |
| 1098 | `PER203` | Total payment ratio for personal loans over the past 6 months |
| 1099 | `PER204` | Total payment ratio for personal loans over the past 12 months |
| 1100 | `PER205` | Total payment ratio for personal loans over the past 24 months |
| 1101 | `PER222` | Average payment ratio for personal loans over the past 3 months |
| 1102 | `PER223` | Average payment ratio for personal loans over the past 6 months |
| 1103 | `PER224` | Average payment ratio for personal loans over the past 12 months |
| 1104 | `PER225` | Average payment ratio for personal loans over the past 24 months |
| 1105 | `PER231` | Aggregate excess payment for personal loans over the past month |
| 1106 | `PER232` | Aggregate excess payment for personal loans over the past 3 months |
| 1107 | `PER233` | Aggregate excess payment for personal loans over the past 6 months |
| 1108 | `PER234` | Aggregate excess payment for personal loans over the past 12 months |
| 1109 | `PER235` | Aggregate excess payment for personal loans over the past 24 months |
| 1110 | `PER252` | Average aggregate excess payment for personal loans over the past 3 months |
| 1111 | `PER253` | Average aggregate excess payment for personal loans over the past 6 months |
| 1112 | `PER254` | Average aggregate excess payment for personal loans over the past 12 months |
| 1113 | `PER255` | Average aggregate excess payment for personal loans over the past 24 months |
| 1114 | `PL01S` | Number of personal loan trades |
| 1115 | `PL02S` | Number of open personal loan trades |
| 1116 | `PL06S` | Number of personal loan trades opened in past 6 months |
| 1117 | `PL09S` | Number of personal loan trades opened in past 24 months |
| 1118 | `PL101S` | Total balance of all personal loan trades verified in past 12 months |
| 1119 | `PL12S` | Number of open personal loan trades verified in past 12 months |
| 1120 | `PL20S` | Months since oldest personal loan trade opened |
| 1121 | `PL21S` | Months since most recent personal loan trade opened |
| 1122 | `PL28S` | Total credit line of open personal loan trades verified in past 12 months |
| 1123 | `PL29S` | Number of open personal loan trades with balance > $0 verified in past 12 months |
| 1124 | `PL30S` | Percentage of open personal loan trades > 50% of credit line verified in past 12 months |
| 1125 | `PL31S` | Percentage of open personal loan trades > 75% of credit line verified in past 12 months |
| 1126 | `PL32S` | Maximum balance owed on open personal loan trades verified in past 12 months |
| 1127 | `PL33S` | Total balance of open personal loan trades verified in past 12 months |
| 1128 | `PL34S` | Utilization for open personal loan trades verified in past 12 months |
| 1129 | `PL35S` | Average balance of open personal loan trades verified in past 12 months |
| 1130 | `PL36S` | Months since most recent personal loan delinquency |
| 1131 | `PL57S` | Total past due amount of open personal loan trades verified in past 12 months |
| 1132 | `PLRI01S` | Number of personal & retail installment loan trades |
| 1133 | `PLRI02S` | Number of open personal & retail installment loan trades |
| 1134 | `PLRI06S` | Number of personal & retail installment loan trades opened in past 6 months |
| 1135 | `PLRI09S` | Number of personal & retail installment loan trades opened in past 24 months |
| 1136 | `PLRI101S` | Total balance of all personal & retail installment loan trades verified in past 12 months |
| 1137 | `PLRI12S` | Number of open personal & retail installment loan trades verified in past 12 months |
| 1138 | `PLRI20S` | Months since oldest personal & retail installment loan trade opened |
| 1139 | `PLRI21S` | Months since most recent personal & retail installment loan trade opened |
| 1140 | `PLRI28S` | Total credit line of open personal & retail installment loan trades verified in past 12 months |
| 1141 | `PLRI29S` | Number of open personal & retail installment loan trades with balance > $0 verified in past 12 months |
| 1142 | `PLRI30S` | Percentage of open personal & retail installment loan trades > 50% of credit line verified in past 12 months |
| 1143 | `PLRI31S` | Percentage of open personal & retail installment loan trades > 75% of credit line verified in past 12 months |
| 1144 | `PLRI32S` | Maximum balance owed on open personal & retail installment loan trades verified in past 12 months |
| 1145 | `PLRI33S` | Total balance of open personal & retail installment loan trades verified in past 12 months |
| 1146 | `PLRI34S` | Utilization for open personal & retail installment loan trades verified in past 12 months |
| 1147 | `PLRI35S` | Average balance of open personal & retail installment loan trades verified in past 12 months |
| 1148 | `PLRI36S` | Months since most recent personal & retail installment loan delinquency |
| 1149 | `PLRI57S` | Total past due amount of open personal & retail installment loan trades verified in past 12 months |
| 1150 | `RE01S` | Number of revolving trades |
| 1151 | `RE02S` | Number of open revolving trades |
| 1152 | `RE06S` | Number of revolving trades opened in past 6 months |
| 1153 | `RE09S` | Number of revolving trades opened in past 24 months |
| 1154 | `RE101S` | Total balance of all revolving trades verified in past 12 months (BKAGBAL) |
| 1155 | `RE102S` | Average credit line of open revolving trades verified in past 12 months (TB072) |
| 1156 | `RE12S` | Number of open revolving trades verified in past 12 months |
| 1157 | `RE20S` | Months since oldest revolving trade opened |
| 1158 | `RE21S` | Months since most recent revolving trade opened |
| 1159 | `RE28S` | Total credit line of open revolving trades verified in past 12 months |
| 1160 | `RE29S` | Number of open revolving trades with balance > $0 verified in past 12 months |
| 1161 | `RE30S` | Percentage of open revolving trades > 50% of credit line verified in past 12 months |
| 1162 | `RE31S` | Percentage of open revolving trades > 75% of credit line verified in past 12 months |
| 1163 | `RE32S` | Maximum balance owed on open revolving trades verified in past 12 months |
| 1164 | `RE33S` | Total balance of open revolving trades verified in past 12 months |
| 1165 | `RE34S` | Utilization for open revolving trades verified in past 12 months |
| 1166 | `RE35S` | Average balance of open revolving trades verified in past 12 months |
| 1167 | `RE36S` | Months since most recent revolving delinquency |
| 1168 | `RE57S` | Total past due amount of open revolving trades verified in past 12 months |
| 1169 | `REAP01` | Total scheduled monthly payment for revolving trades verified in past 12 months |
| 1170 | `RET102` | Number of months in the past 12 months where percentage of retail accounts utilized less than 50% was more than 25% |
| 1171 | `RET11` | Number of instances where a retail account was utilized more than 25% in the past 12 months |
| 1172 | `RET112` | Number of months in the past 12 months where percentage of retail accounts utilized less than 75% was more than 25% |
| 1173 | `RET12` | Number of instances where a retail account was utilized more than 50% in the past 12 months |
| 1174 | `RET122` | Number of months in the past 12 months where percentage of retail accounts utilized less than 100% was more than 25% |
| 1175 | `RET13` | Number of instances where a retail account was utilized more than 75% in the past 12 months |
| 1176 | `RET132` | Number of months in the past 12 months where percentage of retail accounts utilized more than 25% was more than 90% |
| 1177 | `RET14` | Number of instances where a retail account was utilized more than 90% in the past 12 months |
| 1178 | `RET142` | Number of months in the past 12 months where percentage of retail accounts utilized more than 50% was more than 90% |
| 1179 | `RET152` | Number of months in the past 12 months where percentage of retail accounts utilized more than 75% was more than 90% |
| 1180 | `RET162` | Number of months in the past 12 months where percentage of retail accounts utilized more than 100% was more than 90% |
| 1181 | `RET201` | Total payment ratio for retail accounts over the past month |
| 1182 | `RET202` | Total payment ratio for retail accounts over the past 3 months |
| 1183 | `RET203` | Total payment ratio for retail accounts over the past 6 months |
| 1184 | `RET204` | Total payment ratio for retail accounts over the past 12 months |
| 1185 | `RET205` | Total payment ratio for retail accounts over the past 24 months |
| 1186 | `RET222` | Average payment ratio for retail accounts over the past 3 months |
| 1187 | `RET223` | Average payment ratio for retail accounts over the past 6 months |
| 1188 | `RET224` | Average payment ratio for retail accounts over the past 12 months |
| 1189 | `RET225` | Average payment ratio for retail accounts over the past 24 months |
| 1190 | `RET231` | Aggregate excess payment for retail accounts over the past month |
| 1191 | `RET232` | Aggregate excess payment for retail accounts over the past 3 months |
| 1192 | `RET233` | Aggregate excess payment for retail accounts over the past 6 months |
| 1193 | `RET234` | Aggregate excess payment for retail accounts over the past 12 months |
| 1194 | `RET235` | Aggregate excess payment for retail accounts over the past 24 months |
| 1195 | `RET252` | Average aggregate excess payment for retail accounts over the past 3 months |
| 1196 | `RET253` | Average aggregate excess payment for retail accounts over the past 6 months |
| 1197 | `RET254` | Average aggregate excess payment for retail accounts over the past 12 months |
| 1198 | `RET255` | Average aggregate excess payment for retail accounts over the past 24 months |
| 1199 | `RET51` | Number of retail accounts utilized more than 25% in the past 12 months |
| 1200 | `RET52` | Number of retail accounts utilized more than 50% in the past 12 months |
| 1201 | `RET53` | Number of retail accounts utilized more than 75% in the past 12 months |
| 1202 | `RET54` | Number of retail accounts utilized more than 90% in the past 12 months |
| 1203 | `RET81` | Months since a retail account last exceeded 25% utilization |
| 1204 | `RET82` | Months since a retail account last exceeded 50% utilization |
| 1205 | `RET83` | Months since a retail account last exceeded 75% utilization |
| 1206 | `RET84` | Months since a retail account last exceeded 90% utilization |
| 1207 | `RET92` | Number of months in the past 12 months where percentage of retail accounts utilized less than 25% was more than 25% |
| 1208 | `REV_TRD` | Number of revolving trades |
| 1209 | `REV102` | Number of months in the past 12 months where percentage of revolving accounts utilized less than 50% was more than 25% |
| 1210 | `REV11` | Number of instances where a revolving account was utilized more than 25% in the past 12 months |
| 1211 | `REV112` | Number of months in the past 12 months where percentage of revolving accounts utilized less than 75% was more than 25% |
| 1212 | `REV12` | Number of instances where a revolving account was utilized more than 50% in the past 12 months |
| 1213 | `REV122` | Number of months in the past 12 months where percentage of revolving accounts utilized less than 100% was more than 25% |
| 1214 | `REV13` | Number of instances where a revolving account was utilized more than 75% in the past 12 months |
| 1215 | `REV132` | Number of months in the past 12 months where percentage of revolving accounts utilized more than 25% was more than 90% |
| 1216 | `REV14` | Number of instances where a revolving account was utilized more than 90% in the past 12 months |
| 1217 | `REV142` | Number of months in the past 12 months where percentage of revolving accounts utilized more than 50% was more than 90% |
| 1218 | `REV152` | Number of months in the past 12 months where percentage of revolving accounts utilized more than 75% was more than 90% |
| 1219 | `REV162` | Number of months in the past 12 months where percentage of revolving accounts utilized more than 100% was more than 90% |
| 1220 | `REV201` | Total payment ratio for revolving accounts over the past month |
| 1221 | `REV202` | Total payment ratio for revolving accounts over the past 3 months |
| 1222 | `REV203` | Total payment ratio for revolving accounts over the past 6 months |
| 1223 | `REV204` | Total payment ratio for revolving accounts over the past 12 months |
| 1224 | `REV205` | Total payment ratio for revolving accounts over the past 24 months |
| 1225 | `REV222` | Average payment ratio for revolving accounts over the past 3 months |
| 1226 | `REV223` | Average payment ratio for revolving accounts over the past 6 months |
| 1227 | `REV224` | Average payment ratio for revolving accounts over the past 12 months |
| 1228 | `REV225` | Average payment ratio for revolving accounts over the past 24 months |
| 1229 | `REV231` | Aggregate excess payment for revolving accounts over the past month |
| 1230 | `REV232` | Aggregate excess payment for revolving accounts over the past 3 months |
| 1231 | `REV233` | Aggregate excess payment for revolving accounts over the past 6 months |
| 1232 | `REV234` | Aggregate excess payment for revolving accounts over the past 12 months |
| 1233 | `REV235` | Aggregate excess payment for revolving accounts over the past 24 months |
| 1234 | `REV252` | Average aggregate excess payment for revolving accounts over the past 3 months |
| 1235 | `REV253` | Average aggregate excess payment for revolving accounts over the past 6 months |
| 1236 | `REV254` | Average aggregate excess payment for revolving accounts over the past 12 months |
| 1237 | `REV255` | Average aggregate excess payment for revolving accounts over the past 24 months |
| 1238 | `REV51` | Number of revolving accounts utilized more than 25% in the past 12 months |
| 1239 | `REV52` | Number of revolving accounts utilized more than 50% in the past 12 months |
| 1240 | `REV53` | Number of revolving accounts utilized more than 75% in the past 12 months |
| 1241 | `REV54` | Number of revolving accounts utilized more than 90% in the past 12 months |
| 1242 | `REV81` | Months since a revolving account last exceeded 25% utilization |
| 1243 | `REV82` | Months since a revolving account last exceeded 50% utilization |
| 1244 | `REV83` | Months since a revolving account last exceeded 75% utilization |
| 1245 | `REV84` | Months since a revolving account last exceeded 90% utilization |
| 1246 | `REV92` | Number of months in the past 12 months where percentage of revolving accounts utilized less than 25% was more than 25% |
| 1247 | `RT01S` | Number of retail trades |
| 1248 | `RT02S` | Number of open retail trades |
| 1249 | `RT06S` | Number of retail trades opened in past 6 months |
| 1250 | `RT09S` | Number of retail trades opened in past 24 months |
| 1251 | `RT101S` | Total balance of all retail trades verified in past 12 months (BKAGBAL) |
| 1252 | `RT12S` | Number of open retail trades verified in past 12 months |
| 1253 | `RT201S` | Highest balance of retail trades |
| 1254 | `RT20S` | Months since oldest retail trade opened |
| 1255 | `RT21S` | Months since most recent retail trade opened |
| 1256 | `RT28S` | Total credit line of open retail trades verified in past 12 months |
| 1257 | `RT29S` | Number of open retail trades with balance > $0 verified in past 12 months |
| 1258 | `RT30S` | Percentage of open retail trades > 50% of credit line verified in past 12 months |
| 1259 | `RT31S` | Percentage of open retail trades > 75% of credit line verified in past 12 months |
| 1260 | `RT32S` | Maximum balance owed on open retail trades verified in past 12 months |
| 1261 | `RT33S` | Total balance of open retail trades verified in past 12 months |
| 1262 | `RT34S` | Utilization for open retail trades verified in past 12 months |
| 1263 | `RT35S` | Average balance of open retail trades verified in past 12 months |
| 1264 | `RT36S` | Months since most recent retail delinquency |
| 1265 | `RT57S` | Total past due amount of open retail trades verified in past 12 months |
| 1266 | `RTL_TRD` | Number of Retail Trades |
| 1267 | `RVLR01` | Revolver bankcard utilization |
| 1268 | `RVLR03` | Total revolver bankcard balance |
| 1269 | `RVLR05` | Ratio of revolver bankcard to total bankcard balance |
| 1270 | `RVLR07` | Revolver bankcards |
| 1271 | `RVLR08` | Revolver bankcards over past 3 months |
| 1272 | `RVLR09` | Revolver bankcards over past 6 months |
| 1273 | `RVLR10` | Number of revolver bankcards on newly opened cards |
| 1274 | `S004S` | Average number of months trades have been on file |
| 1275 | `S043S` | Number of open trades > 50% of credit line verified in past 12 months (excluding installments and mortgages) |
| 1276 | `S061S` | Months since most recent 60 or more days past due |
| 1277 | `S062S` | Months since most recent 90 or more days past due |
| 1278 | `SE01S` | Number of secured installment trades |
| 1279 | `SE02S` | Number of open secured installment trades |
| 1280 | `SE06S` | Number of secured installment trades opened in past 6 months |
| 1281 | `SE09S` | Number of secured installment trades opened in past 24 months |
| 1282 | `SE101S` | Total balance of all secured installment trades verified in past 12 months |
| 1283 | `SE12S` | Number of open secured installment trades verified in past 12 months |
| 1284 | `SE20S` | Months since oldest secured installment trade opened |
| 1285 | `SE21S` | Months since most recent secured installment trade opened |
| 1286 | `SE28S` | Total credit line of open secured installment trades verified in past 12 months |
| 1287 | `SE29S` | Number of open secured installment trades with balance > $0 verified in past 12 months |
| 1288 | `SE30S` | Percentage of open secured installment trades > 50% of credit line verified in past 12 months |
| 1289 | `SE31S` | Percentage of open secured installment trades > 75% of credit line verified in past 12 months |
| 1290 | `SE32S` | Maximum balance owed on open secured installment trades verified in past 12 months |
| 1291 | `SE33S` | Total balance of open secured installment trades verified in past 12 months |
| 1292 | `SE34S` | Utilization for open secured installment trades verified in past 12 months |
| 1293 | `SE35S` | Average balance of open secured installment trades verified in past 12 months |
| 1294 | `SE36S` | Months since most recent secured installment delinquency |
| 1295 | `SE57S` | Total past due amount of open secured installment trades verified in past 12 months |
| 1296 | `TRD` | Number of trades |
| 1297 | `TRV01` | Number of months since overlimit on a bankcard |
| 1298 | `TRV02` | Number of months a bankcard overlimit in the last 12 months |
| 1299 | `TRV03` | Number of non-mortgage balance increases (prior month to current month) |
| 1300 | `TRV04` | Number of non-mortgage balance increases over the past quarter |
| 1301 | `TRV05` | Number of non-mortgage balance increase over the last 12 months |
| 1302 | `TRV06` | Number of months with a non-mortgage balance increase over the last 12 months |
| 1303 | `TRV07` | Number of non-mortgage balance decreases (prior month to current month) |
| 1304 | `TRV08` | Number of non-mortgage balance decreases over the past quarter |
| 1305 | `TRV09` | Number of non-mortgage balance decreases over the last 12 months |
| 1306 | `TRV10` | Number of months with a non-mortgage balance decrease over the last 12 months |
| 1307 | `TRV11` | Number of revolving H/C increases (prior month to current month) |
| 1308 | `TRV12` | Number of H/C increases over the past quarter |
| 1309 | `TRV13` | Number of revolving H/C increases over the last 12 months |
| 1310 | `TRV14` | Number of months with a revolving H/C increases over the last 12 months |
| 1311 | `TRV15` | Number of credit line increases (prior month to current month) |
| 1312 | `TRV16` | Number of credit line increases over the past quarter |
| 1313 | `TRV17` | Number of credit line increases over the last 12 months |
| 1314 | `TRV18` | Number of months with a credit line increases over the last 12 months |
| 1315 | `TRV19` | Number of credit line decreases (prior month to current month) |
| 1316 | `TRV20` | Number of credit line decreases over the past quarter |
| 1317 | `TRV21` | Number of credit line decreases over the last 12 months |
| 1318 | `TRV22` | Number of months with a credit line decreases over the last 12 months |
| 1319 | `TRV23` | Number of mortgage balance decreases over the last 6 months |
| 1320 | `TW01S` | Number of two wheeler loan trades |
| 1321 | `TW02S` | Number of open two wheeler loan trades |
| 1322 | `TW06S` | Number of two wheeler loan trades opened in past 6 months |
| 1323 | `TW09S` | Number of two wheeler loan trades opened in past 24 months |
| 1324 | `TW101S` | Total balance of all two wheeler loan trades verified in past 12 months |
| 1325 | `TW12S` | Number of open two wheeler loan trades verified in past 12 months |
| 1326 | `TW20S` | Months since oldest two wheeler loan trade opened |
| 1327 | `TW21S` | Months since most recent two wheeler loan trade opened |
| 1328 | `TW28S` | Total credit line of open two wheeler loan trades verified in past 12 months |
| 1329 | `TW29S` | Number of open two wheeler loan trades with balance > $0 verified in past 12 months |
| 1330 | `TW30S` | Percentage of open two wheeler loan trades > 50% of credit line verified in past 12 months |
| 1331 | `TW31S` | Percentage of open two wheeler loan trades > 75% of credit line verified in past 12 months |
| 1332 | `TW32S` | Maximum balance owed on open two wheeler loan trades verified in past 12 months |
| 1333 | `TW33S` | Total balance of open two wheeler loan trades verified in past 12 months |
| 1334 | `TW34S` | Utilization for open two wheeler loan trades verified in past 12 months |
| 1335 | `TW35S` | Average balance of open two wheeler loan trades verified in past 12 months |
| 1336 | `TW36S` | Months since most recent two wheeler loan delinquency |
| 1337 | `TW57S` | Total past due amount of open two wheeler loan trades verified in past 12 months |
| 1338 | `TWO201` | Total payment ratio for two wheeler loans over the past month |
| 1339 | `TWO202` | Total payment ratio for two wheeler loans over the past 3 months |
| 1340 | `TWO203` | Total payment ratio for two wheeler loans over the past 6 months |
| 1341 | `TWO204` | Total payment ratio for two wheeler loans over the past 12 months |
| 1342 | `TWO205` | Total payment ratio for two wheeler loans over the past 24 months |
| 1343 | `TWO222` | Average payment ratio for two wheeler loans over the past 3 months |
| 1344 | `TWO223` | Average payment ratio for two wheeler loans over the past 6 months |
| 1345 | `TWO224` | Average payment ratio for two wheeler loans over the past 12 months |
| 1346 | `TWO225` | Average payment ratio for two wheeler loans over the past 24 months |
| 1347 | `TWO231` | Aggregate excess payment for two wheeler loans over the past month |
| 1348 | `TWO232` | Aggregate excess payment for two wheeler loans over the past 3 months |
| 1349 | `TWO233` | Aggregate excess payment for two wheeler loans over the past 6 months |
| 1350 | `TWO234` | Aggregate excess payment for two wheeler loans over the past 12 months |
| 1351 | `TWO235` | Aggregate excess payment for two wheeler loans over the past 24 months |
| 1352 | `TWO252` | Average aggregate excess payment for two wheeler loans over the past 3 months |
| 1353 | `TWO253` | Average aggregate excess payment for two wheeler loans over the past 6 months |
| 1354 | `TWO254` | Average aggregate excess payment for two wheeler loans over the past 12 months |
| 1355 | `TWO255` | Average aggregate excess payment for two wheeler loans over the past 24 months |
| 1356 | `UL_TRD` | Number of unsecured loan trades |
| 1357 | `US01S` | Number of unsecured installment trades |
| 1358 | `US02S` | Number of open unsecured installment trades |
| 1359 | `US06S` | Number of unsecured installment trades opened in past 6 months |
| 1360 | `US09S` | Number of unsecured installment trades opened in past 24 months |
| 1361 | `US101S` | Total balance of all unsecured installment trades verified in past 12 months |
| 1362 | `US12S` | Number of open unsecured installment trades verified in past 12 months |
| 1363 | `US20S` | Months since oldest unsecured installment trade opened |
| 1364 | `US21S` | Months since most recent unsecured installment trade opened |
| 1365 | `US28S` | Total credit line of open unsecured installment trades verified in past 12 months |
| 1366 | `US29S` | Number of open unsecured installment trades with balance > $0 verified in past 12 months |
| 1367 | `US30S` | Percentage of open unsecured installment trades > 50% of credit line verified in past 12 months |
| 1368 | `US31S` | Percentage of open unsecured installment trades > 75% of credit line verified in past 12 months |
| 1369 | `US32S` | Maximum balance owed on open unsecured installment trades verified in past 12 months |
| 1370 | `US33S` | Total balance of open unsecured installment trades verified in past 12 months |
| 1371 | `US34S` | Utilization for open unsecured installment trades verified in past 12 months |
| 1372 | `US35S` | Average balance of open unsecured installment trades verified in past 12 months |
| 1373 | `US36S` | Months since most recent unsecured installment delinquency |
| 1374 | `US51A` | Terms in months of most recent unsecured installment |
| 1375 | `US57S` | Total past due amount of open unsecured installment trades verified in past 12 months |
| 1376 | `WALSHR09` | Months since w/s shift >25% w/in 24 |
| 1377 | `WALSHR10` | Months since w/s shift >50% w/in 24 |

## Final instruction

Create the complete CSV now. Return the CSV as a downloadable file and report only its shape, bad count, good count, bad rate, and schema-validation result. Do not return generation code.
