"""Prepare the synthetic bureau CSVs for feature-development work.

The source CSVs are never modified.  Corrected copies and a validation report are
written to ``development_data`` by default.

This module deliberately repairs only fields whose meaning is sufficiently clear
from the supplied glossary.  It does not claim to reproduce proprietary bureau
features; the application-level file remains synthetic reference data.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


DPD_COLUMNS = [f"p_hist_{month:02d}" for month in range(1, 37)]
KEY_COLUMNS = ["custid", "mrn"]

PRODUCT_PREFIXES = {
    "AU": {"AUTO_LOAN"},
    "BC": {"CREDIT_CARD"},
    "GL": {"GOLD_LOAN"},
    "HI": {"HOME_EQUITY"},
    "MT": {"MORTGAGE"},
    "PL": {"PERSONAL_LOAN"},
    "RT": {"RETAIL_LOAN"},
    "TW": {"TWO_WHEELER"},
}

DATE_COLUMNS_TRD = [
    "input_date",
    "run_date",
    "report_dt",
    "close_dt",
    "opened_dt",
    "pmt_start_dt",
    "pmt_end_dt",
    "last_pmt_dt",
]
DATE_COLUMNS_INQ = ["input_date", "run_date", "enq_date"]


def _require_columns(frame: pd.DataFrame, required: Iterable[str], frame_name: str) -> None:
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(f"{frame_name} is missing required columns: {missing}")


def _parse_dates(frame: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    for column in columns:
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
    return frame


def _stable_factor(value: object, low: float = 0.55, high: float = 1.45) -> float:
    """Return a deterministic pseudo-random factor for a stable identifier."""

    digest = hashlib.sha256(str(value).encode("utf-8")).digest()
    unit = int.from_bytes(digest[:8], "big") / float(2**64 - 1)
    return low + (high - low) * unit


def normalize_live_closed(series: pd.Series) -> pd.Series:
    """Normalize common bureau/synthetic live-closed encodings to 1/0."""

    normalized = series.astype("string").str.strip().str.upper()
    mapping = {
        "LIVE": 1,
        "OPEN": 1,
        "1": 1,
        "TRUE": 1,
        "CLOSED": 0,
        "CLOSE": 0,
        "0": 0,
        "FALSE": 0,
    }
    result = normalized.map(mapping)
    if result.isna().any():
        bad = sorted(normalized[result.isna()].dropna().unique().tolist())
        raise ValueError(f"Unrecognized LIVE_CLOSED values: {bad}")
    return result.astype("int8")


def derive_product_flag(tradelines: pd.DataFrame) -> pd.Series:
    """Derive SECURED/UNSECURED from collateral, with product fallbacks."""

    collateral = tradelines["collataral_type"].astype("string").str.upper().str.strip()
    product = tradelines["acct_type"].astype("string").str.upper().str.strip()
    result = pd.Series("SECURED", index=tradelines.index, dtype="string")
    result.loc[collateral.eq("UNSECURED")] = "UNSECURED"
    result.loc[product.isin({"CREDIT_CARD", "PERSONAL_LOAN", "REVOLVING", "UNSECURED_INSTALLMENT"})] = "UNSECURED"
    return result


def repair_closed_high_credit(tradelines: pd.DataFrame) -> pd.DataFrame:
    """Replace the synthetic value 1 on closed accounts with plausible amounts.

    Product-level medians are learned only from live accounts.  A stable factor
    based on account number avoids making every imputed closed account identical.
    """

    live = tradelines["LIVE_CLOSED"].eq(1)
    valid_live = live & tradelines["high_credit"].gt(1)
    medians = (
        tradelines.loc[valid_live]
        .groupby("acct_type", observed=True)["high_credit"]
        .median()
    )
    overall = float(tradelines.loc[valid_live, "high_credit"].median())
    bad_closed = (~live) & tradelines["high_credit"].le(1)
    if not bad_closed.any():
        return tradelines

    bases = tradelines.loc[bad_closed, "acct_type"].map(medians).fillna(overall)
    factors = tradelines.loc[bad_closed, "acct_num"].map(_stable_factor)
    imputed = (bases.astype(float) * factors.astype(float) / 1_000).round() * 1_000
    tradelines.loc[bad_closed, "high_credit"] = imputed.clip(lower=1_000).astype("int64")
    return tradelines


def _calendar_months_between(later: pd.Series, earlier: pd.Series) -> pd.Series:
    months = (later.dt.year - earlier.dt.year) * 12 + later.dt.month - earlier.dt.month
    return months.clip(lower=0).astype("Int64")


def repair_payment_history(tradelines: pd.DataFrame) -> pd.DataFrame:
    """Repair the history anchor dates and DPD summary fields."""

    vintage = _calendar_months_between(tradelines["input_date"], tradelines["opened_dt"])
    tradelines["Credit_vintage"] = vintage

    # p_hist_01 is the latest reported month.  Months before account opening use
    # the -1 not-applicable code from the supplied sample rather than clean DPD=0.
    history = tradelines[DPD_COLUMNS].apply(pd.to_numeric, errors="coerce").fillna(-1).astype("int16")
    available = (vintage.fillna(0) + 1).clip(lower=1, upper=36).to_numpy()
    positions = np.arange(36)[None, :]
    history_array = history.to_numpy(copy=True)
    history_array[positions >= available[:, None]] = -1
    tradelines.loc[:, DPD_COLUMNS] = history_array

    anchor = tradelines["report_dt"].dt.to_period("M").dt.to_timestamp()
    tradelines["pmt_start_dt"] = anchor
    end_offsets = available - 1
    end_periods = anchor.dt.to_period("M").astype("int64") - end_offsets
    tradelines["pmt_end_dt"] = pd.PeriodIndex.from_ordinals(
        end_periods.to_numpy(), freq="M"
    ).to_timestamp()

    valid_history = np.where(history_array >= 0, history_array, -1)
    tradelines["Max hist"] = valid_history.max(axis=1).astype("int16")

    for threshold in (30, 60, 90):
        hits = history_array >= threshold
        has_hit = hits.any(axis=1)
        most_recent = hits.argmax(axis=1)
        oldest = 35 - np.flip(hits, axis=1).argmax(axis=1)

        months_column = f"Month Since{threshold}+"
        first_column = f"First Month Since{threshold}+"
        tradelines[months_column] = pd.Series(most_recent, index=tradelines.index).where(has_hit).astype("Int64")

        first_periods = anchor.dt.to_period("M").astype("int64") - oldest
        first_dates = pd.Series(
            pd.PeriodIndex.from_ordinals(first_periods.to_numpy(), freq="M").to_timestamp(),
            index=tradelines.index,
        )
        tradelines[first_column] = first_dates.where(has_hit)

    return tradelines


def repair_tradelines(tradelines: pd.DataFrame) -> pd.DataFrame:
    required = KEY_COLUMNS + [
        "input_date",
        "run_date",
        "report_dt",
        "acct_num",
        "acct_type",
        "LIVE_CLOSED",
        "PRODUCT_FLAG",
        "collataral_type",
        "opened_dt",
        "cur_balance",
        "high_credit",
        "credit_limit",
        "amt_past_due",
    ] + DPD_COLUMNS
    _require_columns(tradelines, required, "tradeline_level.csv")
    tradelines = _parse_dates(tradelines.copy(), DATE_COLUMNS_TRD)
    tradelines["acct_type"] = tradelines["acct_type"].astype("string").str.upper().str.strip()
    tradelines["LIVE_CLOSED"] = normalize_live_closed(tradelines["LIVE_CLOSED"])
    tradelines["PRODUCT_FLAG"] = derive_product_flag(tradelines)
    tradelines = repair_closed_high_credit(tradelines)
    tradelines = repair_payment_history(tradelines)

    positive_limit = tradelines["credit_limit"].gt(0)
    utilization = pd.Series(0.0, index=tradelines.index)
    utilization.loc[positive_limit] = (
        tradelines.loc[positive_limit, "cur_balance"]
        / tradelines.loc[positive_limit, "credit_limit"]
        * 100
    )
    tradelines["Credit Utilization"] = utilization.clip(lower=0, upper=100).round(2)
    return tradelines


def repair_enquiries(enquiries: pd.DataFrame) -> pd.DataFrame:
    required = KEY_COLUMNS + DATE_COLUMNS_INQ + ["ecn", "enq_purpose", "enq_amt"]
    _require_columns(enquiries, required, "enquiry_level.csv")
    enquiries = _parse_dates(enquiries.copy(), DATE_COLUMNS_INQ)
    enquiries["enq_purpose"] = enquiries["enq_purpose"].astype("string").str.upper().str.strip()
    if (enquiries["enq_date"] > enquiries["input_date"]).any():
        raise ValueError("Enquiry file contains enquiries after the application date")
    return enquiries


def _months_since(reference: pd.Series, event: pd.Series) -> pd.Series:
    return ((reference.dt.year - event.dt.year) * 12 + reference.dt.month - event.dt.month).astype("Int64")


def _grouped_sum(frame: pd.DataFrame, mask: pd.Series, column: str, output: str) -> pd.DataFrame:
    return (
        frame.loc[mask]
        .groupby(KEY_COLUMNS, observed=True)[column]
        .sum()
        .rename(output)
        .reset_index()
    )


def _assign_from_group(application: pd.DataFrame, grouped: pd.DataFrame, column: str) -> None:
    lookup = grouped.set_index(KEY_COLUMNS)[column]
    keys = pd.MultiIndex.from_frame(application[KEY_COLUMNS])
    application[column] = lookup.reindex(keys, fill_value=0).to_numpy()


def repair_application(
    application: pd.DataFrame,
    tradelines: pd.DataFrame,
    enquiries: pd.DataFrame,
) -> pd.DataFrame:
    """Recalculate unambiguous application features from lower-level records."""

    required = KEY_COLUMNS + ["application_date", "bad_flag"]
    _require_columns(application, required, "application_level.csv")
    application = application.copy()
    application["application_date"] = pd.to_datetime(application["application_date"], errors="coerce")

    grouped = tradelines.groupby(KEY_COLUMNS, observed=True)
    counts = grouped.size().rename("TRD").reset_index()
    counts["AT01S"] = counts["TRD"]
    _assign_from_group(application, counts, "TRD")
    _assign_from_group(application, counts, "AT01S")

    open_counts = grouped["LIVE_CLOSED"].sum().rename("AT02S").reset_index()
    _assign_from_group(application, open_counts, "AT02S")

    # Clear product-count families.  Only direct product mappings are changed.
    for prefix, products in PRODUCT_PREFIXES.items():
        product_mask = tradelines["acct_type"].isin(products)
        product_count = (
            tradelines.loc[product_mask]
            .groupby(KEY_COLUMNS, observed=True)
            .size()
            .rename(f"{prefix}01S")
            .reset_index()
        )
        open_product_count = (
            tradelines.loc[product_mask & tradelines["LIVE_CLOSED"].eq(1)]
            .groupby(KEY_COLUMNS, observed=True)
            .size()
            .rename(f"{prefix}02S")
            .reset_index()
        )
        for frame, column in ((product_count, f"{prefix}01S"), (open_product_count, f"{prefix}02S")):
            if column in application:
                _assign_from_group(application, frame, column)
    if "BC_TRD" in application:
        application["BC_TRD"] = application["BC01S"]

    all_rows = pd.Series(True, index=tradelines.index)
    bankcard = tradelines["acct_type"].eq("CREDIT_CARD")
    non_mortgage = ~tradelines["acct_type"].isin({"MORTGAGE", "HOME_EQUITY"})
    unsecured = tradelines["PRODUCT_FLAG"].eq("UNSECURED")

    current_aggregates = [
        (all_rows, "cur_balance", "AGG9101"),
        (all_rows, "credit_limit", "AGG9201"),
        (all_rows, "amt_past_due", "AGG9301"),
        (non_mortgage, "cur_balance", "AGG101"),
        (non_mortgage, "credit_limit", "AGG201"),
        (non_mortgage, "amt_past_due", "AGG301"),
        (bankcard, "cur_balance", "AGG501"),
        (bankcard, "credit_limit", "AGG601"),
        (bankcard, "amt_past_due", "AGG701"),
        (unsecured, "credit_limit", "AGG1101"),
        (unsecured, "amt_past_due", "AGG1201"),
    ]
    for mask, source, output in current_aggregates:
        if output in application:
            values = _grouped_sum(tradelines, mask, source, output)
            _assign_from_group(application, values, output)

    # Repair AGG1002-AGG1009 by interpolating between the raw current unsecured
    # balance (conceptual M01) and the already monetary AGG1010 value.
    unsecured_now = _grouped_sum(tradelines, unsecured, "cur_balance", "_unsecured_m01")
    lookup = unsecured_now.set_index(KEY_COLUMNS)["_unsecured_m01"]
    keys = pd.MultiIndex.from_frame(application[KEY_COLUMNS])
    month_1 = lookup.reindex(keys, fill_value=0).to_numpy(dtype=float)
    month_10 = application["AGG1010"].to_numpy(dtype=float)
    for month in range(2, 10):
        column = f"AGG10{month:02d}"
        weight = (month - 1) / 9
        application[column] = np.maximum(0, np.rint(month_1 * (1 - weight) + month_10 * weight)).astype("int64")

    # Enquiry totals and calendar-window counts.
    inq = enquiries.copy()
    app_dates = application.set_index(KEY_COLUMNS)["application_date"]
    inq_keys = pd.MultiIndex.from_frame(inq[KEY_COLUMNS])
    inq["_application_date"] = app_dates.reindex(inq_keys).to_numpy()
    age_days = (inq["_application_date"] - inq["enq_date"]).dt.days
    enquiry_specs = [
        (pd.Series(True, index=inq.index), "G232S"),
        (age_days.le(92), "G242S"),
        (age_days.le(183), "G243S"),
        (age_days.le(365), "G244S"),
    ]
    for mask, output in enquiry_specs:
        if output in application:
            values = (
                inq.loc[mask]
                .groupby(KEY_COLUMNS, observed=True)
                .size()
                .rename(output)
                .reset_index()
            )
            _assign_from_group(application, values, output)

    most_recent = enquiries.groupby(KEY_COLUMNS, observed=True)["enq_date"].max().rename("_recent_enquiry").reset_index()
    recent_lookup = most_recent.set_index(KEY_COLUMNS)["_recent_enquiry"]
    recent_dates = pd.Series(recent_lookup.reindex(keys).to_numpy(), index=application.index)
    if "G102S" in application:
        application["G102S"] = _months_since(application["application_date"], recent_dates)
    if "G500S" in application:
        application["G500S"] = (application["application_date"] - recent_dates).dt.days.astype("Int64")

    return application


def _iso_dates(frame: pd.DataFrame) -> pd.DataFrame:
    for column in frame.columns:
        if pd.api.types.is_datetime64_any_dtype(frame[column]):
            frame[column] = frame[column].dt.strftime("%Y-%m-%d")
    return frame


def build_validation_report(
    application: pd.DataFrame,
    tradelines: pd.DataFrame,
    enquiries: pd.DataFrame,
) -> dict[str, object]:
    app_keys = pd.MultiIndex.from_frame(application[KEY_COLUMNS])
    trd_keys = pd.MultiIndex.from_frame(tradelines[KEY_COLUMNS])
    inq_keys = pd.MultiIndex.from_frame(enquiries[KEY_COLUMNS])
    raw_counts = tradelines.groupby(KEY_COLUMNS, observed=True).size()
    app_count_lookup = application.set_index(KEY_COLUMNS)["TRD"]

    report: dict[str, object] = {
        "application_shape": list(application.shape),
        "tradeline_shape": list(tradelines.shape),
        "enquiry_shape": list(enquiries.shape),
        "bad_count": int(application["bad_flag"].sum()),
        "good_count": int(application["bad_flag"].eq(0).sum()),
        "bad_rate": float(application["bad_flag"].mean()),
        "duplicate_application_keys": int(app_keys.duplicated().sum()),
        "duplicate_account_numbers": int(tradelines["acct_num"].duplicated().sum()),
        "duplicate_enquiry_ids": int(enquiries["ecn"].duplicated().sum()),
        "orphan_tradeline_rows": int((~trd_keys.isin(app_keys)).sum()),
        "orphan_enquiry_rows": int((~inq_keys.isin(app_keys)).sum()),
        "invalid_product_flags": int((~tradelines["PRODUCT_FLAG"].isin(["SECURED", "UNSECURED"])).sum()),
        "closed_high_credit_le_one": int((tradelines["LIVE_CLOSED"].eq(0) & tradelines["high_credit"].le(1)).sum()),
        "max_history_mismatches": int((tradelines["Max hist"] != tradelines[DPD_COLUMNS].max(axis=1)).sum()),
        "tradeline_count_mismatches": int((app_count_lookup.reindex(raw_counts.index) != raw_counts).sum()),
        "future_enquiries": int((enquiries["enq_date"] > enquiries["input_date"]).sum()),
        "future_open_dates": int((tradelines["opened_dt"] > tradelines["input_date"]).sum()),
        "application_feature_columns": int(application.shape[1] - 4),
    }
    report["passed"] = all(
        report[field] == 0
        for field in [
            "duplicate_application_keys",
            "duplicate_account_numbers",
            "duplicate_enquiry_ids",
            "orphan_tradeline_rows",
            "orphan_enquiry_rows",
            "invalid_product_flags",
            "closed_high_credit_le_one",
            "max_history_mismatches",
            "tradeline_count_mismatches",
            "future_enquiries",
            "future_open_dates",
        ]
    )
    return report


def run_pipeline(input_dir: Path, output_dir: Path) -> dict[str, object]:
    application_path = input_dir / "application_level.csv"
    tradeline_path = input_dir / "tradeline_level.csv"
    enquiry_path = input_dir / "enquiry_level.csv"
    for path in (application_path, tradeline_path, enquiry_path):
        if not path.exists():
            raise FileNotFoundError(path)

    output_dir.mkdir(parents=True, exist_ok=True)
    tradelines = repair_tradelines(pd.read_csv(tradeline_path, low_memory=False))
    enquiries = repair_enquiries(pd.read_csv(enquiry_path, low_memory=False))
    application = repair_application(
        pd.read_csv(application_path, low_memory=False),
        tradelines,
        enquiries,
    )

    report = build_validation_report(application, tradelines, enquiries)
    _iso_dates(application.copy()).to_csv(output_dir / "application_level_development.csv", index=False)
    _iso_dates(tradelines.copy()).to_csv(output_dir / "tradeline_level_development.csv", index=False)
    _iso_dates(enquiries.copy()).to_csv(output_dir / "enquiry_level_development.csv", index=False)
    (output_dir / "validation_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=Path.cwd())
    parser.add_argument("--output-dir", type=Path, default=Path.cwd() / "development_data")
    args = parser.parse_args()
    report = run_pipeline(args.input_dir.resolve(), args.output_dir.resolve())
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
