import contextlib
import io
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

import Scorecard_Package as scorecard
from Scorecard_Package import Binning_Rules as binning_rules
from Scorecard_Package import CSI
from Scorecard_Package import Coarse_Classing as coarse
from Scorecard_Package import Fine_Classing as fine
from Scorecard_Package import Modelling as modelling
from Scorecard_Package import Validation as validation


class ScorecardAutomationTests(unittest.TestCase):
    @staticmethod
    def development_data(rows=500, seed=42):
        rng = np.random.default_rng(seed)
        income = rng.normal(50_000, 12_000, rows)
        utilization = rng.uniform(0, 1, rows)
        delinquency = rng.choice([0, 1, 2, 3], rows, p=[0.55, 0.25, 0.15, 0.05])
        segment = rng.choice(["A", "B", "C", None], rows, p=[0.35, 0.3, 0.25, 0.1])
        logit = (
            -0.00004 * (income - 50_000)
            + 2.2 * utilization
            + 0.45 * (delinquency >= 2)
            + 0.35 * (segment == "C")
            - 1.1
        )
        target = (rng.random(rows) < 1 / (1 + np.exp(-logit))).astype(int)
        data = pd.DataFrame({
            "ID": np.arange(rows),
            "income": income,
            "utilization": utilization,
            "delinquency": delinquency,
            "segment": segment,
            "Default": target,
        })
        data.loc[:14, "income"] = np.nan
        return data

    def test_package_imports(self):
        self.assertEqual(scorecard.__version__, "1.0.0")
        self.assertTrue(callable(scorecard.fine_classing))
        self.assertTrue(callable(scorecard.deploy_model))

    def test_missing_and_unseen_values_have_complete_woe(self):
        data = self.development_data()
        variables = ["income", "utilization", "delinquency", "segment"]
        _, _, fine_rules = fine.fine_classing(
            data, variables, "Default", save_output=False
        )
        scored, _, _, coarse_rules = coarse.coarse_classing(
            data, variables, fine_rules, {}, target="Default", save_output=False
        )

        self.assertFalse(scored.filter(like="_COARSE_WOE").isna().any().any())

        deployment = pd.DataFrame({
            "income": [np.nan, -1_000_000, 1_000_000],
            "utilization": [np.nan, -2.0, 3.0],
            "delinquency": [np.nan, 99, 1],
            "segment": [None, "NEVER_SEEN", "A"],
        })
        deployed = coarse.apply_coarse_binning(
            deployment, coarse_rules, return_woe=True
        )

        self.assertFalse(deployed.filter(like="_COARSE_WOE").isna().any().any())
        self.assertEqual(deployed.loc[0, "segment_COARSE_BIN"], "_MISSING_")
        self.assertEqual(deployed.loc[1, "segment_COARSE_BIN"], "_OTHER_")
        self.assertEqual(deployed.loc[1, "delinquency_COARSE_BIN"], "_OTHER_")

    def test_csi_includes_bins_absent_from_test(self):
        train = {
            "x": pd.DataFrame({"BIN": ["A", "B"], "POPULATION_PCT": [0.5, 0.5]})
        }
        test = {
            "x": pd.DataFrame({"BIN": ["A"], "POPULATION_PCT": [1.0]})
        }
        summary, details = CSI.build_csi_bivariates(
            train, test, save_output=False
        )

        eps = 1e-10
        expected = (
            (1.0 - 0.5) * np.log((1.0 + eps) / (0.5 + eps))
            + (0.0 - 0.5) * np.log((0.0 + eps) / (0.5 + eps))
        )
        self.assertAlmostEqual(summary.loc[0, "CSI"], expected, places=6)
        self.assertEqual(set(details["x"]["COMPARISON"]["BIN"]), {"A", "B"})

    def test_empty_correlation_result_is_valid(self):
        data = pd.DataFrame({
            "first_WOE": [0.0, 1.0, 2.0, 3.0],
            "second_WOE": [0.0, 1.0, 0.0, 1.0],
        })
        _, high = modelling.correlation_analysis(data, threshold=1.1)
        self.assertTrue(high.empty)
        self.assertEqual(
            list(high.columns), ["VARIABLE_1", "VARIABLE_2", "CORRELATION"]
        )

    def test_long_excel_names_round_trip(self):
        data = self.development_data(rows=250)
        first = "a_very_long_scorecard_variable_name_shared_prefix_one"
        second = "a_very_long_scorecard_variable_name_shared_prefix_two"
        data[first] = data["income"]
        data[second] = data["utilization"]

        output = Path(__file__).parent / "_test_fine.xlsx"
        rule_file = Path(__file__).parent / "_test_rules.xlsx"
        try:
            fine.fine_classing(
                data,
                [first, second],
                "Default",
                save_output=True,
                output_file_path=output,
                rules_output_path=rule_file,
            )
            loaded = binning_rules.load_fine_rules(rule_file)
        finally:
            output.unlink(missing_ok=True)
            rule_file.unlink(missing_ok=True)

        self.assertEqual(set(loaded), {first, second})

    def test_end_to_end_training_artifact_loading_and_deployment(self):
        data = self.development_data(rows=650, seed=7)
        variables = ["income", "utilization", "delinquency", "segment"]
        _, _, fine_rules = fine.fine_classing(
            data, variables, "Default", save_output=False
        )
        coarse_data, coarse_summary, _, coarse_rules = coarse.coarse_classing(
            data, variables, fine_rules, {}, target="Default", save_output=False
        )
        model_data = modelling.prepare_model_dataset(coarse_data, "ID", "Default")
        train = model_data.iloc[:500].copy()
        test = model_data.iloc[500:].copy()
        iv_map = dict(zip(coarse_summary["VARIABLE"], coarse_summary["IV"]))

        with contextlib.redirect_stdout(io.StringIO()):
            results = modelling.scorecard_model_pipeline(
                train,
                test,
                coarse_rules=coarse_rules,
                iv_map=iv_map,
                target="Default",
                key_col="ID",
                save_output=False,
            )

        self.assertTrue(np.isneginf(results["bin_edges"][0]))
        self.assertTrue(np.isposinf(results["bin_edges"][-1]))
        self.assertFalse(results["test_data"]["PD_BAND"].isna().any())

        mapping = dict(zip(
            results["train_data"]["PD_BAND"],
            results["train_data"]["SCORE_BAND"],
        ))
        score_band_table = (
            results["train_data"]
            .groupby("PD_BAND", observed=False)["SCORE"]
            .agg(["min", "max"])
            .reset_index()
        )
        coefficient_map = dict(zip(
            results["coefficients"]["VARIABLE"],
            results["coefficients"]["COEF"],
        ))

        artifact_dir = Path(__file__).parent
        model_path = artifact_dir / "_test_model.pkl"
        metadata_path = artifact_dir / "_test_metadata.pkl"
        coarse_path = artifact_dir / "_test_coarse.xlsx"
        try:
            modelling.save_model(results["model"], model_path)
            modelling.save_model_metadata(
                variables=results["final_variables"],
                bin_edges=results["bin_edges"],
                development_distribution=results["train_band_report"]["POPULATION_%"].tolist(),
                score_band_mapping=mapping,
                score_band_table=score_band_table,
                min_score=300,
                max_score=900,
                base_score=600,
                base_odds=50,
                pdo=20,
                coefficients=coefficient_map,
                file_path=metadata_path,
            )
            coarse.save_coarse_rules(coarse_rules, coarse_path)

            deployment = pd.DataFrame({
                "ID": [1001, 1002],
                "income": [np.nan, 250_000],
                "utilization": [0.2, 1.5],
                "delinquency": [99, 0],
                "segment": ["NEW", None],
            })
            deployed = validation.deploy_model(
                deployment,
                coarse_rules_path=coarse_path,
                model_path=model_path,
                metadata_path=metadata_path,
                target_available=False,
                key_col="ID",
                save_output=False,
            )
        finally:
            model_path.unlink(missing_ok=True)
            metadata_path.unlink(missing_ok=True)
            coarse_path.unlink(missing_ok=True)

        self.assertEqual(len(deployed["data"]), 2)
        self.assertFalse(deployed["data"][["PD", "SCORE", "PD_BAND"]].isna().any().any())


if __name__ == "__main__":
    unittest.main()
