import unittest

import pandas as pd

from prepare_development_data import (
    DPD_COLUMNS,
    derive_product_flag,
    normalize_live_closed,
    repair_closed_high_credit,
    repair_payment_history,
)


class PreparationTests(unittest.TestCase):
    def test_normalize_live_closed_accepts_string_and_numeric_encodings(self):
        values = pd.Series(["LIVE", "OPEN", 1, "1", "CLOSED", 0, "0"])
        self.assertEqual(normalize_live_closed(values).tolist(), [1, 1, 1, 1, 0, 0, 0])

    def test_product_flag_uses_collateral_and_unsecured_product_fallbacks(self):
        frame = pd.DataFrame(
            {
                "collataral_type": ["PROPERTY", "UNSECURED", "VEHICLE"],
                "acct_type": ["MORTGAGE", "BUSINESS_LOAN", "PERSONAL_LOAN"],
            }
        )
        self.assertEqual(
            derive_product_flag(frame).tolist(),
            ["SECURED", "UNSECURED", "UNSECURED"],
        )

    def test_closed_high_credit_imputation_is_positive_and_deterministic(self):
        source = pd.DataFrame(
            {
                "LIVE_CLOSED": [1, 0, 0],
                "acct_type": ["PERSONAL_LOAN"] * 3,
                "acct_num": ["LIVE-1", "CLOSED-1", "CLOSED-2"],
                "high_credit": [200_000, 1, 1],
            }
        )
        first = repair_closed_high_credit(source.copy())
        second = repair_closed_high_credit(source.copy())
        self.assertTrue((first.loc[1:, "high_credit"] >= 1_000).all())
        self.assertEqual(first["high_credit"].tolist(), second["high_credit"].tolist())

    def test_payment_history_rebuilds_recency_and_dates(self):
        row = {
            "input_date": pd.Timestamp("2025-06-15"),
            "report_dt": pd.Timestamp("2025-06-10"),
            "opened_dt": pd.Timestamp("2023-01-20"),
        }
        row.update({column: 0 for column in DPD_COLUMNS})
        row["p_hist_03"] = 30
        row["p_hist_08"] = 60
        frame = repair_payment_history(pd.DataFrame([row]))

        self.assertEqual(frame.loc[0, "pmt_start_dt"], pd.Timestamp("2025-06-01"))
        self.assertEqual(frame.loc[0, "Month Since30+"], 2)
        self.assertEqual(frame.loc[0, "Month Since60+"], 7)
        self.assertEqual(frame.loc[0, "First Month Since30+"], pd.Timestamp("2024-11-01"))
        self.assertEqual(frame.loc[0, "Max hist"], 60)


if __name__ == "__main__":
    unittest.main()
