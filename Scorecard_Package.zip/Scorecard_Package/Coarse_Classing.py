def _legacy_build_coarse_rules(
        selected_variables,
        rules_dict,
        merge_dict=None
):

    import pandas as pd
    import numpy as np

    merge_dict = merge_dict or {}

    coarse_rules = {}

    for var in selected_variables:

        fine_rules = rules_dict[var]["RULES"].copy()

        var_type = rules_dict[var]["TYPE"]

        max_bin = int(
            fine_rules["BIN_ORDER"].max()
        )

        # ---------------------------------
        # Build groups
        # ---------------------------------

        merges = merge_dict.get(var, [])

        used = set()

        groups = []

        for grp in merges:

            grp = tuple(sorted(grp))

            groups.append(grp)

            used.update(grp)

        for i in range(1, max_bin + 1):

            if i not in used:

                groups.append((i,))

        groups = sorted(groups, key=min)

        # ---------------------------------
        # CATEGORICAL
        # ---------------------------------

        if var_type == "CATEGORICAL":

            rows = []

            for new_order, grp in enumerate(groups, 1):

                tmp = fine_rules[
                    fine_rules["BIN_ORDER"]
                    .isin(grp)
                ]

                cats = (
                    tmp["CATEGORY"]
                    .astype(str)
                    .tolist()
                )

                bin_name = (
                    f"{excel_col(new_order-1)}. "
                    + ", ".join(cats)
                )

                for cat in cats:

                    rows.append({

                        "BIN_ORDER":
                            new_order,

                        "BIN":
                            bin_name,

                        "CATEGORY":
                            cat
                    })

            coarse_rules[var] = {

                "TYPE":
                    "CATEGORICAL",

                "RULES":
                    pd.DataFrame(rows)
            }

        # ---------------------------------
        # CONTINUOUS
        # ---------------------------------

        elif var_type == "CONTINUOUS":

            rows = []

            for new_order, grp in enumerate(groups, 1):

                tmp = fine_rules[
                    fine_rules["BIN_ORDER"]
                    .isin(grp)
                ]

                frm = tmp["CUT_FROM"].min()
                to  = tmp["CUT_TO"].max()
                
                if new_order == 1:
                    frm = -np.inf
                
                if new_order == len(groups):
                    to = np.inf

                rows.append({

                    "BIN_ORDER":
                        new_order,

                    "FROM":
                        frm,

                    "TO":
                        to
                })

            coarse_df = pd.DataFrame(rows)
            
            labels = []

            for i in range(len(coarse_df)):

                frm = coarse_df.iloc[i]["FROM"]

                to = coarse_df.iloc[i]["TO"]

                if i == 0:

                    label = (
                        f"{excel_col(i)}. <= {to}"
                    )

                elif i == len(coarse_df)-1:

                    prev_to = coarse_df.iloc[i-1]["TO"]
                
                    label = (
                        f"{excel_col(i)}. > {prev_to}"
                    )

                else:

                    prev_to = coarse_df.iloc[i-1]["TO"]
                
                    label = (
                        f"{excel_col(i)}. "
                        f"> {prev_to} - <= {to}"
                    )

                labels.append(label)

            coarse_df["BIN"] = labels

            coarse_rules[var] = {

                "TYPE":
                    "NUMERIC",

                "RULES":
                    coarse_df[
                        [
                            "BIN_ORDER",
                            "BIN",
                            "FROM",
                            "TO"
                        ]
                    ]
            }

        # ---------------------------------
        # LOW_CARD_NUMERIC
        # ---------------------------------

        else:

            rows = []
        
            for new_order, grp in enumerate(groups, 1):
        
                tmp = fine_rules[
                    fine_rules["BIN_ORDER"]
                    .isin(grp)
                ]
        
                vals = sorted(
                    tmp["VALUE"].tolist()
                )
        
                frm = min(vals)
                to = max(vals)
        
                if new_order == 1:
                    frm = -np.inf
        
                if new_order == len(groups):
                    to = np.inf
        
                rows.append({
        
                    "BIN_ORDER": new_order,
                    "FROM": frm,
                    "TO": to
        
                })
        
            coarse_df = pd.DataFrame(rows)

            # Fix boundaries for LOW_CARD_NUMERIC

            for i in range(1, len(coarse_df)):
                coarse_df.loc[i, "FROM"] = coarse_df.loc[i-1, "TO"]
        
            labels = []
        
            for i in range(len(coarse_df)):
        
                frm = coarse_df.iloc[i]["FROM"]
                to = coarse_df.iloc[i]["TO"]
        
                if i == 0:
        
                    label = f"{excel_col(i)}. <= {to}"
        
                elif i == len(coarse_df)-1:
        
                    label = f"{excel_col(i)}. > {frm}"
        
                else:
        
                    label = (
                        f"{excel_col(i)}. "
                        f"> {frm} - <= {to}"
                    )
        
                labels.append(label)
        
            coarse_df["BIN"] = labels
        
            coarse_rules[var] = {
        
                "TYPE": "NUMERIC",
        
                "RULES":
                    coarse_df[
                        [
                            "BIN_ORDER",
                            "BIN",
                            "FROM",
                            "TO"
                        ]
                    ]
            }

    return coarse_rules

def excel_col(n):

    result = ""

    while n >= 0:

        result = (
            chr(n % 26 + 65)
            + result
        )

        n = n // 26 - 1

    return result


MISSING_BIN = "_MISSING_"
OTHER_BIN = "_OTHER_"


def _build_sheet_name_map(variables, reserved=()):
    import re

    used = {str(name).casefold() for name in reserved}
    result = {}

    for variable in variables:
        base = re.sub(r"[\[\]:*?/\\]", "_", str(variable)).strip("'") or "VARIABLE"
        candidate = base[:31]
        suffix = 1

        while candidate.casefold() in used:
            marker = f"_{suffix}"
            candidate = base[:31 - len(marker)] + marker
            suffix += 1

        used.add(candidate.casefold())
        result[variable] = candidate

    return result


def build_coarse_rules(selected_variables, rules_dict, merge_dict=None):
    """Build validated coarse rules with explicit deployment fallback bins."""
    merge_dict = merge_dict or {}
    coarse_rules = {}

    for var in selected_variables:
        if var not in rules_dict:
            raise KeyError(f"No fine-classing rules found for {var!r}")

        fine_rules = rules_dict[var]["RULES"].copy()
        var_type = rules_dict[var]["TYPE"]

        if "BIN_ORDER" not in fine_rules or "BIN" not in fine_rules:
            raise ValueError(f"Fine-classing rules for {var!r} are incomplete")

        regular = fine_rules[~fine_rules["BIN"].isin([MISSING_BIN, OTHER_BIN])].copy()
        valid_orders = set(regular["BIN_ORDER"].dropna().astype(int))
        used = set()
        groups = []

        for raw_group in merge_dict.get(var, []):
            group = tuple(sorted({int(value) for value in raw_group}))
            if not group:
                raise ValueError(f"Empty merge group supplied for {var!r}")
            invalid = set(group) - valid_orders
            if invalid:
                raise ValueError(f"Invalid bin orders for {var!r}: {sorted(invalid)}")
            overlap = used.intersection(group)
            if overlap:
                raise ValueError(f"Overlapping merge groups for {var!r}: {sorted(overlap)}")
            if var_type == "CONTINUOUS" and group != tuple(range(min(group), max(group) + 1)):
                raise ValueError(f"Continuous merges for {var!r} must use adjacent bins")
            groups.append(group)
            used.update(group)

        groups.extend((order,) for order in sorted(valid_orders - used))
        groups = sorted(groups, key=min)
        rows = []

        if var_type == "CATEGORICAL":
            for new_order, group in enumerate(groups, 1):
                cats = regular.loc[regular["BIN_ORDER"].isin(group), "CATEGORY"].astype(str).tolist()
                bin_name = f"{excel_col(new_order - 1)}. " + ", ".join(cats)
                rows.extend(
                    {"BIN_ORDER": new_order, "BIN": bin_name, "CATEGORY": cat}
                    for cat in cats
                )

            next_order = len(groups) + 1
            rows.extend([
                {"BIN_ORDER": next_order, "BIN": MISSING_BIN, "CATEGORY": MISSING_BIN},
                {"BIN_ORDER": next_order + 1, "BIN": OTHER_BIN, "CATEGORY": OTHER_BIN},
            ])
            coarse_rules[var] = {"TYPE": "CATEGORICAL", "RULES": pd.DataFrame(rows)}

        elif var_type == "CONTINUOUS":
            for new_order, group in enumerate(groups, 1):
                subset = regular[regular["BIN_ORDER"].isin(group)]
                frm = subset["CUT_FROM"].min()
                to = subset["CUT_TO"].max()
                if new_order == 1:
                    frm = -np.inf
                if new_order == len(groups):
                    to = np.inf

                if new_order == 1:
                    label = f"{excel_col(new_order - 1)}. <= {to}"
                elif new_order == len(groups):
                    label = f"{excel_col(new_order - 1)}. > {frm}"
                else:
                    label = f"{excel_col(new_order - 1)}. > {frm} - <= {to}"
                rows.append({"BIN_ORDER": new_order, "BIN": label, "FROM": frm, "TO": to})

            next_order = len(groups) + 1
            rows.extend([
                {"BIN_ORDER": next_order, "BIN": MISSING_BIN, "FROM": np.nan, "TO": np.nan},
                {"BIN_ORDER": next_order + 1, "BIN": OTHER_BIN, "FROM": np.nan, "TO": np.nan},
            ])
            coarse_rules[var] = {"TYPE": "NUMERIC", "RULES": pd.DataFrame(rows)}

        elif var_type == "LOW_CARD_NUMERIC":
            for new_order, group in enumerate(groups, 1):
                values = regular.loc[regular["BIN_ORDER"].isin(group), "VALUE"].tolist()
                bin_name = f"{excel_col(new_order - 1)}. " + ", ".join(map(str, values))
                rows.extend(
                    {"BIN_ORDER": new_order, "BIN": bin_name, "VALUE": value}
                    for value in values
                )

            next_order = len(groups) + 1
            rows.extend([
                {"BIN_ORDER": next_order, "BIN": MISSING_BIN, "VALUE": np.nan},
                {"BIN_ORDER": next_order + 1, "BIN": OTHER_BIN, "VALUE": np.nan},
            ])
            coarse_rules[var] = {"TYPE": "DISCRETE_NUMERIC", "RULES": pd.DataFrame(rows)}

        else:
            raise ValueError(f"Unsupported fine-classing type for {var!r}: {var_type!r}")

    return coarse_rules


def apply_coarse_binning(df, coarse_rules, return_woe=False):

    out = df.copy()

    for var, rule_info in coarse_rules.items():

        if var not in out.columns:
            continue

        rules = rule_info["RULES"]

        special_rules = rules[rules["BIN"].isin([MISSING_BIN, OTHER_BIN])]
        special_order = dict(zip(special_rules["BIN"], special_rules["BIN_ORDER"]))
        special_woe = (
            dict(zip(special_rules["BIN"], special_rules["WOE"]))
            if "WOE" in special_rules.columns
            else {}
        )

        missing_mask = out[var].isna()
        out[var + "_COARSE_BIN"] = np.where(missing_mask, MISSING_BIN, OTHER_BIN)
        out[var + "_COARSE_ORDER"] = pd.Series(
            np.where(
                missing_mask,
                special_order.get(MISSING_BIN, pd.NA),
                special_order.get(OTHER_BIN, pd.NA)
            ),
            index=out.index,
            dtype="Int64"
        )
        
        if return_woe:
            out[var + "_COARSE_WOE"] = np.where(
                missing_mask,
                special_woe.get(MISSING_BIN, 0.0),
                special_woe.get(OTHER_BIN, 0.0)
            )

        # ----------------------------
        # NUMERIC
        # ----------------------------

        if rule_info["TYPE"] == "NUMERIC":

            for _, r in rules.iterrows():

                if r["BIN"] in {MISSING_BIN, OTHER_BIN} or pd.isna(r["FROM"]) or pd.isna(r["TO"]):
                    continue

                mask = out[var].between(r["FROM"],r["TO"],inclusive="right")

                out.loc[mask,var + "_COARSE_BIN"] = r["BIN"]
                
                out.loc[mask,var + "_COARSE_ORDER"] = r["BIN_ORDER"]

                if return_woe and "WOE" in rules.columns:

                    out.loc[mask,var + "_COARSE_WOE"] = r["WOE"]

        # ----------------------------
        # DISCRETE NUMERIC
        # ----------------------------

        elif rule_info["TYPE"] == "DISCRETE_NUMERIC":

            regular = rules[~rules["BIN"].isin([MISSING_BIN, OTHER_BIN])]
            bin_map = dict(zip(regular["VALUE"], regular["BIN"]))
            order_map = dict(zip(regular["VALUE"], regular["BIN_ORDER"]))
            mapped_bin = out[var].map(bin_map)
            known = mapped_bin.notna()

            out.loc[known, var + "_COARSE_BIN"] = mapped_bin[known]
            out.loc[known, var + "_COARSE_ORDER"] = out.loc[known, var].map(order_map)

            if return_woe and "WOE" in rules.columns:
                woe_map = dict(zip(regular["VALUE"], regular["WOE"]))
                out.loc[known, var + "_COARSE_WOE"] = out.loc[known, var].map(woe_map)

        # ----------------------------
        # CATEGORICAL
        # ----------------------------

        elif rule_info["TYPE"] == "CATEGORICAL":

            bin_map = dict(zip(rules["CATEGORY"].astype(str),rules["BIN"]))
            
            order_map = dict(zip(rules["CATEGORY"].astype(str),rules["BIN_ORDER"]))

            if return_woe and "WOE" in rules.columns:

                woe_map = dict(zip(rules["CATEGORY"].astype(str),rules["WOE"]))
            
            normalized = out[var].where(out[var].notna(), MISSING_BIN).astype(str)
            out[var + "_COARSE_BIN"] = normalized.map(bin_map).fillna(bin_map.get(OTHER_BIN, OTHER_BIN))
            mapped_order = normalized.map(order_map)
            if OTHER_BIN in order_map:
                mapped_order = mapped_order.fillna(order_map[OTHER_BIN])
            out[var + "_COARSE_ORDER"] = mapped_order.astype("Int64")

            if return_woe and "WOE" in rules.columns:

                out[var + "_COARSE_WOE"] = (
                    normalized.map(woe_map).fillna(woe_map.get(OTHER_BIN, 0.0))
                )

        else:
            raise ValueError(f"Unsupported coarse rule type for {var!r}: {rule_info['TYPE']!r}")

    woe_cols=[c for c in out.columns if c.endswith("_COARSE_WOE")]

    if len(woe_cols)>0:
        out[woe_cols]=out[woe_cols].apply(pd.to_numeric,errors="coerce").astype(float)
        out[woe_cols]=out[woe_cols].round(10)

    return out


### Bivariates

import pandas as pd
import numpy as np


def build_coarse_bivariates(
        df_coarse,
        coarse_rules,
        selected_variables,
        target="Default"
):


    coarse_bivariates = {}
    coarse_summary = []
    total_event = df_coarse[target].sum()
    total_non_event = (
        len(df_coarse)
        - total_event
    )

    if total_event <= 0 or total_non_event <= 0:
        raise ValueError("Target must contain both event (1) and non-event (0) rows")

    for var in selected_variables:

        bin_col = var + "_COARSE_BIN"

        order_col = var + "_COARSE_ORDER"

        if bin_col not in df_coarse.columns:
            continue

        temp = (df_coarse.groupby([order_col, bin_col],dropna=False).agg(TOTAL=(target, "size"),EVENT=(target, "sum")).reset_index())
        temp["NON_EVENT"] = (temp["TOTAL"]- temp["EVENT"])
        temp["POPULATION_PCT"] = (temp["TOTAL"]/ temp["TOTAL"].sum())
        temp["EVENT_RATE"] = (temp["EVENT"] / temp["TOTAL"])

        # Standard distributions
        temp["DIST_EVENT"] = (temp["EVENT"]/ total_event)        
        temp["DIST_NON_EVENT"] = (temp["NON_EVENT"]/ total_non_event)
        
        # Apply smoothing ONLY when required       
        temp.loc[temp["EVENT"] == 0,"DIST_EVENT"] = (0.5 / total_event)        
        temp.loc[temp["NON_EVENT"] == 0,"DIST_NON_EVENT"] = (0.5 / total_non_event)
        temp["WOE"] = np.log(temp["DIST_NON_EVENT"]/ temp["DIST_EVENT"])
        temp["IV"] = (temp["DIST_NON_EVENT"]- temp["DIST_EVENT"]) * temp["WOE"]

        # ---------------------
        # KS
        # ---------------------

        temp = temp.sort_values(order_col)
        temp["CUM_EVENT"] = (temp["DIST_EVENT"].cumsum())
        temp["CUM_NON_EVENT"] = (temp["DIST_NON_EVENT"].cumsum())
        temp["KS"] = (abs(temp["CUM_EVENT"]- temp["CUM_NON_EVENT"]))
        max_ks = temp["KS"].max()

        # ---------------------
        # Monotonicity
        # ---------------------

        woe_vals = temp["WOE"].values
        diff = np.diff(woe_vals)
        if len(diff) == 0:
            monotonicity = ("INCREASING")
        elif np.all(diff >= 0):
            monotonicity = ("INCREASING")
        elif np.all(diff <= 0):
            monotonicity = ("DECREASING")
        else:
            monotonicity = ("NON_MONOTONIC")

        iv = temp["IV"].sum()

        missing_pct = ((df_coarse[var].isna().sum())/len(df_coarse))
        
        coarse_summary.append({        
            "VARIABLE": var,        
            "IV":round(iv, 6),        
            "KS":round(max_ks, 6),        
            "MONOTONICITY":monotonicity,        
            "NO_BINS":temp.shape[0],        
            "MISSING_PCT":round(missing_pct * 100,2)
        })

        temp = temp.rename(columns={order_col:"BIN_ORDER",bin_col:"BIN"})

        # Update rules with WOE

        if var in coarse_rules:

            rules = coarse_rules[var]["RULES"].copy()
        
            temp["BIN"] = temp["BIN"].astype(str)
        
            woe_map = dict(
                zip(
                    temp["BIN"],
                    temp["WOE"]
                )
            )
        
            rules["WOE"] = (
                rules["BIN"]
                .astype(str)
                .map(woe_map).round(10)
            )
            special = rules["BIN"].isin([MISSING_BIN, OTHER_BIN])
            rules.loc[special, "WOE"] = rules.loc[special, "WOE"].fillna(0.0)
        
            coarse_rules[var]["RULES"] = rules
        coarse_bivariates[var] = temp

    coarse_summary = pd.DataFrame(coarse_summary)
    if not coarse_summary.empty:
        coarse_summary = coarse_summary.sort_values("IV",ascending=False).reset_index(drop=True)

    return (
        coarse_summary,
        coarse_bivariates,
        coarse_rules
    )

### save_course_classing funtion

def save_coarse_classing(
        coarse_summary,
        coarse_bivariates,
        output_file
):

    sheet_names = _build_sheet_name_map(
        coarse_summary["VARIABLE"].tolist(),
        reserved={"SUMMARY"}
    )

    with pd.ExcelWriter(
        output_file,
        engine="openpyxl"
    ) as writer:

        coarse_summary.to_excel(
            writer,
            sheet_name="SUMMARY",
            index=False
        )

        for var in coarse_summary["VARIABLE"]:

            coarse_bivariates[var].to_excel(
                writer,
                sheet_name=sheet_names[var],
                index=False
            )

### save_coarse_rules Function

def save_coarse_rules(
        coarse_rules,
        output_file
):

    variable_types = []
    sheet_names = _build_sheet_name_map(
        coarse_rules.keys(),
        reserved={"_VARIABLE_TYPES_"}
    )

    for var, info in coarse_rules.items():

        variable_types.append({

            "VARIABLE":
                var,

            "TYPE":
                info["TYPE"],

            "SHEET_NAME":
                sheet_names[var]

        })

    variable_types = pd.DataFrame(
        variable_types
    )

    with pd.ExcelWriter(
        output_file,
        engine="openpyxl"
    ) as writer:

        variable_types.to_excel(
            writer,
            sheet_name="_VARIABLE_TYPES_",
            index=False
        )

        for var, info in coarse_rules.items():

            info["RULES"].to_excel(
                writer,
                sheet_name=sheet_names[var],
                index=False
            )


##########################################

import os


def coarse_classing(
        df,
        selected_variables,
        rules_dict,
        merge_dict,
        target="Default",
        save_output=False,
        output_folder="V3_Output"
):

    coarse_rules = build_coarse_rules(
        selected_variables=selected_variables,
        rules_dict=rules_dict,
        merge_dict=merge_dict
    )

    df_temp = apply_coarse_binning(
        df=df,
        coarse_rules=coarse_rules
    )

    coarse_summary,\
    coarse_bivariates,\
    coarse_rules = build_coarse_bivariates(
        df_coarse=df_temp,
        coarse_rules=coarse_rules,
        selected_variables=selected_variables,
        target=target
    )

    df_coarse = apply_coarse_binning(
        df=df,
        coarse_rules=coarse_rules,
        return_woe=True
    )

    if save_output:

        os.makedirs(
            output_folder,
            exist_ok=True
        )

        save_coarse_classing(
            coarse_summary=coarse_summary,
            coarse_bivariates=coarse_bivariates,
            output_file=os.path.join(
                output_folder,
                "CoarseClassing.xlsx"
            )
        )

        save_coarse_rules(
            coarse_rules=coarse_rules,
            output_file=os.path.join(
                output_folder,
                "CoarseRules.xlsx"
            )
        )

    return (
        df_coarse,
        coarse_summary,
        coarse_bivariates,
        coarse_rules
    )
