# --------------------------------------------------
# Load Fine Rules
# --------------------------------------------------
import pandas as pd

def load_fine_rules(file_path):

    xls = pd.ExcelFile(file_path)
    try:
        meta = pd.read_excel(xls, "_VARIABLE_TYPES_")
        rules_dict = {}

        for _, r in meta.iterrows():
            var = r["VARIABLE"]
            sheet_name = r.get("SHEET_NAME", var)
            rules_dict[var] = {
                "TYPE": r["TYPE"],
                "RULES": pd.read_excel(xls, sheet_name)
            }

        return rules_dict
    finally:
        xls.close()

#####################################################################

# --------------------------------------------------
# Load Coarse Rules
# --------------------------------------------------

### Load Coarse Binning + WOE Rules

def load_coarse_rules(
        file_path
):

    xls = pd.ExcelFile(
        file_path
    )

    try:
        types = pd.read_excel(xls, "_VARIABLE_TYPES_")
        coarse_rules = {}

        for _, row in types.iterrows():
            var = row["VARIABLE"]
            var_type = row["TYPE"]
            sheet_name = row.get("SHEET_NAME", var)
            rules = pd.read_excel(xls, sheet_name=sheet_name)
            coarse_rules[var] = {"TYPE": var_type, "RULES": rules}

        return coarse_rules
    finally:
        xls.close()
