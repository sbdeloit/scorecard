import pandas as pd
import numpy as np


def build_csi_bivariates(
        coarse_bivariates,
        test_bivariates,
        output_file="CSI_Report.xlsx",
        save_output=True
):

    eps = 1e-10

    csi_summary = []

    csi_bivariates = {}

    for var in coarse_bivariates:

        train_bv = coarse_bivariates[var].copy()

        test_bv = test_bivariates[var].copy()

        train_pct = (
            train_bv[
                ["BIN", "POPULATION_PCT"]
            ]
            .rename(
                columns={
                    "POPULATION_PCT":
                    "TRAIN_PCT"
                }
            )
        )

        test_pct = (
            test_bv[
                ["BIN", "POPULATION_PCT"]
            ]
            .rename(
                columns={
                    "POPULATION_PCT":
                    "TEST_PCT"
                }
            )
        )

        temp = (
            train_pct
            .merge(
                test_pct,
                on="BIN",
                how="outer"
            )
            .fillna(0)
        )

        temp["CSI"] = (
            (
                temp["TEST_PCT"]
                -
                temp["TRAIN_PCT"]
            )
            *
            np.log(
                (
                    temp["TEST_PCT"]
                    + eps
                )
                /
                (
                    temp["TRAIN_PCT"]
                    + eps
                )
            )
        )

        test_bv = test_bv.merge(
            temp[
                [
                    "BIN",
                    "CSI"
                ]
            ],
            on="BIN",
            how="left"
        )

        total_csi = (
            temp["CSI"]
            .sum()
        )

        csi_summary.append({

            "VARIABLE":
                var,

            "CSI":
                round(
                    total_csi,
                    6
                )

        })

        csi_bivariates[var] = {

            "TRAIN":
                train_bv,

            "TEST":
                test_bv,

            "COMPARISON":
                temp,

            "CSI":
                total_csi

        }

    csi_summary = pd.DataFrame(csi_summary, columns=["VARIABLE", "CSI"])
    if not csi_summary.empty:
        csi_summary = csi_summary.sort_values("CSI", ascending=False).reset_index(drop=True)

    # ------------------------
    # Save Excel
    # ------------------------

    if save_output:
        with pd.ExcelWriter(
            output_file,
            engine="openpyxl"
        ) as writer:

            csi_summary.to_excel(
                writer,
                sheet_name="SUMMARY",
                index=False
            )

            used_sheets = {"summary"}
            for var, data in csi_bivariates.items():

                base = str(var).translate(str.maketrans({c: "_" for c in "[]:*?/\\"})) or "VARIABLE"
                sheet = base[:31]
                suffix = 1
                while sheet.casefold() in used_sheets:
                    marker = f"_{suffix}"
                    sheet = base[:31-len(marker)] + marker
                    suffix += 1
                used_sheets.add(sheet.casefold())

                train_bv = data["TRAIN"]

                test_bv = data["TEST"]

                train_bv.to_excel(
                    writer,
                    sheet_name=sheet,
                    startrow=0,
                    index=False
                )

                test_bv.to_excel(
                    writer,
                    sheet_name=sheet,
                    startrow=len(train_bv) + 4,
                    index=False
                )

                ws = writer.sheets[sheet]

                total_row = len(train_bv) + len(test_bv) + 7

                ws.cell(row=total_row, column=1).value = "TOTAL CSI"

                ws.cell(row=total_row, column=2).value = round(data["CSI"], 6)

        print(f"CSI Report saved to: {output_file}")

    return (
        csi_summary,
        csi_bivariates
    )
