
"""
scorecard_fine_classing.py

Production-oriented scorecard fine classing library.

Includes:
- fine_classing() > Main code for fine binning
- load_rules() > Converts rules generated in excel to dictionary 
- apply_binning() > This code is used to apply the same bins and WOE on a new data
- save_selected_rules() > Save rules only for a selected variables which you will pass
- calculate_variable_ks() > Calculates KS 
- calculate_psi() > 

Features:
- Continuous/LOW_CARD_NUMERIC/Categorical detection
- Missing bin (_MISSING_)
- Other bin (_OTHER_)
- WOE / IV
- KS
- PSI
- Rules workbook with _VARIABLE_TYPES_
- Reusable deployment rules
"""

import pandas as pd
import numpy as np
import re


MISSING_BIN = "_MISSING_"
OTHER_BIN = "_OTHER_"


def _build_sheet_name_map(variables, reserved=()):
    """Return deterministic, valid, case-insensitively unique Excel sheet names."""
    used = {str(name).casefold() for name in reserved}
    result = {}

    for variable in variables:
        base = re.sub(r"[\[\]:*?/\\]", "_", str(variable)).strip("'") or "VARIABLE"
        candidate = base[:31]
        suffix = 1

        while candidate.casefold() in used:
            marker = f"_{suffix}"
            candidate = base[:31 - len(marker)] + marker
            suffix += 1

        used.add(candidate.casefold())
        result[variable] = candidate

    return result


# --------------------------------------------------
# Utility
# --------------------------------------------------

def excel_col(n):
    s = ""
    while n >= 0:
        s = chr(n % 26 + 65) + s
        n = n // 26 - 1
    return s


def variable_type(series, unique_continuous=20):
    if pd.api.types.is_numeric_dtype(series):
        return (
            "LOW_CARD_NUMERIC"
            if series.nunique(dropna=True) <= unique_continuous
            else "CONTINUOUS"
        )
    return "CATEGORICAL"


# --------------------------------------------------
# KS
# --------------------------------------------------

def calculate_variable_ks(bv):
    t1 = bv.copy()
    t1["CUM_EVENT"] = t1["DIST_EVENT"].cumsum()
    t1["CUM_NON_EVENT"] = t1["DIST_NON_EVENT"].cumsum()
    return (abs(t1["CUM_EVENT"] - t1["CUM_NON_EVENT"]).max()) * 100


# --------------------------------------------------
# PSI
# --------------------------------------------------

def calculate_psi(expected, actual, eps=1e-6):
    expected = np.array(expected)
    actual = np.array(actual)

    expected = np.where(expected == 0, eps, expected)
    actual = np.where(actual == 0, eps, actual)

    return np.sum((actual - expected) * np.log(actual / expected))


# --------------------------------------------------
# Fine Classing
# --------------------------------------------------

def fine_classing(
    df,
    variables,
    target,
    key=None,
    continuous_bins=10,
    categorical_bins=20,
    unique_continuous=20,
    save_output=True,
    output_file_path="FineClassing.xlsx",
    rules_output_path="Rules.xlsx"
):

    df = df.copy()

    if target not in df.columns:
        raise KeyError(f"Target column not found: {target!r}")
    if not variables:
        raise ValueError("At least one variable is required")
    missing_variables = [variable for variable in variables if variable not in df.columns]
    if missing_variables:
        raise KeyError(f"Variables not found in data: {missing_variables}")
    target_values = set(df[target].dropna().unique())
    if df[target].isna().any() or not target_values.issubset({0, 1}) or len(target_values) != 2:
        raise ValueError("Target must be non-null, binary (0/1), and contain both classes")

    summary = []
    bivariates = {}
    rules_dict = {}

    total_event = df[target].sum()
    total_non_event = len(df) - total_event

    for var in variables:

        s = df[var]
        vtype = variable_type(s, unique_continuous)

        # ----------------------------
        # Create bins
        # ----------------------------

        if vtype == "CONTINUOUS":

            q = min(continuous_bins, s.nunique(dropna=True))

            bins = pd.qcut(s, q=q, duplicates="drop")

            mapping = {}
            rules = []

            cats = list(bins.cat.categories)

            for i, c in enumerate(cats):

                if i == 0:
                    label = f"{excel_col(i)}. <= {round(c.right,4)}"
                elif i == len(cats)-1:
                    label = f"{excel_col(i)}. > {round(c.left,4)}"
                else:
                    label = f"{excel_col(i)}. > {round(c.left,4)} - <= {round(c.right,4)}"

                mapping[c] = label

                rules.append({
                    "BIN_ORDER": i+1,
                    "BIN": label,
                    "CUT_FROM": c.left,
                    "CUT_TO": c.right
                })

            binned = bins.map(mapping).astype(object)
            rules = pd.DataFrame(rules)

            if not rules.empty:
                rules.loc[rules.index[0], "CUT_FROM"] = -np.inf
                rules.loc[rules.index[-1], "CUT_TO"] = np.inf

        elif vtype == "LOW_CARD_NUMERIC":

            vals = sorted(s.dropna().unique())

            rules = []
            mapping = {}

            for i, v in enumerate(vals):

                label = f"{excel_col(i)}. {v}"

                mapping[v] = label

                rules.append({
                    "BIN_ORDER": i+1,
                    "BIN": label,
                    "VALUE": v
                })

            binned = s.map(mapping)
            rules = pd.DataFrame(rules)

        else:

            freq = s.value_counts(dropna=True)

            keep = freq.head(categorical_bins-1).index

            temp = s.where(s.isin(keep), OTHER_BIN)
            temp = temp.where(s.notna(), MISSING_BIN)

            tmp_df = pd.DataFrame({
                "CAT": temp,
                "TARGET": df[target]
            })
            
            cats = (
                tmp_df
                .groupby("CAT")["TARGET"]
                .mean()
                .sort_values(ascending=False)
                .index
                .astype(str)
                .tolist()
            )

            rules = []
            mapping = {}

            for i, c in enumerate(cats):

                label = c if c in {MISSING_BIN, OTHER_BIN} else f"{excel_col(i)}. {c}"

                mapping[c] = label

                rules.append({
                    "BIN_ORDER": i+1,
                    "BIN": label,
                    "CATEGORY": c
                })

            binned = temp.astype(str).map(mapping)
            rules = pd.DataFrame(rules)

        binned = binned.fillna(MISSING_BIN)

        # Persist explicit deployment fallbacks. Bins that were not observed in
        # development receive neutral WOE after the bivariate merge below.
        next_order = int(rules["BIN_ORDER"].max()) + 1 if not rules.empty else 1

        if MISSING_BIN not in set(rules.get("BIN", pd.Series(dtype=str)).astype(str)):
            missing_rule = {"BIN_ORDER": next_order, "BIN": MISSING_BIN}
            if vtype == "CONTINUOUS":
                missing_rule.update({"CUT_FROM": np.nan, "CUT_TO": np.nan})
            elif vtype == "LOW_CARD_NUMERIC":
                missing_rule["VALUE"] = np.nan
            else:
                missing_rule["CATEGORY"] = MISSING_BIN
            rules = pd.concat([rules, pd.DataFrame([missing_rule])], ignore_index=True)
            next_order += 1

        if vtype in {"LOW_CARD_NUMERIC", "CATEGORICAL"} and OTHER_BIN not in set(
            rules.get("BIN", pd.Series(dtype=str)).astype(str)
        ):
            other_rule = {"BIN_ORDER": next_order, "BIN": OTHER_BIN}
            if vtype == "LOW_CARD_NUMERIC":
                other_rule["VALUE"] = np.nan
            else:
                other_rule["CATEGORY"] = OTHER_BIN
            rules = pd.concat([rules, pd.DataFrame([other_rule])], ignore_index=True)

        # ----------------------------
        # Bivariate
        # ----------------------------

        bv = (
            pd.DataFrame({
                "BIN": binned,
                target: df[target]
            })
            .groupby("BIN", dropna=False)
            .agg(TOTAL=(target, "size"),
                 EVENT=(target, "sum"))
            .reset_index()
        )

        bv["NON_EVENT"] = bv["TOTAL"] - bv["EVENT"]
        bv["POPULATION_PCT"] = bv["TOTAL"] / bv["TOTAL"].sum()
        bv["EVENT_RATE"] = bv["EVENT"] / bv["TOTAL"]

        # Standard distributions

        bv["DIST_EVENT"] = (bv["EVENT"] / total_event)       
        bv["DIST_NON_EVENT"] = (bv["NON_EVENT"] / total_non_event)
        
        # Apply correction only when EVENT = 0        
        bv.loc[bv["EVENT"] == 0, "DIST_EVENT"] = 0.5 / total_event
        
        # Apply correction only when NON_EVENT = 0       
        bv.loc[bv["NON_EVENT"] == 0,"DIST_NON_EVENT"] = (0.5 / total_non_event)

        bv["WOE"] = np.log(bv["DIST_NON_EVENT"] / bv["DIST_EVENT"])
        bv["IV"] = (bv["DIST_NON_EVENT"] - bv["DIST_EVENT"]) * bv["WOE"]

        iv = bv["IV"].sum()
        ks = calculate_variable_ks(bv)

        if not rules.empty:
            rules["VARIABLE"] = var
            rules = rules.merge(bv[["BIN", "WOE"]], on="BIN", how="left")
            special = rules["BIN"].isin([MISSING_BIN, OTHER_BIN])
            rules.loc[special, "WOE"] = rules.loc[special, "WOE"].fillna(0.0)

        rules_dict[var] = {
            "TYPE": vtype,
            "RULES": rules
        }

        summary.append({
            "VARIABLE": var,
            "TYPE": vtype,
            "IV": round(iv, 6),
            "KS": round(ks, 2),
            "MISSING_PCT": round(s.isna().mean() * 100, 2),
            "NO_BINS": bv.shape[0],
            "UNIQUE": s.nunique(dropna=True),
        
            "MIN_VALUE":
                s.min()
                if pd.api.types.is_numeric_dtype(s)
                else np.nan,
        
            "MAX_VALUE":
                s.max()
                if pd.api.types.is_numeric_dtype(s)
                else np.nan
        })

        bivariates[var] = bv

    summary = pd.DataFrame(summary)
    if not summary.empty:
        summary = summary.sort_values("IV", ascending=False)

    if save_output:

        sheet_names = _build_sheet_name_map(
            summary["VARIABLE"].tolist(),
            reserved={"SUMMARY", "_VARIABLE_TYPES_"}
        )

        with pd.ExcelWriter(output_file_path, engine="openpyxl") as writer:

            summary.to_excel(writer, sheet_name="SUMMARY", index=False)

            for v in summary["VARIABLE"]:
                bivariates[v].to_excel(writer, sheet_name=sheet_names[v], index=False)

        with pd.ExcelWriter(rules_output_path, engine="openpyxl") as writer:

            metadata = summary[["VARIABLE", "TYPE"]].copy()
            metadata["SHEET_NAME"] = metadata["VARIABLE"].map(sheet_names)
            metadata.to_excel(
                writer,
                sheet_name="_VARIABLE_TYPES_",
                index=False
            )

            for v in summary["VARIABLE"]:
                rules_dict[v]["RULES"].to_excel(
                    writer,
                    sheet_name=sheet_names[v],
                    index=False
                )

    return summary, bivariates, rules_dict


# --------------------------------------------------
# Load Rules
# --------------------------------------------------

def load_rules(file_path):

    xls = pd.ExcelFile(file_path)
    try:
        meta = pd.read_excel(xls, "_VARIABLE_TYPES_")
        rules_dict = {}

        for _, r in meta.iterrows():
            var = r["VARIABLE"]
            sheet_name = r.get("SHEET_NAME", var)
            rules_dict[var] = {
                "TYPE": r["TYPE"],
                "RULES": pd.read_excel(xls, sheet_name)
            }

        return rules_dict
    finally:
        xls.close()


# --------------------------------------------------
# Apply Binning
# --------------------------------------------------

def apply_binning(df, rules_dict):

    out = df.copy()

    for var, meta in rules_dict.items():

        if var not in out.columns:
            continue

        rules = meta["RULES"]
        vtype = meta["TYPE"]

        out[var + "_BIN"] = "_MISSING_"
        out[var + "_WOE"] = np.nan

        if vtype == "CONTINUOUS":

            for _, r in rules.iterrows():
                if r["BIN"] == MISSING_BIN:
                    m = out[var].isna()
                    out.loc[m, var+"_BIN"] = MISSING_BIN
                    out.loc[m, var+"_WOE"] = r["WOE"]
                    continue

                m = out[var].between(
                    r["CUT_FROM"],
                    r["CUT_TO"],
                    inclusive="right"
                )

                out.loc[m, var+"_BIN"] = r["BIN"]
                out.loc[m, var+"_WOE"] = r["WOE"]

        elif vtype == "LOW_CARD_NUMERIC":
            regular = rules[~rules["BIN"].isin([MISSING_BIN, OTHER_BIN])]
            bin_map = dict(zip(regular["VALUE"], regular["BIN"]))
            woe_map = dict(zip(regular["VALUE"], regular["WOE"]))
            special_woe = dict(zip(rules["BIN"], rules["WOE"]))

            mapped_bin = out[var].map(bin_map)
            out[var+"_BIN"] = mapped_bin.where(
                mapped_bin.notna(),
                np.where(out[var].isna(), MISSING_BIN, OTHER_BIN)
            )
            out[var+"_WOE"] = out[var].map(woe_map)
            out.loc[out[var].isna(), var+"_WOE"] = special_woe.get(MISSING_BIN, 0.0)
            out.loc[out[var].notna() & mapped_bin.isna(), var+"_WOE"] = special_woe.get(OTHER_BIN, 0.0)

        else:
            tmp = out[var].where(out[var].notna(), MISSING_BIN).astype(str)
            bin_map = dict(zip(rules["CATEGORY"].astype(str), rules["BIN"]))
            woe_map = dict(zip(rules["CATEGORY"].astype(str), rules["WOE"]))
            mapped_bin = tmp.map(bin_map)

            out[var+"_BIN"] = mapped_bin.fillna(bin_map.get(OTHER_BIN, OTHER_BIN))
            out[var+"_WOE"] = tmp.map(woe_map).fillna(woe_map.get(OTHER_BIN, 0.0))

    return out


# --------------------------------------------------
# Save Selected Rules
# --------------------------------------------------

def save_selected_rules(
    rules_dict,
    variables,
    file_name="SelectedRules.xlsx"
):

    meta = []
    selected = [v for v in variables if v in rules_dict]
    sheet_names = _build_sheet_name_map(selected, reserved={"_VARIABLE_TYPES_"})

    with pd.ExcelWriter(file_name, engine="openpyxl") as writer:

        for v in variables:

            if v not in rules_dict:
                continue

            meta.append({
                "VARIABLE": v,
                "TYPE": rules_dict[v]["TYPE"],
                "SHEET_NAME": sheet_names[v]
            })

            rules_dict[v]["RULES"].to_excel(
                writer,
                sheet_name=sheet_names[v],
                index=False
            )

        pd.DataFrame(meta).to_excel(
            writer,
            sheet_name="_VARIABLE_TYPES_",
            index=False
        )
